ALTER TABLE cluster_membership ALTER COLUMN rpc_address TYPE VARCHAR(128);
