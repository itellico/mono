ALTER TABLE current_executions ALTER COLUMN create_request_id TYPE VARCHAR(255);
ALTER TABLE signals_requested_sets ALTER COLUMN signal_id TYPE VARCHAR(255);
