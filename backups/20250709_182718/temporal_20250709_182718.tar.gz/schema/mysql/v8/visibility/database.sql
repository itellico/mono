CREATE DATABASE temporal_visibility CHARACTER SET utf8mb4;
