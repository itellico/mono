ALTER TABLE cluster_membership MODIFY COLUMN rpc_address VARCHAR(128);
