ALTER TABLE executions ADD db_record_version BIGINT NOT NULL DEFAULT 0;
