ALTER TABLE history_node ADD prev_txn_id BIGINT NOT NULL DEFAULT 0;
