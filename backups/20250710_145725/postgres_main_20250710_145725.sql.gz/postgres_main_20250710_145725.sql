--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE developer;
ALTER ROLE developer WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:hiGPc7SYrq2NbBca/J7PJg==$CaUcEqRCFCWHPZ+ZLhXCFIKdCTiVKPQctX8kjonezUg=:avX05ALgr7Z8DVOUEhqjFtNAZ1MYSG1Hv/4vLd1mtPo=';

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "kanboard" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: kanboard; Type: DATABASE; Schema: -; Owner: developer
--

CREATE DATABASE kanboard WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE kanboard OWNER TO developer;

\connect kanboard

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action_has_params; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.action_has_params (
    id integer NOT NULL,
    action_id integer NOT NULL,
    name text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.action_has_params OWNER TO developer;

--
-- Name: action_has_params_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.action_has_params_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.action_has_params_id_seq OWNER TO developer;

--
-- Name: action_has_params_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.action_has_params_id_seq OWNED BY public.action_has_params.id;


--
-- Name: actions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.actions (
    id integer NOT NULL,
    project_id integer NOT NULL,
    event_name text NOT NULL,
    action_name text NOT NULL
);


ALTER TABLE public.actions OWNER TO developer;

--
-- Name: actions_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actions_id_seq OWNER TO developer;

--
-- Name: actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.actions_id_seq OWNED BY public.actions.id;


--
-- Name: column_has_move_restrictions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.column_has_move_restrictions (
    restriction_id integer NOT NULL,
    project_id integer NOT NULL,
    role_id integer NOT NULL,
    src_column_id integer NOT NULL,
    dst_column_id integer NOT NULL,
    only_assigned boolean DEFAULT false
);


ALTER TABLE public.column_has_move_restrictions OWNER TO developer;

--
-- Name: column_has_move_restrictions_restriction_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.column_has_move_restrictions_restriction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.column_has_move_restrictions_restriction_id_seq OWNER TO developer;

--
-- Name: column_has_move_restrictions_restriction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.column_has_move_restrictions_restriction_id_seq OWNED BY public.column_has_move_restrictions.restriction_id;


--
-- Name: column_has_restrictions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.column_has_restrictions (
    restriction_id integer NOT NULL,
    project_id integer NOT NULL,
    role_id integer NOT NULL,
    column_id integer NOT NULL,
    rule character varying(255) NOT NULL
);


ALTER TABLE public.column_has_restrictions OWNER TO developer;

--
-- Name: column_has_restrictions_restriction_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.column_has_restrictions_restriction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.column_has_restrictions_restriction_id_seq OWNER TO developer;

--
-- Name: column_has_restrictions_restriction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.column_has_restrictions_restriction_id_seq OWNED BY public.column_has_restrictions.restriction_id;


--
-- Name: columns; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.columns (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    "position" integer,
    project_id integer NOT NULL,
    task_limit integer DEFAULT 0,
    description text,
    hide_in_dashboard boolean DEFAULT false
);


ALTER TABLE public.columns OWNER TO developer;

--
-- Name: columns_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.columns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.columns_id_seq OWNER TO developer;

--
-- Name: columns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.columns_id_seq OWNED BY public.columns.id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.comments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer DEFAULT 0,
    date_creation bigint NOT NULL,
    comment text,
    reference text DEFAULT ''::character varying,
    date_modification bigint,
    visibility character varying(25) DEFAULT 'app-user'::character varying NOT NULL
);


ALTER TABLE public.comments OWNER TO developer;

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_id_seq OWNER TO developer;

--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.currencies (
    currency character(3) NOT NULL,
    rate real DEFAULT 0
);


ALTER TABLE public.currencies OWNER TO developer;

--
-- Name: custom_filters; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.custom_filters (
    id integer NOT NULL,
    filter text NOT NULL,
    project_id integer NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    is_shared boolean DEFAULT false,
    append boolean DEFAULT false
);


ALTER TABLE public.custom_filters OWNER TO developer;

--
-- Name: custom_filters_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.custom_filters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_filters_id_seq OWNER TO developer;

--
-- Name: custom_filters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.custom_filters_id_seq OWNED BY public.custom_filters.id;


--
-- Name: group_has_users; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.group_has_users (
    group_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.group_has_users OWNER TO developer;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    external_id character varying(255) DEFAULT ''::character varying,
    name text NOT NULL
);


ALTER TABLE public.groups OWNER TO developer;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO developer;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: invites; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.invites (
    email character varying(255) NOT NULL,
    project_id integer NOT NULL,
    token character varying(255) NOT NULL
);


ALTER TABLE public.invites OWNER TO developer;

--
-- Name: last_logins; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.last_logins (
    id integer NOT NULL,
    auth_type character varying(25),
    user_id integer,
    ip character varying(45),
    user_agent character varying(255),
    date_creation bigint
);


ALTER TABLE public.last_logins OWNER TO developer;

--
-- Name: last_logins_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.last_logins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.last_logins_id_seq OWNER TO developer;

--
-- Name: last_logins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.last_logins_id_seq OWNED BY public.last_logins.id;


--
-- Name: links; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.links (
    id integer NOT NULL,
    label character varying(255) NOT NULL,
    opposite_id integer DEFAULT 0
);


ALTER TABLE public.links OWNER TO developer;

--
-- Name: links_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.links_id_seq OWNER TO developer;

--
-- Name: links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.links_id_seq OWNED BY public.links.id;


--
-- Name: password_reset; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.password_reset (
    token character varying(80) NOT NULL,
    user_id integer NOT NULL,
    date_expiration integer NOT NULL,
    date_creation integer NOT NULL,
    ip character varying(45) NOT NULL,
    user_agent character varying(255) NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.password_reset OWNER TO developer;

--
-- Name: plugin_schema_versions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.plugin_schema_versions (
    plugin character varying(80) NOT NULL,
    version integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.plugin_schema_versions OWNER TO developer;

--
-- Name: predefined_task_descriptions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.predefined_task_descriptions (
    id integer NOT NULL,
    project_id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.predefined_task_descriptions OWNER TO developer;

--
-- Name: predefined_task_descriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.predefined_task_descriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.predefined_task_descriptions_id_seq OWNER TO developer;

--
-- Name: predefined_task_descriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.predefined_task_descriptions_id_seq OWNED BY public.predefined_task_descriptions.id;


--
-- Name: project_activities; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_activities (
    id integer NOT NULL,
    date_creation bigint NOT NULL,
    event_name text NOT NULL,
    creator_id integer,
    project_id integer,
    task_id integer,
    data text
);


ALTER TABLE public.project_activities OWNER TO developer;

--
-- Name: project_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_activities_id_seq OWNER TO developer;

--
-- Name: project_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_activities_id_seq OWNED BY public.project_activities.id;


--
-- Name: project_daily_column_stats; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_daily_column_stats (
    id integer NOT NULL,
    day character(10) NOT NULL,
    project_id integer NOT NULL,
    column_id integer NOT NULL,
    total integer DEFAULT 0 NOT NULL,
    score integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.project_daily_column_stats OWNER TO developer;

--
-- Name: project_daily_stats; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_daily_stats (
    id integer NOT NULL,
    day character(10) NOT NULL,
    project_id integer NOT NULL,
    avg_lead_time integer DEFAULT 0 NOT NULL,
    avg_cycle_time integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.project_daily_stats OWNER TO developer;

--
-- Name: project_daily_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_daily_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_daily_stats_id_seq OWNER TO developer;

--
-- Name: project_daily_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_daily_stats_id_seq OWNED BY public.project_daily_stats.id;


--
-- Name: project_daily_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_daily_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_daily_summaries_id_seq OWNER TO developer;

--
-- Name: project_daily_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_daily_summaries_id_seq OWNED BY public.project_daily_column_stats.id;


--
-- Name: project_has_categories; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    project_id integer NOT NULL,
    description text,
    color_id character varying(50) DEFAULT NULL::character varying
);


ALTER TABLE public.project_has_categories OWNER TO developer;

--
-- Name: project_has_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_has_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_has_categories_id_seq OWNER TO developer;

--
-- Name: project_has_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_has_categories_id_seq OWNED BY public.project_has_categories.id;


--
-- Name: project_has_files; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_files (
    id integer NOT NULL,
    project_id integer NOT NULL,
    name text NOT NULL,
    path text NOT NULL,
    is_image boolean DEFAULT false,
    size integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    date integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.project_has_files OWNER TO developer;

--
-- Name: project_has_files_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_has_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_has_files_id_seq OWNER TO developer;

--
-- Name: project_has_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_has_files_id_seq OWNED BY public.project_has_files.id;


--
-- Name: project_has_groups; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_groups (
    group_id integer NOT NULL,
    project_id integer NOT NULL,
    role character varying(255) NOT NULL
);


ALTER TABLE public.project_has_groups OWNER TO developer;

--
-- Name: project_has_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_metadata (
    project_id integer NOT NULL,
    name character varying(50) NOT NULL,
    value character varying(255) DEFAULT ''::character varying,
    changed_by integer DEFAULT 0 NOT NULL,
    changed_on integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.project_has_metadata OWNER TO developer;

--
-- Name: project_has_notification_types; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_notification_types (
    id integer NOT NULL,
    project_id integer NOT NULL,
    notification_type character varying(50) NOT NULL
);


ALTER TABLE public.project_has_notification_types OWNER TO developer;

--
-- Name: project_has_notification_types_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_has_notification_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_has_notification_types_id_seq OWNER TO developer;

--
-- Name: project_has_notification_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_has_notification_types_id_seq OWNED BY public.project_has_notification_types.id;


--
-- Name: project_has_roles; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_roles (
    role_id integer NOT NULL,
    role character varying(255) NOT NULL,
    project_id integer NOT NULL
);


ALTER TABLE public.project_has_roles OWNER TO developer;

--
-- Name: project_has_roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_has_roles_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_has_roles_role_id_seq OWNER TO developer;

--
-- Name: project_has_roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_has_roles_role_id_seq OWNED BY public.project_has_roles.role_id;


--
-- Name: project_has_users; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_users (
    project_id integer NOT NULL,
    user_id integer NOT NULL,
    role character varying(255) DEFAULT 'project-viewer'::character varying NOT NULL
);


ALTER TABLE public.project_has_users OWNER TO developer;

--
-- Name: project_role_has_restrictions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_role_has_restrictions (
    restriction_id integer NOT NULL,
    project_id integer NOT NULL,
    role_id integer NOT NULL,
    rule character varying(255) NOT NULL
);


ALTER TABLE public.project_role_has_restrictions OWNER TO developer;

--
-- Name: project_role_has_restrictions_restriction_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_role_has_restrictions_restriction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_role_has_restrictions_restriction_id_seq OWNER TO developer;

--
-- Name: project_role_has_restrictions_restriction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_role_has_restrictions_restriction_id_seq OWNED BY public.project_role_has_restrictions.restriction_id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT true,
    token character varying(255),
    last_modified bigint DEFAULT 0,
    is_public boolean DEFAULT false,
    is_private boolean DEFAULT false,
    description text,
    identifier character varying(50) DEFAULT ''::character varying,
    start_date character varying(10) DEFAULT ''::character varying,
    end_date character varying(10) DEFAULT ''::character varying,
    owner_id integer DEFAULT 0,
    priority_default integer DEFAULT 0,
    priority_start integer DEFAULT 0,
    priority_end integer DEFAULT 3,
    email text,
    predefined_email_subjects text,
    per_swimlane_task_limits boolean DEFAULT false,
    task_limit integer DEFAULT 0,
    enable_global_tags boolean DEFAULT true
);


ALTER TABLE public.projects OWNER TO developer;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO developer;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: remember_me; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.remember_me (
    id integer NOT NULL,
    user_id integer,
    ip character varying(45),
    user_agent character varying(255),
    token character varying(255),
    sequence character varying(255),
    expiration integer,
    date_creation bigint
);


ALTER TABLE public.remember_me OWNER TO developer;

--
-- Name: remember_me_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.remember_me_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.remember_me_id_seq OWNER TO developer;

--
-- Name: remember_me_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.remember_me_id_seq OWNED BY public.remember_me.id;


--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.schema_version (
    version integer DEFAULT 0
);


ALTER TABLE public.schema_version OWNER TO developer;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    expire_at integer NOT NULL,
    data text DEFAULT ''::text
);


ALTER TABLE public.sessions OWNER TO developer;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.settings (
    option character varying(100) NOT NULL,
    value text DEFAULT ''::character varying,
    changed_by integer DEFAULT 0 NOT NULL,
    changed_on integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.settings OWNER TO developer;

--
-- Name: subtask_time_tracking; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.subtask_time_tracking (
    id integer NOT NULL,
    user_id integer NOT NULL,
    subtask_id integer NOT NULL,
    start bigint DEFAULT 0,
    "end" bigint DEFAULT 0,
    time_spent real DEFAULT 0
);


ALTER TABLE public.subtask_time_tracking OWNER TO developer;

--
-- Name: subtask_time_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.subtask_time_tracking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subtask_time_tracking_id_seq OWNER TO developer;

--
-- Name: subtask_time_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.subtask_time_tracking_id_seq OWNED BY public.subtask_time_tracking.id;


--
-- Name: subtasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.subtasks (
    id integer NOT NULL,
    title text NOT NULL,
    status smallint DEFAULT 0,
    time_estimated double precision DEFAULT 0,
    time_spent double precision DEFAULT 0,
    task_id integer NOT NULL,
    user_id integer,
    "position" integer DEFAULT 1
);


ALTER TABLE public.subtasks OWNER TO developer;

--
-- Name: swimlanes; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.swimlanes (
    id integer NOT NULL,
    name text NOT NULL,
    "position" integer DEFAULT 1,
    is_active boolean DEFAULT true,
    project_id integer,
    description text,
    task_limit integer DEFAULT 0
);


ALTER TABLE public.swimlanes OWNER TO developer;

--
-- Name: swimlanes_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.swimlanes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.swimlanes_id_seq OWNER TO developer;

--
-- Name: swimlanes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.swimlanes_id_seq OWNED BY public.swimlanes.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    project_id integer NOT NULL,
    color_id character varying(50) DEFAULT NULL::character varying
);


ALTER TABLE public.tags OWNER TO developer;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_id_seq OWNER TO developer;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: task_has_external_links; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_has_external_links (
    id integer NOT NULL,
    link_type character varying(100) NOT NULL,
    dependency character varying(100) NOT NULL,
    title text NOT NULL,
    url text NOT NULL,
    date_creation integer NOT NULL,
    date_modification integer NOT NULL,
    task_id integer NOT NULL,
    creator_id integer DEFAULT 0
);


ALTER TABLE public.task_has_external_links OWNER TO developer;

--
-- Name: task_has_external_links_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.task_has_external_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_has_external_links_id_seq OWNER TO developer;

--
-- Name: task_has_external_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.task_has_external_links_id_seq OWNED BY public.task_has_external_links.id;


--
-- Name: task_has_files; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_has_files (
    id integer NOT NULL,
    name text NOT NULL,
    path text,
    is_image boolean DEFAULT false,
    task_id integer NOT NULL,
    date bigint DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    size integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.task_has_files OWNER TO developer;

--
-- Name: task_has_files_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.task_has_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_has_files_id_seq OWNER TO developer;

--
-- Name: task_has_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.task_has_files_id_seq OWNED BY public.task_has_files.id;


--
-- Name: task_has_links; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_has_links (
    id integer NOT NULL,
    link_id integer NOT NULL,
    task_id integer NOT NULL,
    opposite_task_id integer NOT NULL
);


ALTER TABLE public.task_has_links OWNER TO developer;

--
-- Name: task_has_links_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.task_has_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_has_links_id_seq OWNER TO developer;

--
-- Name: task_has_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.task_has_links_id_seq OWNED BY public.task_has_links.id;


--
-- Name: task_has_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_has_metadata (
    task_id integer NOT NULL,
    name character varying(50) NOT NULL,
    value character varying(255) DEFAULT ''::character varying,
    changed_by integer DEFAULT 0 NOT NULL,
    changed_on integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.task_has_metadata OWNER TO developer;

--
-- Name: task_has_subtasks_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.task_has_subtasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_has_subtasks_id_seq OWNER TO developer;

--
-- Name: task_has_subtasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.task_has_subtasks_id_seq OWNED BY public.subtasks.id;


--
-- Name: task_has_tags; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_has_tags (
    task_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.task_has_tags OWNER TO developer;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    date_creation bigint,
    color_id character varying(255),
    project_id integer NOT NULL,
    column_id integer NOT NULL,
    owner_id integer DEFAULT 0,
    "position" integer,
    is_active boolean DEFAULT true,
    date_completed bigint,
    score integer,
    date_due bigint,
    category_id integer DEFAULT 0,
    creator_id integer DEFAULT 0,
    date_modification integer DEFAULT 0,
    reference text DEFAULT ''::character varying,
    date_started bigint,
    time_spent double precision DEFAULT 0,
    time_estimated double precision DEFAULT 0,
    swimlane_id integer NOT NULL,
    date_moved bigint DEFAULT 0,
    recurrence_status integer DEFAULT 0 NOT NULL,
    recurrence_trigger integer DEFAULT 0 NOT NULL,
    recurrence_factor integer DEFAULT 0 NOT NULL,
    recurrence_timeframe integer DEFAULT 0 NOT NULL,
    recurrence_basedate integer DEFAULT 0 NOT NULL,
    recurrence_parent integer,
    recurrence_child integer,
    priority integer DEFAULT 0,
    external_provider character varying(255),
    external_uri character varying(255)
);


ALTER TABLE public.tasks OWNER TO developer;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO developer;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: transitions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.transitions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    project_id integer NOT NULL,
    task_id integer NOT NULL,
    src_column_id integer NOT NULL,
    dst_column_id integer NOT NULL,
    date bigint NOT NULL,
    time_spent integer DEFAULT 0
);


ALTER TABLE public.transitions OWNER TO developer;

--
-- Name: transitions_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.transitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transitions_id_seq OWNER TO developer;

--
-- Name: transitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.transitions_id_seq OWNED BY public.transitions.id;


--
-- Name: user_has_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.user_has_metadata (
    user_id integer NOT NULL,
    name character varying(50) NOT NULL,
    value character varying(255) DEFAULT ''::character varying,
    changed_by integer DEFAULT 0 NOT NULL,
    changed_on integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_has_metadata OWNER TO developer;

--
-- Name: user_has_notification_types; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.user_has_notification_types (
    id integer NOT NULL,
    user_id integer NOT NULL,
    notification_type character varying(50)
);


ALTER TABLE public.user_has_notification_types OWNER TO developer;

--
-- Name: user_has_notification_types_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.user_has_notification_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_has_notification_types_id_seq OWNER TO developer;

--
-- Name: user_has_notification_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.user_has_notification_types_id_seq OWNED BY public.user_has_notification_types.id;


--
-- Name: user_has_notifications; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.user_has_notifications (
    user_id integer NOT NULL,
    project_id integer
);


ALTER TABLE public.user_has_notifications OWNER TO developer;

--
-- Name: user_has_unread_notifications; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.user_has_unread_notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    date_creation bigint NOT NULL,
    event_name text NOT NULL,
    event_data text NOT NULL
);


ALTER TABLE public.user_has_unread_notifications OWNER TO developer;

--
-- Name: user_has_unread_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.user_has_unread_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_has_unread_notifications_id_seq OWNER TO developer;

--
-- Name: user_has_unread_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.user_has_unread_notifications_id_seq OWNED BY public.user_has_unread_notifications.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password character varying(255),
    is_ldap_user boolean DEFAULT false,
    name character varying(255),
    email character varying(255),
    google_id character varying(255),
    github_id character varying(30),
    notifications_enabled boolean DEFAULT false,
    timezone character varying(50),
    language character varying(11),
    disable_login_form boolean DEFAULT false,
    twofactor_activated boolean DEFAULT false,
    twofactor_secret character(16),
    token character varying(255) DEFAULT ''::character varying,
    notifications_filter integer DEFAULT 4,
    nb_failed_login integer DEFAULT 0,
    lock_expiration_date bigint DEFAULT 0,
    gitlab_id integer,
    role character varying(25) DEFAULT 'app-user'::character varying NOT NULL,
    is_active boolean DEFAULT true,
    avatar_path character varying(255),
    api_access_token character varying(255) DEFAULT NULL::character varying,
    filter text DEFAULT NULL::character varying,
    theme text DEFAULT 'light'::text NOT NULL
);


ALTER TABLE public.users OWNER TO developer;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO developer;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: action_has_params id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.action_has_params ALTER COLUMN id SET DEFAULT nextval('public.action_has_params_id_seq'::regclass);


--
-- Name: actions id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.actions ALTER COLUMN id SET DEFAULT nextval('public.actions_id_seq'::regclass);


--
-- Name: column_has_move_restrictions restriction_id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions ALTER COLUMN restriction_id SET DEFAULT nextval('public.column_has_move_restrictions_restriction_id_seq'::regclass);


--
-- Name: column_has_restrictions restriction_id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions ALTER COLUMN restriction_id SET DEFAULT nextval('public.column_has_restrictions_restriction_id_seq'::regclass);


--
-- Name: columns id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.columns ALTER COLUMN id SET DEFAULT nextval('public.columns_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: custom_filters id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.custom_filters ALTER COLUMN id SET DEFAULT nextval('public.custom_filters_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: last_logins id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.last_logins ALTER COLUMN id SET DEFAULT nextval('public.last_logins_id_seq'::regclass);


--
-- Name: links id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.links ALTER COLUMN id SET DEFAULT nextval('public.links_id_seq'::regclass);


--
-- Name: predefined_task_descriptions id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.predefined_task_descriptions ALTER COLUMN id SET DEFAULT nextval('public.predefined_task_descriptions_id_seq'::regclass);


--
-- Name: project_activities id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_activities ALTER COLUMN id SET DEFAULT nextval('public.project_activities_id_seq'::regclass);


--
-- Name: project_daily_column_stats id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_column_stats ALTER COLUMN id SET DEFAULT nextval('public.project_daily_summaries_id_seq'::regclass);


--
-- Name: project_daily_stats id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_stats ALTER COLUMN id SET DEFAULT nextval('public.project_daily_stats_id_seq'::regclass);


--
-- Name: project_has_categories id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_categories ALTER COLUMN id SET DEFAULT nextval('public.project_has_categories_id_seq'::regclass);


--
-- Name: project_has_files id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_files ALTER COLUMN id SET DEFAULT nextval('public.project_has_files_id_seq'::regclass);


--
-- Name: project_has_notification_types id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_notification_types ALTER COLUMN id SET DEFAULT nextval('public.project_has_notification_types_id_seq'::regclass);


--
-- Name: project_has_roles role_id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_roles ALTER COLUMN role_id SET DEFAULT nextval('public.project_has_roles_role_id_seq'::regclass);


--
-- Name: project_role_has_restrictions restriction_id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_role_has_restrictions ALTER COLUMN restriction_id SET DEFAULT nextval('public.project_role_has_restrictions_restriction_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: remember_me id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.remember_me ALTER COLUMN id SET DEFAULT nextval('public.remember_me_id_seq'::regclass);


--
-- Name: subtask_time_tracking id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtask_time_tracking ALTER COLUMN id SET DEFAULT nextval('public.subtask_time_tracking_id_seq'::regclass);


--
-- Name: subtasks id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtasks ALTER COLUMN id SET DEFAULT nextval('public.task_has_subtasks_id_seq'::regclass);


--
-- Name: swimlanes id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.swimlanes ALTER COLUMN id SET DEFAULT nextval('public.swimlanes_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: task_has_external_links id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_external_links ALTER COLUMN id SET DEFAULT nextval('public.task_has_external_links_id_seq'::regclass);


--
-- Name: task_has_files id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_files ALTER COLUMN id SET DEFAULT nextval('public.task_has_files_id_seq'::regclass);


--
-- Name: task_has_links id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_links ALTER COLUMN id SET DEFAULT nextval('public.task_has_links_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: transitions id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions ALTER COLUMN id SET DEFAULT nextval('public.transitions_id_seq'::regclass);


--
-- Name: user_has_notification_types id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notification_types ALTER COLUMN id SET DEFAULT nextval('public.user_has_notification_types_id_seq'::regclass);


--
-- Name: user_has_unread_notifications id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_unread_notifications ALTER COLUMN id SET DEFAULT nextval('public.user_has_unread_notifications_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: action_has_params; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.action_has_params (id, action_id, name, value) FROM stdin;
\.


--
-- Data for Name: actions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.actions (id, project_id, event_name, action_name) FROM stdin;
\.


--
-- Data for Name: column_has_move_restrictions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.column_has_move_restrictions (restriction_id, project_id, role_id, src_column_id, dst_column_id, only_assigned) FROM stdin;
\.


--
-- Data for Name: column_has_restrictions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.column_has_restrictions (restriction_id, project_id, role_id, column_id, rule) FROM stdin;
\.


--
-- Data for Name: columns; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.columns (id, title, "position", project_id, task_limit, description, hide_in_dashboard) FROM stdin;
1	Backlog	1	1	0		f
2	Ready	2	1	0		f
3	Work in progress	3	1	0		f
4	Done	4	1	0		f
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.comments (id, task_id, user_id, date_creation, comment, reference, date_modification, visibility) FROM stdin;
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.currencies (currency, rate) FROM stdin;
\.


--
-- Data for Name: custom_filters; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.custom_filters (id, filter, project_id, user_id, name, is_shared, append) FROM stdin;
\.


--
-- Data for Name: group_has_users; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.group_has_users (group_id, user_id) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.groups (id, external_id, name) FROM stdin;
\.


--
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.invites (email, project_id, token) FROM stdin;
\.


--
-- Data for Name: last_logins; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.last_logins (id, auth_type, user_id, ip, user_agent, date_creation) FROM stdin;
1	Database	1	192.168.65.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	1752062887
\.


--
-- Data for Name: links; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.links (id, label, opposite_id) FROM stdin;
1	relates to	0
2	blocks	3
3	is blocked by	2
4	duplicates	5
5	is duplicated by	4
6	is a child of	7
7	is a parent of	6
8	targets milestone	9
9	is a milestone of	8
10	fixes	11
11	is fixed by	10
\.


--
-- Data for Name: password_reset; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.password_reset (token, user_id, date_expiration, date_creation, ip, user_agent, is_active) FROM stdin;
\.


--
-- Data for Name: plugin_schema_versions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.plugin_schema_versions (plugin, version) FROM stdin;
\.


--
-- Data for Name: predefined_task_descriptions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.predefined_task_descriptions (id, project_id, title, description) FROM stdin;
\.


--
-- Data for Name: project_activities; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_activities (id, date_creation, event_name, creator_id, project_id, task_id, data) FROM stdin;
\.


--
-- Data for Name: project_daily_column_stats; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_daily_column_stats (id, day, project_id, column_id, total, score) FROM stdin;
37	2025-07-09	1	1	30	0
\.


--
-- Data for Name: project_daily_stats; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_daily_stats (id, day, project_id, avg_lead_time, avg_cycle_time) FROM stdin;
37	2025-07-09	1	643	0
\.


--
-- Data for Name: project_has_categories; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_categories (id, name, project_id, description, color_id) FROM stdin;
\.


--
-- Data for Name: project_has_files; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_files (id, project_id, name, path, is_image, size, user_id, date) FROM stdin;
\.


--
-- Data for Name: project_has_groups; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_groups (group_id, project_id, role) FROM stdin;
\.


--
-- Data for Name: project_has_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_metadata (project_id, name, value, changed_by, changed_on) FROM stdin;
\.


--
-- Data for Name: project_has_notification_types; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_notification_types (id, project_id, notification_type) FROM stdin;
\.


--
-- Data for Name: project_has_roles; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_roles (role_id, role, project_id) FROM stdin;
\.


--
-- Data for Name: project_has_users; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_users (project_id, user_id, role) FROM stdin;
1	1	project-manager
\.


--
-- Data for Name: project_role_has_restrictions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_role_has_restrictions (restriction_id, project_id, role_id, rule) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.projects (id, name, is_active, token, last_modified, is_public, is_private, description, identifier, start_date, end_date, owner_id, priority_default, priority_start, priority_end, email, predefined_email_subjects, per_swimlane_task_limits, task_limit, enable_global_tags) FROM stdin;
1	mono	t		1752073077	f	f	\N				1	0	0	3	\N	\N	f	0	t
\.


--
-- Data for Name: remember_me; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.remember_me (id, user_id, ip, user_agent, token, sequence, expiration, date_creation) FROM stdin;
1	1	192.168.65.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	40a425e8f04416c973a6f2eabd679ada6ca703df4cd3dca312c7ed6f9209c4ea	b4d64bf123ecd35a78f5f42e0bbab5b490b187558bda102a3ac9bc5c68f1	1757246887	1752062887
\.


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.schema_version (version) FROM stdin;
117
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.sessions (id, expire_at, data) FROM stdin;
688888cfdd6996cadd538e30d637e63a	1752074958	csrf_key|s:64:"683ac4aafe2f8fc8ccee34355b40c12bdc2775670b73891e3d775f112d388b7b";hasRememberMe|b:1;user|a:24:{s:2:"id";i:1;s:8:"username";s:5:"admin";s:12:"is_ldap_user";b:0;s:4:"name";N;s:5:"email";N;s:9:"google_id";N;s:9:"github_id";N;s:21:"notifications_enabled";b:0;s:8:"timezone";N;s:8:"language";N;s:18:"disable_login_form";b:0;s:19:"twofactor_activated";b:0;s:16:"twofactor_secret";N;s:5:"token";s:0:"";s:20:"notifications_filter";i:4;s:15:"nb_failed_login";i:0;s:20:"lock_expiration_date";i:0;s:9:"gitlab_id";N;s:4:"role";s:9:"app-admin";s:9:"is_active";b:1;s:11:"avatar_path";N;s:16:"api_access_token";N;s:6:"filter";N;s:5:"theme";s:5:"light";}postAuthenticationValidated|b:0;hasSubtaskInProgress|b:0;flash|a:0:{}filters:1|s:11:"status:open";pcsrf_key|s:64:"42540f52b42be4364e16e1bc792bd1c5b40a1e6b5a4e74540b962b767a9ccf67";
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.settings (option, value, changed_by, changed_on) FROM stdin;
board_highlight_period	172800	0	0
board_public_refresh_interval	60	0	0
board_private_refresh_interval	10	0	0
board_columns		0	0
webhook_token	15c4a94a1792dcdd49c81bd6b23966962617506b09ab4ca1cee6985afa5b	0	0
api_token	2e85cd5800c57f0ff4b7bc0d64848a3f41bd714245f4e9a6bc9398c6211b	0	0
application_language	en_US	0	0
application_timezone	UTC	0	0
application_url		0	0
application_date_format	m/d/Y	0	0
project_categories		0	0
subtask_restriction	0	0	0
application_stylesheet		0	0
application_currency	USD	0	0
integration_gravatar	0	0	0
calendar_user_subtasks_time_tracking	0	0	0
calendar_user_tasks	date_started	0	0
calendar_project_tasks	date_started	0	0
webhook_url		0	0
default_color	yellow	0	0
subtask_time_tracking	1	0	0
cfd_include_closed_tasks	1	0	0
password_reset	1	0	0
mail_sender_address		1	1752063124
mail_transport	smtp	1	1752063124
\.


--
-- Data for Name: subtask_time_tracking; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.subtask_time_tracking (id, user_id, subtask_id, start, "end", time_spent) FROM stdin;
\.


--
-- Data for Name: subtasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.subtasks (id, title, status, time_estimated, time_spent, task_id, user_id, "position") FROM stdin;
\.


--
-- Data for Name: swimlanes; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.swimlanes (id, name, "position", is_active, project_id, description, task_limit) FROM stdin;
1	Default swimlane	1	t	1		0
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.tags (id, name, project_id, color_id) FROM stdin;
1	security	1	\N
2	backend	1	\N
3	api	1	\N
4	bug	1	\N
5	compliance	1	\N
6	feature	1	\N
7	payment	1	\N
8	testing	1	\N
9	frontend	1	\N
10	infra	1	\N
11	performance	1	\N
12	database	1	\N
13	analytics	1	\N
14	mobile	1	\N
15	auth	1	\N
16	messaging	1	\N
17	docs	1	\N
18	roadmap	1	\N
19	status	1	\N
20	project-management	1	\N
21	subtask	1	\N
22	mfa	1	\N
23	content	1	\N
24	workflow	1	\N
25	template	1	\N
26	reference	1	\N
27	documentation	1	\N
28	clickdummy	1	\N
29	gdpr	1	\N
\.


--
-- Data for Name: task_has_external_links; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_has_external_links (id, link_type, dependency, title, url, date_creation, date_modification, task_id, creator_id) FROM stdin;
\.


--
-- Data for Name: task_has_files; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_has_files (id, name, path, is_image, task_id, date, user_id, size) FROM stdin;
\.


--
-- Data for Name: task_has_links; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_has_links (id, link_id, task_id, opposite_task_id) FROM stdin;
\.


--
-- Data for Name: task_has_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_has_metadata (task_id, name, value, changed_by, changed_on) FROM stdin;
\.


--
-- Data for Name: task_has_tags; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_has_tags (task_id, tag_id) FROM stdin;
4	1
4	2
4	3
4	4
5	1
5	2
5	4
5	5
6	6
6	2
6	3
6	7
7	8
7	2
7	9
8	8
8	9
8	10
9	11
9	2
9	12
10	6
10	2
10	9
10	13
11	6
11	9
11	14
12	6
12	2
12	3
12	15
13	6
13	2
13	10
14	6
14	2
14	9
14	4
15	3
15	2
15	7
16	3
16	2
16	13
17	9
17	6
17	4
18	9
18	6
18	16
19	17
19	3
20	10
20	8
20	1
21	4
21	9
21	13
22	4
22	10
22	2
23	18
23	19
23	20
24	17
24	1
24	21
24	22
25	17
25	7
25	21
26	17
26	8
26	21
27	17
27	13
27	9
27	21
28	17
28	23
28	24
28	21
29	25
29	26
30	26
30	27
30	28
31	17
31	5
31	29
31	21
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.tasks (id, title, description, date_creation, color_id, project_id, column_id, owner_id, "position", is_active, date_completed, score, date_due, category_id, creator_id, date_modification, reference, date_started, time_spent, time_estimated, swimlane_id, date_moved, recurrence_status, recurrence_trigger, recurrence_factor, recurrence_timeframe, recurrence_basedate, recurrence_parent, recurrence_child, priority, external_provider, external_uri) FROM stdin;
1	Test Task from MCP Integration	This is a test task created via the API to verify Kanboard integration is working properly	1752070710	blue	1	1	0	1	t	\N	0	0	0	0	1752071271		0	\N	\N	1	1752070710	0	0	0	0	0	\N	\N	1	\N	\N
2	Test after MCP fix		1752071109	yellow	1	1	0	2	t	\N	0	0	0	0	1752071277		0	\N	\N	1	1752071109	0	0	0	0	0	\N	\N	0	\N	\N
8	Testing Infrastructure - E2E Tests	Set up end-to-end testing framework and implement critical user journey tests.\n\nRequirements:\n- Playwright setup\n- Critical user flows testing\n- CI/CD integration\n- Test data management\n- Parallel test execution\n\nKey flows to test:\n- User registration/login\n- Job posting workflow\n- Messaging system\n- Payment flows	1752072316	orange	1	1	0	7	t	\N	0	0	0	0	1752072316		0	\N	\N	1	1752072316	0	0	0	0	0	\N	\N	2	\N	\N
9	Performance Optimization - Database Queries	Optimize database performance to maintain <200ms API response times.\n\nCurrent: 60% optimized\nIssues to address:\n- N+1 query problems\n- Missing indexes\n- Inefficient joins\n- Query result caching\n- Connection pooling optimization\n\nTools: Prisma query analysis, pgAdmin, Redis caching	1752072323	orange	1	1	0	8	t	\N	0	0	0	0	1752072323		0	\N	\N	1	1752072323	0	0	0	0	0	\N	\N	2	\N	\N
10	Advanced Analytics - User Behavior Tracking	Implement comprehensive user analytics system.\n\nRequirements:\n- User action tracking\n- Session analytics\n- Conversion funnel analysis\n- Custom event tracking\n- Privacy-compliant data collection\n- Real-time dashboards\n\nCurrent: 30% complete\nStack: PostHog/Mixpanel integration, custom analytics API	1752072330	orange	1	1	0	9	t	\N	0	0	0	0	1752072330		0	\N	\N	1	1752072330	0	0	0	0	0	\N	\N	2	\N	\N
11	Mobile Optimization - PWA Implementation	Convert the Next.js application into a Progressive Web App.\n\nRequirements:\n- Service worker implementation\n- Offline functionality\n- Push notifications\n- App manifest configuration\n- Cache strategies\n- Install prompts\n\nCurrent: 40% complete	1752072336	yellow	1	1	0	10	t	\N	0	0	0	0	1752072336		0	\N	\N	1	1752072336	0	0	0	0	0	\N	\N	1	\N	\N
12	Social Media Login Integration	Implement OAuth-based social login options.\n\nProviders to integrate:\n- Google OAuth 2.0\n- Facebook Login\n- LinkedIn Authentication\n- Apple Sign In\n\nRequirements:\n- Account linking for existing users\n- Profile data import\n- Security considerations	1752072343	yellow	1	1	0	11	t	\N	0	0	0	0	1752072343		0	\N	\N	1	1752072343	0	0	0	0	0	\N	\N	1	\N	\N
13	Workflow Automation - Temporal Integration	Complete Temporal workflow engine integration for complex business processes.\n\nUse cases:\n- Job application workflows\n- Content moderation pipelines\n- Payment processing workflows\n- User onboarding sequences\n- Notification scheduling\n\nTech: Temporal.io + Reactflow for visual workflow builder	1752072351	yellow	1	1	0	12	t	\N	0	0	0	0	1752072351		0	\N	\N	1	1752072351	0	0	0	0	0	\N	\N	1	\N	\N
15	API Endpoints - Payment Routes	Implement missing payment-related API endpoints.\n\nRequired endpoints:\n- POST /api/v1/payments/connect/onboard\n- POST /api/v1/payments/process\n- GET /api/v1/payments/history\n- POST /api/v1/payments/refund\n- GET /api/v1/payments/invoices\n- POST /api/v1/payments/escrow/release\n\nFollow 5-tier API architecture	1752072371	blue	1	1	0	14	t	\N	0	0	0	0	1752072371		0	\N	\N	1	1752072371	0	0	0	0	0	\N	\N	2	\N	\N
16	API Endpoints - Analytics Routes	Create analytics API endpoints for dashboard data.\n\nRequired endpoints:\n- GET /api/v1/analytics/users/behavior\n- GET /api/v1/analytics/revenue/summary\n- GET /api/v1/analytics/content/performance\n- POST /api/v1/analytics/events/track\n- GET /api/v1/analytics/funnels\n\nInclude proper caching strategies	1752072378	blue	1	1	0	15	t	\N	0	0	0	0	1752072378		0	\N	\N	1	1752072378	0	0	0	0	0	\N	\N	1	\N	\N
18	Frontend - Video Call Integration	Add video calling to messaging system.\n\nRequirements:\n- WebRTC implementation\n- Screen sharing capability\n- Recording options\n- In-call chat\n- Call scheduling\n- Integration with existing messaging\n\nOptions: Daily.co, Twilio Video, or Jitsi	1752072394	purple	1	1	0	17	t	\N	0	0	0	0	1752072394		0	\N	\N	1	1752072394	0	0	0	0	0	\N	\N	1	\N	\N
7	Testing Infrastructure - Unit Tests	Implement comprehensive unit testing across the codebase.\n\n## Current: 20% complete\n## Target: 80% code coverage\n\n## Areas to cover:\n- API endpoints (Fastify routes)\n- Business logic services\n- Database models (Prisma)\n- Utility functions\n- React components\n\n## Documentation Links:\n- 📚 Testing Guide: http://localhost:3005/development/testing/methodology\n- 📚 Coverage Types: http://localhost:3005/development/testing/types-and-coverage\n- 🎯 Test Examples: Check existing test files in `/apps/api/src/__tests__/`\n- 📖 Best Practices: http://localhost:3005/development/workflows/complete-workflow\n\n## Testing Structure:\n```\n/apps/api/src/__tests__/\n  /routes/    # API endpoint tests\n  /services/  # Business logic tests\n  /utils/     # Utility function tests\n\n/apps/web/src/__tests__/\n  /components/  # React component tests\n  /hooks/       # Custom hook tests\n  /utils/       # Frontend utility tests\n```\n\n## Tools: Vitest, React Testing Library, MSW for API mocking	1752072308	orange	1	1	0	6	t	\N	0	0	0	0	1752072950		0	\N	\N	1	1752072308	0	0	0	0	0	\N	\N	2	\N	\N
5	Implement Data Retention Policies	Create and implement comprehensive data retention policies for GDPR compliance.\n\n## Requirements:\n- User data retention settings\n- Automatic data purging mechanisms\n- Audit trail for data deletions\n- Configurable retention periods per data type\n- Right to be forgotten implementation\n\n## Documentation Links:\n- 📚 Security Docs: http://localhost:3005/architecture/security\n- 📚 Audit System: http://localhost:3005/platform/system-management/audit-system\n- 🎯 Clickdummy - Platform: http://localhost:4040/platform/settings/data-retention.php\n- 🎯 Clickdummy - User: http://localhost:4040/user/settings.php#privacy\n- 📖 GDPR Guide: http://localhost:3005/architecture/security/gdpr-compliance\n\n## Implementation Across Tiers:\n1. **Platform**: Global retention policies, compliance dashboard\n2. **Tenant**: Marketplace-specific data rules\n3. **User**: Privacy settings, data export/delete requests\n\n## Technical Implementation:\n- Cron jobs for automatic data purging\n- Soft delete with retention periods\n- Audit log for all deletions\n- Data export API endpoints\n- Anonymization procedures\n\n## Related Tasks:\n- Parent: Security & Compliance Epic\n- Related: #4 (MFA), #21 (Audit System)\n\nPriority: Critical for compliance	1752072292	red	1	1	0	4	t	\N	0	0	0	0	1752073066		0	\N	\N	1	1752072292	0	0	0	0	0	\N	\N	3	\N	\N
19	Documentation - API Reference Update	Update OpenAPI documentation for all new endpoints.\n\nTasks:\n- Document payment endpoints\n- Document analytics endpoints  \n- Add example requests/responses\n- Update Postman collection\n- Generate TypeScript types\n- Update API versioning guide	1752072401	grey	1	1	0	18	t	\N	0	0	0	0	1752072401		0	\N	\N	1	1752072401	0	0	0	0	0	\N	\N	0	\N	\N
20	Infrastructure - CI/CD Pipeline Enhancement	Improve GitHub Actions workflows.\n\nEnhancements:\n- Add automated testing on PR\n- Implement deployment previews\n- Add security scanning (Snyk/Dependabot)\n- Performance regression tests\n- Automated changelog generation\n- Docker image optimization	1752072409	grey	1	1	0	19	t	\N	0	0	0	0	1752072409		0	\N	\N	1	1752072409	0	0	0	0	0	\N	\N	1	\N	\N
21	Bug - Missing Portfolio Analytics	Portfolio analytics feature is documented but not implemented.\n\nMissing functionality:\n- View counts tracking\n- Engagement metrics\n- Conversion tracking\n- Performance over time graphs\n- Comparison with peers\n\nAffects user dashboard experience	1752072418	red	1	1	0	20	t	\N	0	0	0	0	1752072418		0	\N	\N	1	1752072418	0	0	0	0	0	\N	\N	1	\N	\N
22	Bug - Advanced Deployment Settings Missing	Deployment configuration options are not available in admin panel.\n\nMissing features:\n- Environment variable management\n- Feature flags configuration\n- Rollback mechanisms\n- Blue-green deployment settings\n- Auto-scaling configuration\n\nCurrently requires manual intervention	1752072424	orange	1	1	0	21	t	\N	0	0	0	0	1752072424		0	\N	\N	1	1752072424	0	0	0	0	0	\N	\N	1	\N	\N
23	PROJECT STATUS: Itellico Mono - Q1 2025 Roadmap	## Overall Project Status: 85% Core + 40% Advanced Features\n\n### Critical Issues (Priority 3):\n- [ ] Multi-Factor Authentication\n- [ ] Data Retention Policies  \n- [ ] Payment Integration (Stripe)\n\n### Q1 2025 Priorities (Priority 2):\n- [ ] Testing Infrastructure (20% → 80%)\n- [ ] Performance Optimization (60% → 95%)\n- [ ] Advanced Analytics (30% → 80%)\n\n### In Development (Priority 1):\n- [ ] Mobile PWA (40% → 100%)\n- [ ] Social Login Integration\n- [ ] Workflow Automation\n- [ ] Content Approval System\n\n### Metrics:\n- API Endpoints: 190+ implemented\n- Database Models: 40+ tables\n- Admin Modules: 30+ complete\n- Target Users: 700,000+\n\nUpdated weekly. Check individual tasks for details.	1752072482	green	1	1	0	22	t	\N	0	0	0	0	1752072482		0	\N	\N	1	1752072482	0	0	0	0	0	\N	\N	3	\N	\N
4	Implement Multi-Factor Authentication (MFA)	Implement MFA for enhanced security. This is a critical security requirement currently missing from the platform.\n\n## Requirements:\n- Support for TOTP (Time-based One-Time Password)\n- SMS-based authentication as backup\n- Recovery codes generation\n- Integration with existing JWT auth system\n\n## Documentation Links:\n- 📚 Docs: http://localhost:3005/architecture/security/authentication\n- 🎯 Clickdummy: http://localhost:4040/user/settings.php (Security Settings section)\n- 📖 API Design: http://localhost:3005/architecture/api-design\n\n## Tech Stack:\n- Fastify backend\n- speakeasy library for TOTP\n- Redis for temporary code storage\n\n## Subtasks:\n1. Create API endpoints for MFA setup/verify\n2. Update authentication flow documentation\n3. Add MFA UI components to settings page\n4. Create recovery code generation system\n5. Update clickdummy with MFA mockups	1752072285	red	1	1	0	3	t	\N	0	0	0	0	1752072905		0	\N	\N	1	1752072285	0	0	0	0	0	\N	\N	3	\N	\N
24	SUBTASK: Document MFA Implementation Guide	Create comprehensive documentation for Multi-Factor Authentication implementation.\n\n## Parent Task: #4 - Implement Multi-Factor Authentication (MFA)\n\n## Documentation Tasks:\n1. Create `/docs/architecture/security/mfa-implementation.md`\n2. Document API endpoints for MFA\n3. Create user guide for MFA setup\n4. Add MFA flow diagrams\n5. Update authentication.md with MFA details\n\n## Links:\n- 📚 Target: http://localhost:3005/architecture/security/mfa-implementation\n- 🔗 Parent Task: #4\n- 📖 Related: http://localhost:3005/architecture/security/authentication	1752072917	grey	1	1	0	23	t	\N	0	0	0	0	1752072917		0	\N	\N	1	1752072917	0	0	0	0	0	\N	\N	2	\N	\N
6	Payment Integration - Stripe Connect	Implement complete payment system using Stripe Connect for marketplace transactions.\n\n## Requirements:\n- Stripe Connect onboarding for vendors\n- Payment processing for jobs/gigs\n- Escrow system implementation\n- Invoice generation\n- Commission handling\n- Refund mechanisms\n\n## Documentation Links:\n- 📚 Docs: http://localhost:3005/platform/subscription-management\n- 🎯 Clickdummy - User: http://localhost:4040/user/wallet.php\n- 🎯 Clickdummy - Tenant: http://localhost:4040/tenant/finance/payments.php\n- 🎯 Clickdummy - Platform: http://localhost:4040/platform/finance/overview.php\n- 📖 API Design: http://localhost:3005/architecture/api-design\n\n## Implementation Areas:\n1. Platform Level: Global payment settings, commission rates\n2. Tenant Level: Marketplace-specific payment rules\n3. User Level: Wallet, transactions, payouts\n\n## Current Status: 0% complete\nPriority: Critical for marketplace functionality	1752072300	red	1	1	0	5	t	\N	0	0	0	0	1752072928		0	\N	\N	1	1752072300	0	0	0	0	0	\N	\N	3	\N	\N
25	SUBTASK: Create Payment System Documentation	Document the complete payment system architecture and implementation guide.\n\n## Parent Task: #6 - Payment Integration - Stripe Connect\n\n## Documentation Tasks:\n1. Create `/docs/platform/payment-system/stripe-connect.md`\n2. Document payment flow diagrams (platform → tenant → user)\n3. Create API endpoint documentation for payments\n4. Write integration testing guide\n5. Document escrow system design\n6. Create commission calculation guide\n\n## Clickdummy References:\n- User Wallet: http://localhost:4040/user/wallet.php\n- Payment History: http://localhost:4040/user/payment-history.php\n- Tenant Finance: http://localhost:4040/tenant/finance/payments.php\n\n## Links:\n- 📚 Target: http://localhost:3005/platform/payment-system\n- 🔗 Parent Task: #6\n- 📖 Related: http://localhost:3005/platform/subscription-management	1752072939	grey	1	1	0	24	t	\N	0	0	0	0	1752072939		0	\N	\N	1	1752072939	0	0	0	0	0	\N	\N	2	\N	\N
26	SUBTASK: Create Testing Documentation & Examples	Develop comprehensive testing documentation with examples for all test types.\n\n## Parent Task: #7 - Testing Infrastructure - Unit Tests\n\n## Documentation Tasks:\n1. Create `/docs/development/testing/unit-test-guide.md`\n2. Add example tests for each component type\n3. Document testing patterns and anti-patterns\n4. Create test data management guide\n5. Write mock strategy documentation\n6. Add CI/CD testing integration guide\n\n## Example Coverage Areas:\n- Fastify route testing examples\n- Prisma model testing patterns\n- React component testing with RTL\n- Custom hook testing strategies\n- API mocking with MSW\n\n## Links:\n- 📚 Target: http://localhost:3005/development/testing/unit-test-guide\n- 🔗 Parent Task: #7\n- 📖 Related: http://localhost:3005/development/testing/methodology	1752072960	grey	1	1	0	25	t	\N	0	0	0	0	1752072960		0	\N	\N	1	1752072960	0	0	0	0	0	\N	\N	1	\N	\N
17	Frontend - Advanced User Analytics Dashboard	Build comprehensive analytics dashboard for users.\n\n## Components needed:\n- Revenue charts (Chart.js/Recharts)\n- Performance metrics cards\n- Activity timeline\n- Conversion funnel visualization\n- Export functionality\n- Date range filters\n\n## Documentation Links:\n- 📚 Platform Analytics: http://localhost:3005/platform/system-management\n- 🎯 Clickdummy - User: http://localhost:4040/user/analytics/overview.php\n- 🎯 Clickdummy - Account: http://localhost:4040/account/analytics/performance.php\n- 🎯 Clickdummy - Tenant: http://localhost:4040/tenant/analytics/overview.php\n- 📖 Component Patterns: http://localhost:3005/architecture/performance/react-patterns\n\n## Implementation Reference:\n- User Level: Personal performance metrics\n- Account Level: Team/agency analytics\n- Tenant Level: Marketplace-wide analytics\n- Platform Level: Global system analytics\n\n## Currently missing from platform - Priority for user engagement	1752072387	purple	1	1	0	16	t	\N	0	0	0	0	1752072973		0	\N	\N	1	1752072387	0	0	0	0	0	\N	\N	1	\N	\N
27	SUBTASK: Document Analytics Dashboard Architecture	Create documentation for the multi-tier analytics system.\n\n## Parent Task: #17 - Frontend - Advanced User Analytics Dashboard\n\n## Documentation Tasks:\n1. Create `/docs/platform/analytics/dashboard-architecture.md`\n2. Document data flow for each tier's analytics\n3. Create component library for chart types\n4. Write performance optimization guide for large datasets\n5. Document export formats and API endpoints\n6. Add real-time update strategies\n\n## Tier-Specific Documentation:\n- Platform: System-wide metrics and monitoring\n- Tenant: Marketplace performance and trends\n- Account: Team productivity and revenue\n- User: Individual performance tracking\n\n## Clickdummy References:\n- User Analytics: http://localhost:4040/user/analytics/overview.php\n- Account Analytics: http://localhost:4040/account/analytics/performance.php\n- Tenant Analytics: http://localhost:4040/tenant/analytics/overview.php\n- Platform Analytics: http://localhost:4040/platform/analytics/system.php\n\n## Links:\n- 📚 Target: http://localhost:3005/platform/analytics/dashboard-architecture\n- 🔗 Parent Task: #17\n- 📖 Related: http://localhost:3005/architecture/performance/three-layer-caching	1752072988	grey	1	1	0	26	t	\N	0	0	0	0	1752072988		0	\N	\N	1	1752072988	0	0	0	0	0	\N	\N	1	\N	\N
14	Content Approval Workflows	Implement content moderation and approval system.\n\n## Requirements:\n- Multi-level approval chains\n- Role-based review assignments\n- Automated content checks\n- Manual review interface\n- Rejection reasons & feedback\n- Version control for content\n\n## Documentation Links:\n- 📚 Content Management: http://localhost:3005/platform/content-management\n- 📚 RBAC System: http://localhost:3005/platform/access-control/rbac-system\n- 🎯 Clickdummy - Moderation: http://localhost:4040/tenant/content/moderation.php\n- 🎯 Clickdummy - Review Queue: http://localhost:4040/account/content/review-queue.php\n- 📖 Workflow Patterns: http://localhost:3005/architecture/system-design\n\n## Implementation Levels:\n1. Platform: Global content policies, AI moderation rules\n2. Tenant: Marketplace-specific approval workflows\n3. Account: Team review assignments\n4. User: Content submission and revision interface\n\n## Integration Points:\n- Temporal workflow engine for approval chains\n- AI content moderation (text, image analysis)\n- Notification system for reviewers\n- Audit trail for all approval actions\n\n## Missing from current system - affects content quality control	1752072358	yellow	1	1	0	13	t	\N	0	0	0	0	1752073000		0	\N	\N	1	1752072358	0	0	0	0	0	\N	\N	1	\N	\N
28	SUBTASK: Design Content Approval Workflow System	Document the complete content approval and moderation system design.\n\n## Parent Task: #14 - Content Approval Workflows\n\n## Documentation Tasks:\n1. Create `/docs/platform/content-management/approval-workflows.md`\n2. Design approval chain configuration schema\n3. Document AI moderation integration points\n4. Create reviewer interface wireframes\n5. Write notification flow documentation\n6. Design audit trail structure\n\n## Workflow Examples:\n- Job posting approval (User → Account → Tenant)\n- Profile verification (User → Platform moderator)\n- Content flagging system (Community → Tenant admin)\n- Template approval (Tenant → Platform)\n\n## Clickdummy References:\n- Moderation Dashboard: http://localhost:4040/tenant/content/moderation.php\n- Review Queue: http://localhost:4040/account/content/review-queue.php\n- Content Policies: http://localhost:4040/platform/settings/content-policies.php\n\n## Links:\n- 📚 Target: http://localhost:3005/platform/content-management/approval-workflows\n- 🔗 Parent Task: #14\n- 📖 Related: http://localhost:3005/platform/access-control/permission-matrix	1752073011	grey	1	1	0	27	t	\N	0	0	0	0	1752073011		0	\N	\N	1	1752073011	0	0	0	0	0	\N	\N	1	\N	\N
29	TEMPLATE: Standard Task Format with Links	## 📋 Task Template - Use this format for all new tasks\n\n## Overview:\nBrief description of what needs to be implemented.\n\n## Requirements:\n- Requirement 1\n- Requirement 2\n- Requirement 3\n\n## Documentation Links:\n- 📚 Main Docs: http://localhost:3005/[relevant-section]\n- 🎯 Clickdummy: http://localhost:4040/[tier]/[page].php\n- 📖 API Reference: http://localhost:3001/docs#/[endpoint-group]\n- 🔧 Dev Guide: http://localhost:3005/development/[guide]\n\n## Implementation Tiers:\n1. **Platform**: [What platform admins need]\n2. **Tenant**: [What tenant admins need]\n3. **Account**: [What account managers need]\n4. **User**: [What end users need]\n5. **Public**: [What public visitors see]\n\n## Technical Details:\n- Frontend: [Components/pages to create]\n- Backend: [API endpoints needed]\n- Database: [Models/migrations required]\n- Cache: [Redis keys/strategies]\n\n## Related Tasks:\n- Parent: #[parent-task-id]\n- Blocks: #[task-ids-this-blocks]\n- Blocked by: #[task-ids-blocking-this]\n- Related: #[related-task-ids]\n\n## Acceptance Criteria:\n- [ ] Criterion 1\n- [ ] Criterion 2\n- [ ] Tests written and passing\n- [ ] Documentation updated\n\n## Subtasks Required:\n1. Create documentation (#[doc-task-id])\n2. Update clickdummy mockups\n3. Implement API endpoints\n4. Build frontend components\n5. Write tests\n6. Update changelog	1752073028	teal	1	1	0	28	t	\N	0	0	0	0	1752073028		0	\N	\N	1	1752073028	0	0	0	0	0	\N	\N	0	\N	\N
30	REFERENCE: Clickdummy & Documentation Index	## 🗺️ Complete Reference Map for itellico Mono\n\n## Clickdummy URLs (http://localhost:4040)\n\n### Platform Tier (/platform/)\n- Dashboard: /platform/dashboard.php\n- Tenants: /platform/tenants/list.php\n- Features: /platform/features/list.php\n- Analytics: /platform/analytics/system.php\n- Finance: /platform/finance/overview.php\n- Settings: /platform/settings/general.php\n\n### Tenant Tier (/tenant/)\n- Dashboard: /tenant/dashboard.php\n- Accounts: /tenant/accounts/list.php\n- Plans: /tenant/plans/list.php\n- Content: /tenant/content/moderation.php\n- Analytics: /tenant/analytics/overview.php\n- Finance: /tenant/finance/payments.php\n\n### Account Tier (/account/)\n- Dashboard: /account/dashboard.php\n- Team: /account/team/members.php\n- Projects: /account/projects/list.php\n- Analytics: /account/analytics/performance.php\n- Content: /account/content/review-queue.php\n\n### User Tier (/user/)\n- Profile: /user/profile.php\n- Portfolio: /user/portfolio/showcase.php\n- Jobs: /user/jobs/browse.php\n- Messages: /user/messages/inbox.php\n- Wallet: /user/wallet.php\n- Settings: /user/settings.php\n- Analytics: /user/analytics/overview.php\n\n### Public Tier (/public/)\n- Homepage: /public/index.php\n- Marketplace: /public/marketplace/browse.php\n- Job Board: /public/jobs/listings.php\n- Profiles: /public/profiles/search.php\n\n## Documentation Structure (http://localhost:3005)\n\n### Architecture (/architecture/)\n- System Design\n- API Design\n- Data Models\n- Security\n- Performance\n\n### Platform Features (/platform/)\n- Access Control & RBAC\n- Content Management\n- Subscription Management\n- Developer Tools\n- System Management\n\n### Development (/development/)\n- Getting Started\n- Testing\n- Deployment\n- Tools\n- Workflows\n\n## API Documentation\n- Swagger/OpenAPI: http://localhost:3001/docs\n- Postman Collection: /docs/api/postman-collection.json\n\n## Quick Links for Common Tasks:\n1. Add new feature: Check clickdummy → Create API → Build UI → Document\n2. Fix bug: Reproduce in clickdummy → Fix → Test → Update docs\n3. New API endpoint: Design in OpenAPI → Implement → Test → Document\n\n## Task Relationships:\n- Features link to multiple clickdummy pages\n- Each tier has specific documentation sections\n- API endpoints map to clickdummy functionality\n- Tests verify clickdummy behavior matches implementation	1752073051	cyan	1	1	0	29	t	\N	0	0	0	0	1752073051		0	\N	\N	1	1752073051	0	0	0	0	0	\N	\N	3	\N	\N
31	SUBTASK: GDPR Compliance Documentation	Create comprehensive GDPR compliance documentation and implementation guide.\n\n## Parent Task: #5 - Implement Data Retention Policies\n\n## Documentation Tasks:\n1. Create `/docs/architecture/security/gdpr-compliance.md`\n2. Document data retention policy templates\n3. Create user data rights documentation\n4. Write data purging procedures\n5. Design compliance audit checklist\n6. Create privacy policy templates\n\n## Implementation Guides:\n- Right to access (data export)\n- Right to rectification (data updates)\n- Right to erasure (data deletion)\n- Right to portability (data transfer)\n- Consent management system\n\n## Clickdummy References:\n- Platform Compliance: http://localhost:4040/platform/settings/data-retention.php\n- User Privacy: http://localhost:4040/user/settings.php#privacy\n- Data Export: http://localhost:4040/user/settings.php#export-data\n\n## Links:\n- 📚 Target: http://localhost:3005/architecture/security/gdpr-compliance\n- 🔗 Parent Task: #5\n- 📖 Related: http://localhost:3005/platform/system-management/audit-system	1752073077	grey	1	1	0	30	t	\N	0	0	0	0	1752073077		0	\N	\N	1	1752073077	0	0	0	0	0	\N	\N	2	\N	\N
\.


--
-- Data for Name: transitions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.transitions (id, user_id, project_id, task_id, src_column_id, dst_column_id, date, time_spent) FROM stdin;
\.


--
-- Data for Name: user_has_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.user_has_metadata (user_id, name, value, changed_by, changed_on) FROM stdin;
\.


--
-- Data for Name: user_has_notification_types; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.user_has_notification_types (id, user_id, notification_type) FROM stdin;
\.


--
-- Data for Name: user_has_notifications; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.user_has_notifications (user_id, project_id) FROM stdin;
\.


--
-- Data for Name: user_has_unread_notifications; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.user_has_unread_notifications (id, user_id, date_creation, event_name, event_data) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.users (id, username, password, is_ldap_user, name, email, google_id, github_id, notifications_enabled, timezone, language, disable_login_form, twofactor_activated, twofactor_secret, token, notifications_filter, nb_failed_login, lock_expiration_date, gitlab_id, role, is_active, avatar_path, api_access_token, filter, theme) FROM stdin;
1	admin	$2y$10$rJ9jGas8srQP7BuByccgJueXRTAMHMNt8KMNNtfIkYWo/XX86FlZu	f	\N	\N	\N	\N	f	\N	\N	f	f	\N		4	0	0	\N	app-admin	t	\N	\N	\N	light
\.


--
-- Name: action_has_params_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.action_has_params_id_seq', 1, false);


--
-- Name: actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.actions_id_seq', 1, false);


--
-- Name: column_has_move_restrictions_restriction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.column_has_move_restrictions_restriction_id_seq', 1, false);


--
-- Name: column_has_restrictions_restriction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.column_has_restrictions_restriction_id_seq', 1, false);


--
-- Name: columns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.columns_id_seq', 4, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.comments_id_seq', 1, false);


--
-- Name: custom_filters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.custom_filters_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- Name: last_logins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.last_logins_id_seq', 1, true);


--
-- Name: links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.links_id_seq', 11, true);


--
-- Name: predefined_task_descriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.predefined_task_descriptions_id_seq', 1, false);


--
-- Name: project_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_activities_id_seq', 1, false);


--
-- Name: project_daily_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_daily_stats_id_seq', 37, true);


--
-- Name: project_daily_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_daily_summaries_id_seq', 37, true);


--
-- Name: project_has_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_has_categories_id_seq', 1, false);


--
-- Name: project_has_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_has_files_id_seq', 1, false);


--
-- Name: project_has_notification_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_has_notification_types_id_seq', 1, false);


--
-- Name: project_has_roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_has_roles_role_id_seq', 1, false);


--
-- Name: project_role_has_restrictions_restriction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_role_has_restrictions_restriction_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, true);


--
-- Name: remember_me_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.remember_me_id_seq', 1, true);


--
-- Name: subtask_time_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.subtask_time_tracking_id_seq', 1, false);


--
-- Name: swimlanes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.swimlanes_id_seq', 1, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.tags_id_seq', 29, true);


--
-- Name: task_has_external_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.task_has_external_links_id_seq', 1, false);


--
-- Name: task_has_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.task_has_files_id_seq', 1, false);


--
-- Name: task_has_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.task_has_links_id_seq', 1, false);


--
-- Name: task_has_subtasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.task_has_subtasks_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.tasks_id_seq', 31, true);


--
-- Name: transitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.transitions_id_seq', 1, false);


--
-- Name: user_has_notification_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.user_has_notification_types_id_seq', 1, false);


--
-- Name: user_has_unread_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.user_has_unread_notifications_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: action_has_params action_has_params_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.action_has_params
    ADD CONSTRAINT action_has_params_pkey PRIMARY KEY (id);


--
-- Name: actions actions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_pkey PRIMARY KEY (id);


--
-- Name: column_has_move_restrictions column_has_move_restrictions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_pkey PRIMARY KEY (restriction_id);


--
-- Name: column_has_move_restrictions column_has_move_restrictions_role_id_src_column_id_dst_colu_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_role_id_src_column_id_dst_colu_key UNIQUE (role_id, src_column_id, dst_column_id);


--
-- Name: column_has_restrictions column_has_restrictions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions
    ADD CONSTRAINT column_has_restrictions_pkey PRIMARY KEY (restriction_id);


--
-- Name: column_has_restrictions column_has_restrictions_role_id_column_id_rule_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions
    ADD CONSTRAINT column_has_restrictions_role_id_column_id_rule_key UNIQUE (role_id, column_id, rule);


--
-- Name: columns columns_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.columns
    ADD CONSTRAINT columns_pkey PRIMARY KEY (id);


--
-- Name: columns columns_title_project_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.columns
    ADD CONSTRAINT columns_title_project_id_key UNIQUE (title, project_id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_currency_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_currency_key UNIQUE (currency);


--
-- Name: custom_filters custom_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.custom_filters
    ADD CONSTRAINT custom_filters_pkey PRIMARY KEY (id);


--
-- Name: group_has_users group_has_users_group_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.group_has_users
    ADD CONSTRAINT group_has_users_group_id_user_id_key UNIQUE (group_id, user_id);


--
-- Name: groups groups_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_name_key UNIQUE (name);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: invites invites_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_pkey PRIMARY KEY (email, token);


--
-- Name: last_logins last_logins_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.last_logins
    ADD CONSTRAINT last_logins_pkey PRIMARY KEY (id);


--
-- Name: links links_label_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_label_key UNIQUE (label);


--
-- Name: links links_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_pkey PRIMARY KEY (id);


--
-- Name: password_reset password_reset_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.password_reset
    ADD CONSTRAINT password_reset_pkey PRIMARY KEY (token);


--
-- Name: plugin_schema_versions plugin_schema_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.plugin_schema_versions
    ADD CONSTRAINT plugin_schema_versions_pkey PRIMARY KEY (plugin);


--
-- Name: predefined_task_descriptions predefined_task_descriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.predefined_task_descriptions
    ADD CONSTRAINT predefined_task_descriptions_pkey PRIMARY KEY (id);


--
-- Name: project_activities project_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_activities
    ADD CONSTRAINT project_activities_pkey PRIMARY KEY (id);


--
-- Name: project_daily_stats project_daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_stats
    ADD CONSTRAINT project_daily_stats_pkey PRIMARY KEY (id);


--
-- Name: project_daily_column_stats project_daily_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_column_stats
    ADD CONSTRAINT project_daily_summaries_pkey PRIMARY KEY (id);


--
-- Name: project_has_categories project_has_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_categories
    ADD CONSTRAINT project_has_categories_pkey PRIMARY KEY (id);


--
-- Name: project_has_categories project_has_categories_project_id_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_categories
    ADD CONSTRAINT project_has_categories_project_id_name_key UNIQUE (project_id, name);


--
-- Name: project_has_files project_has_files_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_files
    ADD CONSTRAINT project_has_files_pkey PRIMARY KEY (id);


--
-- Name: project_has_groups project_has_groups_group_id_project_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_groups
    ADD CONSTRAINT project_has_groups_group_id_project_id_key UNIQUE (group_id, project_id);


--
-- Name: project_has_metadata project_has_metadata_project_id_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_metadata
    ADD CONSTRAINT project_has_metadata_project_id_name_key UNIQUE (project_id, name);


--
-- Name: project_has_notification_types project_has_notification_types_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_notification_types
    ADD CONSTRAINT project_has_notification_types_pkey PRIMARY KEY (id);


--
-- Name: project_has_notification_types project_has_notification_types_project_id_notification_type_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_notification_types
    ADD CONSTRAINT project_has_notification_types_project_id_notification_type_key UNIQUE (project_id, notification_type);


--
-- Name: project_has_roles project_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_roles
    ADD CONSTRAINT project_has_roles_pkey PRIMARY KEY (role_id);


--
-- Name: project_has_roles project_has_roles_project_id_role_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_roles
    ADD CONSTRAINT project_has_roles_project_id_role_key UNIQUE (project_id, role);


--
-- Name: project_has_users project_has_users_project_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_users
    ADD CONSTRAINT project_has_users_project_id_user_id_key UNIQUE (project_id, user_id);


--
-- Name: project_role_has_restrictions project_role_has_restrictions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_role_has_restrictions
    ADD CONSTRAINT project_role_has_restrictions_pkey PRIMARY KEY (restriction_id);


--
-- Name: project_role_has_restrictions project_role_has_restrictions_role_id_rule_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_role_has_restrictions
    ADD CONSTRAINT project_role_has_restrictions_role_id_rule_key UNIQUE (role_id, rule);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: remember_me remember_me_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.remember_me
    ADD CONSTRAINT remember_me_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (option);


--
-- Name: subtask_time_tracking subtask_time_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtask_time_tracking
    ADD CONSTRAINT subtask_time_tracking_pkey PRIMARY KEY (id);


--
-- Name: swimlanes swimlanes_name_project_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.swimlanes
    ADD CONSTRAINT swimlanes_name_project_id_key UNIQUE (name, project_id);


--
-- Name: swimlanes swimlanes_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.swimlanes
    ADD CONSTRAINT swimlanes_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_project_id_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_project_id_name_key UNIQUE (project_id, name);


--
-- Name: task_has_external_links task_has_external_links_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_external_links
    ADD CONSTRAINT task_has_external_links_pkey PRIMARY KEY (id);


--
-- Name: task_has_files task_has_files_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_files
    ADD CONSTRAINT task_has_files_pkey PRIMARY KEY (id);


--
-- Name: task_has_links task_has_links_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_links
    ADD CONSTRAINT task_has_links_pkey PRIMARY KEY (id);


--
-- Name: task_has_metadata task_has_metadata_task_id_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_metadata
    ADD CONSTRAINT task_has_metadata_task_id_name_key UNIQUE (task_id, name);


--
-- Name: subtasks task_has_subtasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtasks
    ADD CONSTRAINT task_has_subtasks_pkey PRIMARY KEY (id);


--
-- Name: task_has_tags task_has_tags_tag_id_task_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_tags
    ADD CONSTRAINT task_has_tags_tag_id_task_id_key UNIQUE (tag_id, task_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: transitions transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_pkey PRIMARY KEY (id);


--
-- Name: user_has_metadata user_has_metadata_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_metadata
    ADD CONSTRAINT user_has_metadata_user_id_name_key UNIQUE (user_id, name);


--
-- Name: user_has_notification_types user_has_notification_types_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notification_types
    ADD CONSTRAINT user_has_notification_types_pkey PRIMARY KEY (id);


--
-- Name: user_has_notifications user_has_notifications_project_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notifications
    ADD CONSTRAINT user_has_notifications_project_id_user_id_key UNIQUE (project_id, user_id);


--
-- Name: user_has_unread_notifications user_has_unread_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_unread_notifications
    ADD CONSTRAINT user_has_unread_notifications_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: categories_project_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX categories_project_idx ON public.project_has_categories USING btree (project_id);


--
-- Name: columns_project_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX columns_project_idx ON public.columns USING btree (project_id);


--
-- Name: comments_reference_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX comments_reference_idx ON public.comments USING btree (reference);


--
-- Name: comments_task_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX comments_task_idx ON public.comments USING btree (task_id);


--
-- Name: files_task_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX files_task_idx ON public.task_has_files USING btree (task_id);


--
-- Name: project_daily_column_stats_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX project_daily_column_stats_idx ON public.project_daily_column_stats USING btree (day, project_id, column_id);


--
-- Name: project_daily_stats_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX project_daily_stats_idx ON public.project_daily_stats USING btree (day, project_id);


--
-- Name: subtasks_task_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX subtasks_task_idx ON public.subtasks USING btree (task_id);


--
-- Name: swimlanes_project_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX swimlanes_project_idx ON public.swimlanes USING btree (project_id);


--
-- Name: task_has_links_task_index; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX task_has_links_task_index ON public.task_has_links USING btree (task_id);


--
-- Name: task_has_links_unique; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX task_has_links_unique ON public.task_has_links USING btree (link_id, task_id, opposite_task_id);


--
-- Name: tasks_project_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX tasks_project_idx ON public.tasks USING btree (project_id);


--
-- Name: tasks_reference_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX tasks_reference_idx ON public.tasks USING btree (reference);


--
-- Name: transitions_project_index; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX transitions_project_index ON public.transitions USING btree (project_id);


--
-- Name: transitions_task_index; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX transitions_task_index ON public.transitions USING btree (task_id);


--
-- Name: transitions_user_index; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX transitions_user_index ON public.transitions USING btree (user_id);


--
-- Name: user_has_notification_types_user_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX user_has_notification_types_user_idx ON public.user_has_notification_types USING btree (user_id, notification_type);


--
-- Name: users_username_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX users_username_idx ON public.users USING btree (username);


--
-- Name: action_has_params action_has_params_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.action_has_params
    ADD CONSTRAINT action_has_params_action_id_fkey FOREIGN KEY (action_id) REFERENCES public.actions(id) ON DELETE CASCADE;


--
-- Name: actions actions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: column_has_move_restrictions column_has_move_restrictions_dst_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_dst_column_id_fkey FOREIGN KEY (dst_column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: column_has_move_restrictions column_has_move_restrictions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: column_has_move_restrictions column_has_move_restrictions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.project_has_roles(role_id) ON DELETE CASCADE;


--
-- Name: column_has_move_restrictions column_has_move_restrictions_src_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_src_column_id_fkey FOREIGN KEY (src_column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: column_has_restrictions column_has_restrictions_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions
    ADD CONSTRAINT column_has_restrictions_column_id_fkey FOREIGN KEY (column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: column_has_restrictions column_has_restrictions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions
    ADD CONSTRAINT column_has_restrictions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: column_has_restrictions column_has_restrictions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions
    ADD CONSTRAINT column_has_restrictions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.project_has_roles(role_id) ON DELETE CASCADE;


--
-- Name: columns columns_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.columns
    ADD CONSTRAINT columns_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: comments comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: group_has_users group_has_users_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.group_has_users
    ADD CONSTRAINT group_has_users_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_has_users group_has_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.group_has_users
    ADD CONSTRAINT group_has_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: last_logins last_logins_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.last_logins
    ADD CONSTRAINT last_logins_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset password_reset_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.password_reset
    ADD CONSTRAINT password_reset_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: predefined_task_descriptions predefined_task_descriptions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.predefined_task_descriptions
    ADD CONSTRAINT predefined_task_descriptions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_activities project_activities_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_activities
    ADD CONSTRAINT project_activities_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: project_activities project_activities_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_activities
    ADD CONSTRAINT project_activities_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_activities project_activities_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_activities
    ADD CONSTRAINT project_activities_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: project_daily_stats project_daily_stats_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_stats
    ADD CONSTRAINT project_daily_stats_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_daily_column_stats project_daily_summaries_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_column_stats
    ADD CONSTRAINT project_daily_summaries_column_id_fkey FOREIGN KEY (column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: project_daily_column_stats project_daily_summaries_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_column_stats
    ADD CONSTRAINT project_daily_summaries_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_categories project_has_categories_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_categories
    ADD CONSTRAINT project_has_categories_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_files project_has_files_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_files
    ADD CONSTRAINT project_has_files_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_groups project_has_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_groups
    ADD CONSTRAINT project_has_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: project_has_groups project_has_groups_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_groups
    ADD CONSTRAINT project_has_groups_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_metadata project_has_metadata_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_metadata
    ADD CONSTRAINT project_has_metadata_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_notification_types project_has_notification_types_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_notification_types
    ADD CONSTRAINT project_has_notification_types_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_roles project_has_roles_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_roles
    ADD CONSTRAINT project_has_roles_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_users project_has_users_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_users
    ADD CONSTRAINT project_has_users_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_users project_has_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_users
    ADD CONSTRAINT project_has_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: project_role_has_restrictions project_role_has_restrictions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_role_has_restrictions
    ADD CONSTRAINT project_role_has_restrictions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_role_has_restrictions project_role_has_restrictions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_role_has_restrictions
    ADD CONSTRAINT project_role_has_restrictions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.project_has_roles(role_id) ON DELETE CASCADE;


--
-- Name: remember_me remember_me_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.remember_me
    ADD CONSTRAINT remember_me_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subtask_time_tracking subtask_time_tracking_subtask_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtask_time_tracking
    ADD CONSTRAINT subtask_time_tracking_subtask_id_fkey FOREIGN KEY (subtask_id) REFERENCES public.subtasks(id) ON DELETE CASCADE;


--
-- Name: subtask_time_tracking subtask_time_tracking_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtask_time_tracking
    ADD CONSTRAINT subtask_time_tracking_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: swimlanes swimlanes_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.swimlanes
    ADD CONSTRAINT swimlanes_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: task_has_external_links task_has_external_links_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_external_links
    ADD CONSTRAINT task_has_external_links_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_has_files task_has_files_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_files
    ADD CONSTRAINT task_has_files_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_has_links task_has_links_link_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_links
    ADD CONSTRAINT task_has_links_link_id_fkey FOREIGN KEY (link_id) REFERENCES public.links(id) ON DELETE CASCADE;


--
-- Name: task_has_links task_has_links_opposite_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_links
    ADD CONSTRAINT task_has_links_opposite_task_id_fkey FOREIGN KEY (opposite_task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_has_links task_has_links_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_links
    ADD CONSTRAINT task_has_links_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_has_metadata task_has_metadata_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_metadata
    ADD CONSTRAINT task_has_metadata_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: subtasks task_has_subtasks_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtasks
    ADD CONSTRAINT task_has_subtasks_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_has_tags task_has_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_tags
    ADD CONSTRAINT task_has_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: task_has_tags task_has_tags_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_tags
    ADD CONSTRAINT task_has_tags_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_column_id_fkey FOREIGN KEY (column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_swimlane_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_swimlane_id_fkey FOREIGN KEY (swimlane_id) REFERENCES public.swimlanes(id) ON DELETE CASCADE;


--
-- Name: transitions transitions_dst_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_dst_column_id_fkey FOREIGN KEY (dst_column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: transitions transitions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: transitions transitions_src_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_src_column_id_fkey FOREIGN KEY (src_column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: transitions transitions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: transitions transitions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_has_metadata user_has_metadata_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_metadata
    ADD CONSTRAINT user_has_metadata_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_has_notification_types user_has_notification_types_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notification_types
    ADD CONSTRAINT user_has_notification_types_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_has_notifications user_has_notifications_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notifications
    ADD CONSTRAINT user_has_notifications_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: user_has_notifications user_has_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notifications
    ADD CONSTRAINT user_has_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_has_unread_notifications user_has_unread_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_unread_notifications
    ADD CONSTRAINT user_has_unread_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

--
-- Database "mono" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: mono; Type: DATABASE; Schema: -; Owner: developer
--

CREATE DATABASE mono WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE mono OWNER TO developer;

\connect mono

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "n8n" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: n8n; Type: DATABASE; Schema: -; Owner: developer
--

CREATE DATABASE n8n WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE n8n OWNER TO developer;

\connect n8n

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: annotation_tag_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.annotation_tag_entity (
    id character varying(16) NOT NULL,
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.annotation_tag_entity OWNER TO developer;

--
-- Name: auth_identity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.auth_identity (
    "userId" uuid,
    "providerId" character varying(64) NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.auth_identity OWNER TO developer;

--
-- Name: auth_provider_sync_history; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.auth_provider_sync_history (
    id integer NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "runMode" text NOT NULL,
    status text NOT NULL,
    "startedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    scanned integer NOT NULL,
    created integer NOT NULL,
    updated integer NOT NULL,
    disabled integer NOT NULL,
    error text
);


ALTER TABLE public.auth_provider_sync_history OWNER TO developer;

--
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.auth_provider_sync_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_provider_sync_history_id_seq OWNER TO developer;

--
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.auth_provider_sync_history_id_seq OWNED BY public.auth_provider_sync_history.id;


--
-- Name: credentials_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.credentials_entity (
    name character varying(128) NOT NULL,
    data text NOT NULL,
    type character varying(128) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL,
    "isManaged" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.credentials_entity OWNER TO developer;

--
-- Name: event_destinations; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.event_destinations (
    id uuid NOT NULL,
    destination jsonb NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.event_destinations OWNER TO developer;

--
-- Name: execution_annotation_tags; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.execution_annotation_tags (
    "annotationId" integer NOT NULL,
    "tagId" character varying(24) NOT NULL
);


ALTER TABLE public.execution_annotation_tags OWNER TO developer;

--
-- Name: execution_annotations; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.execution_annotations (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    vote character varying(6),
    note text,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.execution_annotations OWNER TO developer;

--
-- Name: execution_annotations_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.execution_annotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.execution_annotations_id_seq OWNER TO developer;

--
-- Name: execution_annotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.execution_annotations_id_seq OWNED BY public.execution_annotations.id;


--
-- Name: execution_data; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.execution_data (
    "executionId" integer NOT NULL,
    "workflowData" json NOT NULL,
    data text NOT NULL
);


ALTER TABLE public.execution_data OWNER TO developer;

--
-- Name: execution_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.execution_entity (
    id integer NOT NULL,
    finished boolean NOT NULL,
    mode character varying NOT NULL,
    "retryOf" character varying,
    "retrySuccessId" character varying,
    "startedAt" timestamp(3) with time zone,
    "stoppedAt" timestamp(3) with time zone,
    "waitTill" timestamp(3) with time zone,
    status character varying NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "deletedAt" timestamp(3) with time zone,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.execution_entity OWNER TO developer;

--
-- Name: execution_entity_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.execution_entity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.execution_entity_id_seq OWNER TO developer;

--
-- Name: execution_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.execution_entity_id_seq OWNED BY public.execution_entity.id;


--
-- Name: execution_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.execution_metadata (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.execution_metadata OWNER TO developer;

--
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.execution_metadata_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.execution_metadata_temp_id_seq OWNER TO developer;

--
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.execution_metadata_temp_id_seq OWNED BY public.execution_metadata.id;


--
-- Name: folder; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.folder (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    "parentFolderId" character varying(36),
    "projectId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.folder OWNER TO developer;

--
-- Name: folder_tag; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.folder_tag (
    "folderId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


ALTER TABLE public.folder_tag OWNER TO developer;

--
-- Name: insights_by_period; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.insights_by_period (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "periodUnit" integer NOT NULL,
    "periodStart" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.insights_by_period OWNER TO developer;

--
-- Name: COLUMN insights_by_period.type; Type: COMMENT; Schema: public; Owner: developer
--

COMMENT ON COLUMN public.insights_by_period.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- Name: COLUMN insights_by_period."periodUnit"; Type: COMMENT; Schema: public; Owner: developer
--

COMMENT ON COLUMN public.insights_by_period."periodUnit" IS '0: hour, 1: day, 2: week';


--
-- Name: insights_by_period_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

ALTER TABLE public.insights_by_period ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.insights_by_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: insights_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.insights_metadata (
    "metaId" integer NOT NULL,
    "workflowId" character varying(16),
    "projectId" character varying(36),
    "workflowName" character varying(128) NOT NULL,
    "projectName" character varying(255) NOT NULL
);


ALTER TABLE public.insights_metadata OWNER TO developer;

--
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

ALTER TABLE public.insights_metadata ALTER COLUMN "metaId" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."insights_metadata_metaId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: insights_raw; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.insights_raw (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "timestamp" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.insights_raw OWNER TO developer;

--
-- Name: COLUMN insights_raw.type; Type: COMMENT; Schema: public; Owner: developer
--

COMMENT ON COLUMN public.insights_raw.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- Name: insights_raw_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

ALTER TABLE public.insights_raw ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.insights_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: installed_nodes; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.installed_nodes (
    name character varying(200) NOT NULL,
    type character varying(200) NOT NULL,
    "latestVersion" integer DEFAULT 1 NOT NULL,
    package character varying(241) NOT NULL
);


ALTER TABLE public.installed_nodes OWNER TO developer;

--
-- Name: installed_packages; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.installed_packages (
    "packageName" character varying(214) NOT NULL,
    "installedVersion" character varying(50) NOT NULL,
    "authorName" character varying(70),
    "authorEmail" character varying(70),
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.installed_packages OWNER TO developer;

--
-- Name: invalid_auth_token; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.invalid_auth_token (
    token character varying(512) NOT NULL,
    "expiresAt" timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.invalid_auth_token OWNER TO developer;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO developer;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO developer;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: processed_data; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.processed_data (
    "workflowId" character varying(36) NOT NULL,
    context character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.processed_data OWNER TO developer;

--
-- Name: project; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    icon json,
    description character varying(512)
);


ALTER TABLE public.project OWNER TO developer;

--
-- Name: project_relation; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_relation (
    "projectId" character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    role character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.project_relation OWNER TO developer;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.settings (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    "loadOnStartup" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.settings OWNER TO developer;

--
-- Name: shared_credentials; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.shared_credentials (
    "credentialsId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.shared_credentials OWNER TO developer;

--
-- Name: shared_workflow; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.shared_workflow (
    "workflowId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.shared_workflow OWNER TO developer;

--
-- Name: tag_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.tag_entity (
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL
);


ALTER TABLE public.tag_entity OWNER TO developer;

--
-- Name: test_case_execution; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.test_case_execution (
    id character varying(36) NOT NULL,
    "testRunId" character varying(36) NOT NULL,
    "executionId" integer,
    status character varying NOT NULL,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    "errorCode" character varying,
    "errorDetails" json,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.test_case_execution OWNER TO developer;

--
-- Name: test_run; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.test_run (
    id character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    status character varying NOT NULL,
    "errorCode" character varying,
    "errorDetails" json,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.test_run OWNER TO developer;

--
-- Name: user; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public."user" (
    id uuid DEFAULT uuid_in((OVERLAY(OVERLAY(md5((((random())::text || ':'::text) || (clock_timestamp())::text)) PLACING '4'::text FROM 13) PLACING to_hex((floor(((random() * (((11 - 8) + 1))::double precision) + (8)::double precision)))::integer) FROM 17))::cstring) NOT NULL,
    email character varying(255),
    "firstName" character varying(32),
    "lastName" character varying(32),
    password character varying(255),
    "personalizationAnswers" json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    disabled boolean DEFAULT false NOT NULL,
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "mfaSecret" text,
    "mfaRecoveryCodes" text,
    role text NOT NULL
);


ALTER TABLE public."user" OWNER TO developer;

--
-- Name: user_api_keys; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.user_api_keys (
    id character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    label character varying(100) NOT NULL,
    "apiKey" character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    scopes json
);


ALTER TABLE public.user_api_keys OWNER TO developer;

--
-- Name: variables; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.variables (
    key character varying(50) NOT NULL,
    type character varying(50) DEFAULT 'string'::character varying NOT NULL,
    value character varying(255),
    id character varying(36) NOT NULL
);


ALTER TABLE public.variables OWNER TO developer;

--
-- Name: webhook_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.webhook_entity (
    "webhookPath" character varying NOT NULL,
    method character varying NOT NULL,
    node character varying NOT NULL,
    "webhookId" character varying,
    "pathLength" integer,
    "workflowId" character varying(36) NOT NULL
);


ALTER TABLE public.webhook_entity OWNER TO developer;

--
-- Name: workflow_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.workflow_entity (
    name character varying(128) NOT NULL,
    active boolean NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    "staticData" json,
    "pinData" json,
    "versionId" character(36),
    "triggerCount" integer DEFAULT 0 NOT NULL,
    id character varying(36) NOT NULL,
    meta json,
    "parentFolderId" character varying(36) DEFAULT NULL::character varying,
    "isArchived" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.workflow_entity OWNER TO developer;

--
-- Name: workflow_history; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.workflow_history (
    "versionId" character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    authors character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL
);


ALTER TABLE public.workflow_history OWNER TO developer;

--
-- Name: workflow_statistics; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.workflow_statistics (
    count integer DEFAULT 0,
    "latestEvent" timestamp(3) with time zone,
    name character varying(128) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "rootCount" integer DEFAULT 0
);


ALTER TABLE public.workflow_statistics OWNER TO developer;

--
-- Name: workflows_tags; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.workflows_tags (
    "workflowId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


ALTER TABLE public.workflows_tags OWNER TO developer;

--
-- Name: auth_provider_sync_history id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.auth_provider_sync_history ALTER COLUMN id SET DEFAULT nextval('public.auth_provider_sync_history_id_seq'::regclass);


--
-- Name: execution_annotations id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotations ALTER COLUMN id SET DEFAULT nextval('public.execution_annotations_id_seq'::regclass);


--
-- Name: execution_entity id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_entity ALTER COLUMN id SET DEFAULT nextval('public.execution_entity_id_seq'::regclass);


--
-- Name: execution_metadata id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_metadata ALTER COLUMN id SET DEFAULT nextval('public.execution_metadata_temp_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: annotation_tag_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.annotation_tag_entity (id, name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: auth_identity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.auth_identity ("userId", "providerId", "providerType", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: auth_provider_sync_history; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.auth_provider_sync_history (id, "providerType", "runMode", status, "startedAt", "endedAt", scanned, created, updated, disabled, error) FROM stdin;
\.


--
-- Data for Name: credentials_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.credentials_entity (name, data, type, "createdAt", "updatedAt", id, "isManaged") FROM stdin;
\.


--
-- Data for Name: event_destinations; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.event_destinations (id, destination, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: execution_annotation_tags; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.execution_annotation_tags ("annotationId", "tagId") FROM stdin;
\.


--
-- Data for Name: execution_annotations; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.execution_annotations (id, "executionId", vote, note, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: execution_data; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.execution_data ("executionId", "workflowData", data) FROM stdin;
\.


--
-- Data for Name: execution_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.execution_entity (id, finished, mode, "retryOf", "retrySuccessId", "startedAt", "stoppedAt", "waitTill", status, "workflowId", "deletedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: execution_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.execution_metadata (id, "executionId", key, value) FROM stdin;
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.folder (id, name, "parentFolderId", "projectId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: folder_tag; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.folder_tag ("folderId", "tagId") FROM stdin;
\.


--
-- Data for Name: insights_by_period; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.insights_by_period (id, "metaId", type, value, "periodUnit", "periodStart") FROM stdin;
\.


--
-- Data for Name: insights_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.insights_metadata ("metaId", "workflowId", "projectId", "workflowName", "projectName") FROM stdin;
\.


--
-- Data for Name: insights_raw; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.insights_raw (id, "metaId", type, value, "timestamp") FROM stdin;
\.


--
-- Data for Name: installed_nodes; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.installed_nodes (name, type, "latestVersion", package) FROM stdin;
\.


--
-- Data for Name: installed_packages; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.installed_packages ("packageName", "installedVersion", "authorName", "authorEmail", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invalid_auth_token; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.invalid_auth_token (token, "expiresAt") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
1	1587669153312	InitialMigration1587669153312
2	1589476000887	WebhookModel1589476000887
3	1594828256133	CreateIndexStoppedAt1594828256133
4	1607431743768	MakeStoppedAtNullable1607431743768
5	1611144599516	AddWebhookId1611144599516
6	1617270242566	CreateTagEntity1617270242566
7	1620824779533	UniqueWorkflowNames1620824779533
8	1626176912946	AddwaitTill1626176912946
9	1630419189837	UpdateWorkflowCredentials1630419189837
10	1644422880309	AddExecutionEntityIndexes1644422880309
11	1646834195327	IncreaseTypeVarcharLimit1646834195327
12	1646992772331	CreateUserManagement1646992772331
13	1648740597343	LowerCaseUserEmail1648740597343
14	1652254514002	CommunityNodes1652254514002
15	1652367743993	AddUserSettings1652367743993
16	1652905585850	AddAPIKeyColumn1652905585850
17	1654090467022	IntroducePinData1654090467022
18	1658932090381	AddNodeIds1658932090381
19	1659902242948	AddJsonKeyPinData1659902242948
20	1660062385367	CreateCredentialsUserRole1660062385367
21	1663755770893	CreateWorkflowsEditorRole1663755770893
22	1664196174001	WorkflowStatistics1664196174001
23	1665484192212	CreateCredentialUsageTable1665484192212
24	1665754637025	RemoveCredentialUsageTable1665754637025
25	1669739707126	AddWorkflowVersionIdColumn1669739707126
26	1669823906995	AddTriggerCountColumn1669823906995
27	1671535397530	MessageEventBusDestinations1671535397530
28	1671726148421	RemoveWorkflowDataLoadedFlag1671726148421
29	1673268682475	DeleteExecutionsWithWorkflows1673268682475
30	1674138566000	AddStatusToExecutions1674138566000
31	1674509946020	CreateLdapEntities1674509946020
32	1675940580449	PurgeInvalidWorkflowConnections1675940580449
33	1676996103000	MigrateExecutionStatus1676996103000
34	1677236854063	UpdateRunningExecutionStatus1677236854063
35	1677501636754	CreateVariables1677501636754
36	1679416281778	CreateExecutionMetadataTable1679416281778
37	1681134145996	AddUserActivatedProperty1681134145996
38	1681134145997	RemoveSkipOwnerSetup1681134145997
39	1690000000000	MigrateIntegerKeysToString1690000000000
40	1690000000020	SeparateExecutionData1690000000020
41	1690000000030	RemoveResetPasswordColumns1690000000030
42	1690000000030	AddMfaColumns1690000000030
43	1690787606731	AddMissingPrimaryKeyOnExecutionData1690787606731
44	1691088862123	CreateWorkflowNameIndex1691088862123
45	1692967111175	CreateWorkflowHistoryTable1692967111175
46	1693491613982	ExecutionSoftDelete1693491613982
47	1693554410387	DisallowOrphanExecutions1693554410387
48	1694091729095	MigrateToTimestampTz1694091729095
49	1695128658538	AddWorkflowMetadata1695128658538
50	1695829275184	ModifyWorkflowHistoryNodesAndConnections1695829275184
51	1700571993961	AddGlobalAdminRole1700571993961
52	1705429061930	DropRoleMapping1705429061930
53	1711018413374	RemoveFailedExecutionStatus1711018413374
54	1711390882123	MoveSshKeysToDatabase1711390882123
55	1712044305787	RemoveNodesAccess1712044305787
56	1714133768519	CreateProject1714133768519
57	1714133768521	MakeExecutionStatusNonNullable1714133768521
58	1717498465931	AddActivatedAtUserSetting1717498465931
59	1720101653148	AddConstraintToExecutionMetadata1720101653148
60	1721377157740	FixExecutionMetadataSequence1721377157740
61	1723627610222	CreateInvalidAuthTokenTable1723627610222
62	1723796243146	RefactorExecutionIndices1723796243146
63	1724753530828	CreateAnnotationTables1724753530828
64	1724951148974	AddApiKeysTable1724951148974
65	1726606152711	CreateProcessedDataTable1726606152711
66	1727427440136	SeparateExecutionCreationFromStart1727427440136
67	1728659839644	AddMissingPrimaryKeyOnAnnotationTagMapping1728659839644
68	1729607673464	UpdateProcessedDataValueColumnToText1729607673464
69	1729607673469	AddProjectIcons1729607673469
70	1730386903556	CreateTestDefinitionTable1730386903556
71	1731404028106	AddDescriptionToTestDefinition1731404028106
72	1731582748663	MigrateTestDefinitionKeyToString1731582748663
73	1732271325258	CreateTestMetricTable1732271325258
74	1732549866705	CreateTestRun1732549866705
75	1733133775640	AddMockedNodesColumnToTestDefinition1733133775640
76	1734479635324	AddManagedColumnToCredentialsTable1734479635324
77	1736172058779	AddStatsColumnsToTestRun1736172058779
78	1736947513045	CreateTestCaseExecutionTable1736947513045
79	1737715421462	AddErrorColumnsToTestRuns1737715421462
80	1738709609940	CreateFolderTable1738709609940
81	1739549398681	CreateAnalyticsTables1739549398681
82	1740445074052	UpdateParentFolderIdColumn1740445074052
83	1741167584277	RenameAnalyticsToInsights1741167584277
84	1742918400000	AddScopesColumnToApiKeys1742918400000
85	1745322634000	ClearEvaluation1745322634000
86	1745587087521	AddWorkflowStatisticsRootCount1745587087521
87	1745934666076	AddWorkflowArchivedColumn1745934666076
88	1745934666077	DropRoleTable1745934666077
89	1747824239000	AddProjectDescriptionColumn1747824239000
\.


--
-- Data for Name: processed_data; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.processed_data ("workflowId", context, "createdAt", "updatedAt", value) FROM stdin;
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project (id, name, type, "createdAt", "updatedAt", icon, description) FROM stdin;
XD4y1Txvf8MBeyvs	itellico gmbh <m@itellico.at>	personal	2025-07-09 06:46:10.312+00	2025-07-09 14:56:55.874+00	\N	\N
\.


--
-- Data for Name: project_relation; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_relation ("projectId", "userId", role, "createdAt", "updatedAt") FROM stdin;
XD4y1Txvf8MBeyvs	9a95718c-b8e2-47d7-877f-0c124a281de4	project:personalOwner	2025-07-09 06:46:10.312+00	2025-07-09 06:46:10.312+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.settings (key, value, "loadOnStartup") FROM stdin;
ui.banners.dismissed	["V1"]	t
features.ldap	{"loginEnabled":false,"loginLabel":"","connectionUrl":"","allowUnauthorizedCerts":false,"connectionSecurity":"none","connectionPort":389,"baseDn":"","bindingAdminDn":"","bindingAdminPassword":"","firstNameAttribute":"","lastNameAttribute":"","emailAttribute":"","loginIdAttribute":"","ldapIdAttribute":"","userFilter":"","synchronizationEnabled":false,"synchronizationInterval":60,"searchPageSize":0,"searchTimeout":60}	t
userManagement.isInstanceOwnerSetUp	true	t
\.


--
-- Data for Name: shared_credentials; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.shared_credentials ("credentialsId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: shared_workflow; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.shared_workflow ("workflowId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tag_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.tag_entity (name, "createdAt", "updatedAt", id) FROM stdin;
\.


--
-- Data for Name: test_case_execution; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.test_case_execution (id, "testRunId", "executionId", status, "runAt", "completedAt", "errorCode", "errorDetails", metrics, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: test_run; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.test_run (id, "workflowId", status, "errorCode", "errorDetails", "runAt", "completedAt", metrics, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public."user" (id, email, "firstName", "lastName", password, "personalizationAnswers", "createdAt", "updatedAt", settings, disabled, "mfaEnabled", "mfaSecret", "mfaRecoveryCodes", role) FROM stdin;
9a95718c-b8e2-47d7-877f-0c124a281de4	m@itellico.at	itellico	gmbh	$2a$10$uESYLYGqIVK.b1H.hpXFOOi86o6ziMdZehXaHq/ZUYNLK6BogFVCO	{"version":"v4","personalization_survey_submitted_at":"2025-07-09T14:56:58.347Z","personalization_survey_n8n_version":"1.100.1"}	2025-07-09 06:46:09.897+00	2025-07-09 14:56:58.368+00	{"userActivated": false}	f	f	\N	\N	global:owner
\.


--
-- Data for Name: user_api_keys; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.user_api_keys (id, "userId", label, "apiKey", "createdAt", "updatedAt", scopes) FROM stdin;
\.


--
-- Data for Name: variables; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.variables (key, type, value, id) FROM stdin;
\.


--
-- Data for Name: webhook_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.webhook_entity ("webhookPath", method, node, "webhookId", "pathLength", "workflowId") FROM stdin;
\.


--
-- Data for Name: workflow_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.workflow_entity (name, active, nodes, connections, "createdAt", "updatedAt", settings, "staticData", "pinData", "versionId", "triggerCount", id, meta, "parentFolderId", "isArchived") FROM stdin;
\.


--
-- Data for Name: workflow_history; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.workflow_history ("versionId", "workflowId", authors, "createdAt", "updatedAt", nodes, connections) FROM stdin;
\.


--
-- Data for Name: workflow_statistics; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.workflow_statistics (count, "latestEvent", name, "workflowId", "rootCount") FROM stdin;
\.


--
-- Data for Name: workflows_tags; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.workflows_tags ("workflowId", "tagId") FROM stdin;
\.


--
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.auth_provider_sync_history_id_seq', 1, false);


--
-- Name: execution_annotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.execution_annotations_id_seq', 1, false);


--
-- Name: execution_entity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.execution_entity_id_seq', 1, false);


--
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.execution_metadata_temp_id_seq', 1, false);


--
-- Name: insights_by_period_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.insights_by_period_id_seq', 1, false);


--
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public."insights_metadata_metaId_seq"', 1, false);


--
-- Name: insights_raw_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.insights_raw_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.migrations_id_seq', 89, true);


--
-- Name: test_run PK_011c050f566e9db509a0fadb9b9; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.test_run
    ADD CONSTRAINT "PK_011c050f566e9db509a0fadb9b9" PRIMARY KEY (id);


--
-- Name: installed_packages PK_08cc9197c39b028c1e9beca225940576fd1a5804; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.installed_packages
    ADD CONSTRAINT "PK_08cc9197c39b028c1e9beca225940576fd1a5804" PRIMARY KEY ("packageName");


--
-- Name: execution_metadata PK_17a0b6284f8d626aae88e1c16e4; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_metadata
    ADD CONSTRAINT "PK_17a0b6284f8d626aae88e1c16e4" PRIMARY KEY (id);


--
-- Name: project_relation PK_1caaa312a5d7184a003be0f0cb6; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_relation
    ADD CONSTRAINT "PK_1caaa312a5d7184a003be0f0cb6" PRIMARY KEY ("projectId", "userId");


--
-- Name: folder_tag PK_27e4e00852f6b06a925a4d83a3e; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder_tag
    ADD CONSTRAINT "PK_27e4e00852f6b06a925a4d83a3e" PRIMARY KEY ("folderId", "tagId");


--
-- Name: project PK_4d68b1358bb5b766d3e78f32f57; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT "PK_4d68b1358bb5b766d3e78f32f57" PRIMARY KEY (id);


--
-- Name: invalid_auth_token PK_5779069b7235b256d91f7af1a15; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.invalid_auth_token
    ADD CONSTRAINT "PK_5779069b7235b256d91f7af1a15" PRIMARY KEY (token);


--
-- Name: shared_workflow PK_5ba87620386b847201c9531c58f; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_workflow
    ADD CONSTRAINT "PK_5ba87620386b847201c9531c58f" PRIMARY KEY ("workflowId", "projectId");


--
-- Name: folder PK_6278a41a706740c94c02e288df8; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT "PK_6278a41a706740c94c02e288df8" PRIMARY KEY (id);


--
-- Name: annotation_tag_entity PK_69dfa041592c30bbc0d4b84aa00; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.annotation_tag_entity
    ADD CONSTRAINT "PK_69dfa041592c30bbc0d4b84aa00" PRIMARY KEY (id);


--
-- Name: execution_annotations PK_7afcf93ffa20c4252869a7c6a23; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotations
    ADD CONSTRAINT "PK_7afcf93ffa20c4252869a7c6a23" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: installed_nodes PK_8ebd28194e4f792f96b5933423fc439df97d9689; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.installed_nodes
    ADD CONSTRAINT "PK_8ebd28194e4f792f96b5933423fc439df97d9689" PRIMARY KEY (name);


--
-- Name: shared_credentials PK_8ef3a59796a228913f251779cff; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_credentials
    ADD CONSTRAINT "PK_8ef3a59796a228913f251779cff" PRIMARY KEY ("credentialsId", "projectId");


--
-- Name: test_case_execution PK_90c121f77a78a6580e94b794bce; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.test_case_execution
    ADD CONSTRAINT "PK_90c121f77a78a6580e94b794bce" PRIMARY KEY (id);


--
-- Name: user_api_keys PK_978fa5caa3468f463dac9d92e69; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_api_keys
    ADD CONSTRAINT "PK_978fa5caa3468f463dac9d92e69" PRIMARY KEY (id);


--
-- Name: execution_annotation_tags PK_979ec03d31294cca484be65d11f; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotation_tags
    ADD CONSTRAINT "PK_979ec03d31294cca484be65d11f" PRIMARY KEY ("annotationId", "tagId");


--
-- Name: webhook_entity PK_b21ace2e13596ccd87dc9bf4ea6; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.webhook_entity
    ADD CONSTRAINT "PK_b21ace2e13596ccd87dc9bf4ea6" PRIMARY KEY ("webhookPath", method);


--
-- Name: insights_by_period PK_b606942249b90cc39b0265f0575; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_by_period
    ADD CONSTRAINT "PK_b606942249b90cc39b0265f0575" PRIMARY KEY (id);


--
-- Name: workflow_history PK_b6572dd6173e4cd06fe79937b58; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_history
    ADD CONSTRAINT "PK_b6572dd6173e4cd06fe79937b58" PRIMARY KEY ("versionId");


--
-- Name: processed_data PK_ca04b9d8dc72de268fe07a65773; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.processed_data
    ADD CONSTRAINT "PK_ca04b9d8dc72de268fe07a65773" PRIMARY KEY ("workflowId", context);


--
-- Name: settings PK_dc0fe14e6d9943f268e7b119f69ab8bd; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT "PK_dc0fe14e6d9943f268e7b119f69ab8bd" PRIMARY KEY (key);


--
-- Name: user PK_ea8f538c94b6e352418254ed6474a81f; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_ea8f538c94b6e352418254ed6474a81f" PRIMARY KEY (id);


--
-- Name: insights_raw PK_ec15125755151e3a7e00e00014f; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_raw
    ADD CONSTRAINT "PK_ec15125755151e3a7e00e00014f" PRIMARY KEY (id);


--
-- Name: insights_metadata PK_f448a94c35218b6208ce20cf5a1; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_metadata
    ADD CONSTRAINT "PK_f448a94c35218b6208ce20cf5a1" PRIMARY KEY ("metaId");


--
-- Name: user UQ_e12875dfb3b1d92d7d7c5377e2; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e2" UNIQUE (email);


--
-- Name: auth_identity auth_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.auth_identity
    ADD CONSTRAINT auth_identity_pkey PRIMARY KEY ("providerId", "providerType");


--
-- Name: auth_provider_sync_history auth_provider_sync_history_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.auth_provider_sync_history
    ADD CONSTRAINT auth_provider_sync_history_pkey PRIMARY KEY (id);


--
-- Name: credentials_entity credentials_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.credentials_entity
    ADD CONSTRAINT credentials_entity_pkey PRIMARY KEY (id);


--
-- Name: event_destinations event_destinations_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.event_destinations
    ADD CONSTRAINT event_destinations_pkey PRIMARY KEY (id);


--
-- Name: execution_data execution_data_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_data
    ADD CONSTRAINT execution_data_pkey PRIMARY KEY ("executionId");


--
-- Name: execution_entity pk_e3e63bbf986767844bbe1166d4e; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_entity
    ADD CONSTRAINT pk_e3e63bbf986767844bbe1166d4e PRIMARY KEY (id);


--
-- Name: workflow_statistics pk_workflow_statistics; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_statistics
    ADD CONSTRAINT pk_workflow_statistics PRIMARY KEY ("workflowId", name);


--
-- Name: workflows_tags pk_workflows_tags; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflows_tags
    ADD CONSTRAINT pk_workflows_tags PRIMARY KEY ("workflowId", "tagId");


--
-- Name: tag_entity tag_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tag_entity
    ADD CONSTRAINT tag_entity_pkey PRIMARY KEY (id);


--
-- Name: variables variables_key_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.variables
    ADD CONSTRAINT variables_key_key UNIQUE (key);


--
-- Name: variables variables_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.variables
    ADD CONSTRAINT variables_pkey PRIMARY KEY (id);


--
-- Name: workflow_entity workflow_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_entity
    ADD CONSTRAINT workflow_entity_pkey PRIMARY KEY (id);


--
-- Name: IDX_14f68deffaf858465715995508; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_14f68deffaf858465715995508" ON public.folder USING btree ("projectId", id);


--
-- Name: IDX_1d8ab99d5861c9388d2dc1cf73; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_1d8ab99d5861c9388d2dc1cf73" ON public.insights_metadata USING btree ("workflowId");


--
-- Name: IDX_1e31657f5fe46816c34be7c1b4; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_1e31657f5fe46816c34be7c1b4" ON public.workflow_history USING btree ("workflowId");


--
-- Name: IDX_1ef35bac35d20bdae979d917a3; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_1ef35bac35d20bdae979d917a3" ON public.user_api_keys USING btree ("apiKey");


--
-- Name: IDX_5f0643f6717905a05164090dde; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_5f0643f6717905a05164090dde" ON public.project_relation USING btree ("userId");


--
-- Name: IDX_60b6a84299eeb3f671dfec7693; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_60b6a84299eeb3f671dfec7693" ON public.insights_by_period USING btree ("periodStart", type, "periodUnit", "metaId");


--
-- Name: IDX_61448d56d61802b5dfde5cdb00; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_61448d56d61802b5dfde5cdb00" ON public.project_relation USING btree ("projectId");


--
-- Name: IDX_63d7bbae72c767cf162d459fcc; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_63d7bbae72c767cf162d459fcc" ON public.user_api_keys USING btree ("userId", label);


--
-- Name: IDX_8e4b4774db42f1e6dda3452b2a; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_8e4b4774db42f1e6dda3452b2a" ON public.test_case_execution USING btree ("testRunId");


--
-- Name: IDX_97f863fa83c4786f1956508496; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_97f863fa83c4786f1956508496" ON public.execution_annotations USING btree ("executionId");


--
-- Name: IDX_a3697779b366e131b2bbdae297; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_a3697779b366e131b2bbdae297" ON public.execution_annotation_tags USING btree ("tagId");


--
-- Name: IDX_ae51b54c4bb430cf92f48b623f; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_ae51b54c4bb430cf92f48b623f" ON public.annotation_tag_entity USING btree (name);


--
-- Name: IDX_c1519757391996eb06064f0e7c; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_c1519757391996eb06064f0e7c" ON public.execution_annotation_tags USING btree ("annotationId");


--
-- Name: IDX_cec8eea3bf49551482ccb4933e; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_cec8eea3bf49551482ccb4933e" ON public.execution_metadata USING btree ("executionId", key);


--
-- Name: IDX_d6870d3b6e4c185d33926f423c; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_d6870d3b6e4c185d33926f423c" ON public.test_run USING btree ("workflowId");


--
-- Name: IDX_execution_entity_deletedAt; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_execution_entity_deletedAt" ON public.execution_entity USING btree ("deletedAt");


--
-- Name: IDX_workflow_entity_name; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_workflow_entity_name" ON public.workflow_entity USING btree (name);


--
-- Name: idx_07fde106c0b471d8cc80a64fc8; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_07fde106c0b471d8cc80a64fc8 ON public.credentials_entity USING btree (type);


--
-- Name: idx_16f4436789e804e3e1c9eeb240; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_16f4436789e804e3e1c9eeb240 ON public.webhook_entity USING btree ("webhookId", method, "pathLength");


--
-- Name: idx_812eb05f7451ca757fb98444ce; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX idx_812eb05f7451ca757fb98444ce ON public.tag_entity USING btree (name);


--
-- Name: idx_execution_entity_stopped_at_status_deleted_at; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_execution_entity_stopped_at_status_deleted_at ON public.execution_entity USING btree ("stoppedAt", status, "deletedAt") WHERE (("stoppedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- Name: idx_execution_entity_wait_till_status_deleted_at; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_execution_entity_wait_till_status_deleted_at ON public.execution_entity USING btree ("waitTill", status, "deletedAt") WHERE (("waitTill" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- Name: idx_execution_entity_workflow_id_started_at; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_execution_entity_workflow_id_started_at ON public.execution_entity USING btree ("workflowId", "startedAt") WHERE (("startedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- Name: idx_workflows_tags_workflow_id; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_workflows_tags_workflow_id ON public.workflows_tags USING btree ("workflowId");


--
-- Name: pk_credentials_entity_id; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX pk_credentials_entity_id ON public.credentials_entity USING btree (id);


--
-- Name: pk_tag_entity_id; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX pk_tag_entity_id ON public.tag_entity USING btree (id);


--
-- Name: pk_variables_id; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX pk_variables_id ON public.variables USING btree (id);


--
-- Name: pk_workflow_entity_id; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX pk_workflow_entity_id ON public.workflow_entity USING btree (id);


--
-- Name: processed_data FK_06a69a7032c97a763c2c7599464; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.processed_data
    ADD CONSTRAINT "FK_06a69a7032c97a763c2c7599464" FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: insights_metadata FK_1d8ab99d5861c9388d2dc1cf733; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_metadata
    ADD CONSTRAINT "FK_1d8ab99d5861c9388d2dc1cf733" FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE SET NULL;


--
-- Name: workflow_history FK_1e31657f5fe46816c34be7c1b4b; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_history
    ADD CONSTRAINT "FK_1e31657f5fe46816c34be7c1b4b" FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: insights_metadata FK_2375a1eda085adb16b24615b69c; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_metadata
    ADD CONSTRAINT "FK_2375a1eda085adb16b24615b69c" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE SET NULL;


--
-- Name: execution_metadata FK_31d0b4c93fb85ced26f6005cda3; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_metadata
    ADD CONSTRAINT "FK_31d0b4c93fb85ced26f6005cda3" FOREIGN KEY ("executionId") REFERENCES public.execution_entity(id) ON DELETE CASCADE;


--
-- Name: shared_credentials FK_416f66fc846c7c442970c094ccf; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_credentials
    ADD CONSTRAINT "FK_416f66fc846c7c442970c094ccf" FOREIGN KEY ("credentialsId") REFERENCES public.credentials_entity(id) ON DELETE CASCADE;


--
-- Name: project_relation FK_5f0643f6717905a05164090dde7; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_relation
    ADD CONSTRAINT "FK_5f0643f6717905a05164090dde7" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: project_relation FK_61448d56d61802b5dfde5cdb002; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_relation
    ADD CONSTRAINT "FK_61448d56d61802b5dfde5cdb002" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: insights_by_period FK_6414cfed98daabbfdd61a1cfbc0; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_by_period
    ADD CONSTRAINT "FK_6414cfed98daabbfdd61a1cfbc0" FOREIGN KEY ("metaId") REFERENCES public.insights_metadata("metaId") ON DELETE CASCADE;


--
-- Name: insights_raw FK_6e2e33741adef2a7c5d66befa4e; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_raw
    ADD CONSTRAINT "FK_6e2e33741adef2a7c5d66befa4e" FOREIGN KEY ("metaId") REFERENCES public.insights_metadata("metaId") ON DELETE CASCADE;


--
-- Name: installed_nodes FK_73f857fc5dce682cef8a99c11dbddbc969618951; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.installed_nodes
    ADD CONSTRAINT "FK_73f857fc5dce682cef8a99c11dbddbc969618951" FOREIGN KEY (package) REFERENCES public.installed_packages("packageName") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder FK_804ea52f6729e3940498bd54d78; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT "FK_804ea52f6729e3940498bd54d78" FOREIGN KEY ("parentFolderId") REFERENCES public.folder(id) ON DELETE CASCADE;


--
-- Name: shared_credentials FK_812c2852270da1247756e77f5a4; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_credentials
    ADD CONSTRAINT "FK_812c2852270da1247756e77f5a4" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: test_case_execution FK_8e4b4774db42f1e6dda3452b2af; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.test_case_execution
    ADD CONSTRAINT "FK_8e4b4774db42f1e6dda3452b2af" FOREIGN KEY ("testRunId") REFERENCES public.test_run(id) ON DELETE CASCADE;


--
-- Name: folder_tag FK_94a60854e06f2897b2e0d39edba; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder_tag
    ADD CONSTRAINT "FK_94a60854e06f2897b2e0d39edba" FOREIGN KEY ("folderId") REFERENCES public.folder(id) ON DELETE CASCADE;


--
-- Name: execution_annotations FK_97f863fa83c4786f19565084960; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotations
    ADD CONSTRAINT "FK_97f863fa83c4786f19565084960" FOREIGN KEY ("executionId") REFERENCES public.execution_entity(id) ON DELETE CASCADE;


--
-- Name: execution_annotation_tags FK_a3697779b366e131b2bbdae2976; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotation_tags
    ADD CONSTRAINT "FK_a3697779b366e131b2bbdae2976" FOREIGN KEY ("tagId") REFERENCES public.annotation_tag_entity(id) ON DELETE CASCADE;


--
-- Name: shared_workflow FK_a45ea5f27bcfdc21af9b4188560; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_workflow
    ADD CONSTRAINT "FK_a45ea5f27bcfdc21af9b4188560" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: folder FK_a8260b0b36939c6247f385b8221; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT "FK_a8260b0b36939c6247f385b8221" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: execution_annotation_tags FK_c1519757391996eb06064f0e7c8; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotation_tags
    ADD CONSTRAINT "FK_c1519757391996eb06064f0e7c8" FOREIGN KEY ("annotationId") REFERENCES public.execution_annotations(id) ON DELETE CASCADE;


--
-- Name: test_run FK_d6870d3b6e4c185d33926f423c8; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.test_run
    ADD CONSTRAINT "FK_d6870d3b6e4c185d33926f423c8" FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: shared_workflow FK_daa206a04983d47d0a9c34649ce; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_workflow
    ADD CONSTRAINT "FK_daa206a04983d47d0a9c34649ce" FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: folder_tag FK_dc88164176283de80af47621746; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder_tag
    ADD CONSTRAINT "FK_dc88164176283de80af47621746" FOREIGN KEY ("tagId") REFERENCES public.tag_entity(id) ON DELETE CASCADE;


--
-- Name: user_api_keys FK_e131705cbbc8fb589889b02d457; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_api_keys
    ADD CONSTRAINT "FK_e131705cbbc8fb589889b02d457" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: test_case_execution FK_e48965fac35d0f5b9e7f51d8c44; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.test_case_execution
    ADD CONSTRAINT "FK_e48965fac35d0f5b9e7f51d8c44" FOREIGN KEY ("executionId") REFERENCES public.execution_entity(id) ON DELETE SET NULL;


--
-- Name: auth_identity auth_identity_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.auth_identity
    ADD CONSTRAINT "auth_identity_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: execution_data execution_data_fk; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_data
    ADD CONSTRAINT execution_data_fk FOREIGN KEY ("executionId") REFERENCES public.execution_entity(id) ON DELETE CASCADE;


--
-- Name: execution_entity fk_execution_entity_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_entity
    ADD CONSTRAINT fk_execution_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: webhook_entity fk_webhook_entity_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.webhook_entity
    ADD CONSTRAINT fk_webhook_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: workflow_entity fk_workflow_parent_folder; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_entity
    ADD CONSTRAINT fk_workflow_parent_folder FOREIGN KEY ("parentFolderId") REFERENCES public.folder(id) ON DELETE CASCADE;


--
-- Name: workflow_statistics fk_workflow_statistics_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_statistics
    ADD CONSTRAINT fk_workflow_statistics_workflow_id FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: workflows_tags fk_workflows_tags_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_tag_id FOREIGN KEY ("tagId") REFERENCES public.tag_entity(id) ON DELETE CASCADE;


--
-- Name: workflows_tags fk_workflows_tags_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_workflow_id FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "temporal" dump
--

