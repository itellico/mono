--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE developer;
ALTER ROLE developer WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:hiGPc7SYrq2NbBca/J7PJg==$CaUcEqRCFCWHPZ+ZLhXCFIKdCTiVKPQctX8kjonezUg=:avX05ALgr7Z8DVOUEhqjFtNAZ1MYSG1Hv/4vLd1mtPo=';

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "kanboard" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: kanboard; Type: DATABASE; Schema: -; Owner: developer
--

CREATE DATABASE kanboard WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE kanboard OWNER TO developer;

\connect kanboard

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action_has_params; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.action_has_params (
    id integer NOT NULL,
    action_id integer NOT NULL,
    name text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.action_has_params OWNER TO developer;

--
-- Name: action_has_params_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.action_has_params_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.action_has_params_id_seq OWNER TO developer;

--
-- Name: action_has_params_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.action_has_params_id_seq OWNED BY public.action_has_params.id;


--
-- Name: actions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.actions (
    id integer NOT NULL,
    project_id integer NOT NULL,
    event_name text NOT NULL,
    action_name text NOT NULL
);


ALTER TABLE public.actions OWNER TO developer;

--
-- Name: actions_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actions_id_seq OWNER TO developer;

--
-- Name: actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.actions_id_seq OWNED BY public.actions.id;


--
-- Name: column_has_move_restrictions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.column_has_move_restrictions (
    restriction_id integer NOT NULL,
    project_id integer NOT NULL,
    role_id integer NOT NULL,
    src_column_id integer NOT NULL,
    dst_column_id integer NOT NULL,
    only_assigned boolean DEFAULT false
);


ALTER TABLE public.column_has_move_restrictions OWNER TO developer;

--
-- Name: column_has_move_restrictions_restriction_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.column_has_move_restrictions_restriction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.column_has_move_restrictions_restriction_id_seq OWNER TO developer;

--
-- Name: column_has_move_restrictions_restriction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.column_has_move_restrictions_restriction_id_seq OWNED BY public.column_has_move_restrictions.restriction_id;


--
-- Name: column_has_restrictions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.column_has_restrictions (
    restriction_id integer NOT NULL,
    project_id integer NOT NULL,
    role_id integer NOT NULL,
    column_id integer NOT NULL,
    rule character varying(255) NOT NULL
);


ALTER TABLE public.column_has_restrictions OWNER TO developer;

--
-- Name: column_has_restrictions_restriction_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.column_has_restrictions_restriction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.column_has_restrictions_restriction_id_seq OWNER TO developer;

--
-- Name: column_has_restrictions_restriction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.column_has_restrictions_restriction_id_seq OWNED BY public.column_has_restrictions.restriction_id;


--
-- Name: columns; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.columns (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    "position" integer,
    project_id integer NOT NULL,
    task_limit integer DEFAULT 0,
    description text,
    hide_in_dashboard boolean DEFAULT false
);


ALTER TABLE public.columns OWNER TO developer;

--
-- Name: columns_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.columns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.columns_id_seq OWNER TO developer;

--
-- Name: columns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.columns_id_seq OWNED BY public.columns.id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.comments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer DEFAULT 0,
    date_creation bigint NOT NULL,
    comment text,
    reference text DEFAULT ''::character varying,
    date_modification bigint,
    visibility character varying(25) DEFAULT 'app-user'::character varying NOT NULL
);


ALTER TABLE public.comments OWNER TO developer;

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_id_seq OWNER TO developer;

--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.currencies (
    currency character(3) NOT NULL,
    rate real DEFAULT 0
);


ALTER TABLE public.currencies OWNER TO developer;

--
-- Name: custom_filters; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.custom_filters (
    id integer NOT NULL,
    filter text NOT NULL,
    project_id integer NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    is_shared boolean DEFAULT false,
    append boolean DEFAULT false
);


ALTER TABLE public.custom_filters OWNER TO developer;

--
-- Name: custom_filters_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.custom_filters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_filters_id_seq OWNER TO developer;

--
-- Name: custom_filters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.custom_filters_id_seq OWNED BY public.custom_filters.id;


--
-- Name: group_has_users; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.group_has_users (
    group_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.group_has_users OWNER TO developer;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    external_id character varying(255) DEFAULT ''::character varying,
    name text NOT NULL
);


ALTER TABLE public.groups OWNER TO developer;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO developer;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: invites; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.invites (
    email character varying(255) NOT NULL,
    project_id integer NOT NULL,
    token character varying(255) NOT NULL
);


ALTER TABLE public.invites OWNER TO developer;

--
-- Name: last_logins; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.last_logins (
    id integer NOT NULL,
    auth_type character varying(25),
    user_id integer,
    ip character varying(45),
    user_agent character varying(255),
    date_creation bigint
);


ALTER TABLE public.last_logins OWNER TO developer;

--
-- Name: last_logins_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.last_logins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.last_logins_id_seq OWNER TO developer;

--
-- Name: last_logins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.last_logins_id_seq OWNED BY public.last_logins.id;


--
-- Name: links; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.links (
    id integer NOT NULL,
    label character varying(255) NOT NULL,
    opposite_id integer DEFAULT 0
);


ALTER TABLE public.links OWNER TO developer;

--
-- Name: links_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.links_id_seq OWNER TO developer;

--
-- Name: links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.links_id_seq OWNED BY public.links.id;


--
-- Name: password_reset; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.password_reset (
    token character varying(80) NOT NULL,
    user_id integer NOT NULL,
    date_expiration integer NOT NULL,
    date_creation integer NOT NULL,
    ip character varying(45) NOT NULL,
    user_agent character varying(255) NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.password_reset OWNER TO developer;

--
-- Name: plugin_schema_versions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.plugin_schema_versions (
    plugin character varying(80) NOT NULL,
    version integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.plugin_schema_versions OWNER TO developer;

--
-- Name: predefined_task_descriptions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.predefined_task_descriptions (
    id integer NOT NULL,
    project_id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.predefined_task_descriptions OWNER TO developer;

--
-- Name: predefined_task_descriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.predefined_task_descriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.predefined_task_descriptions_id_seq OWNER TO developer;

--
-- Name: predefined_task_descriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.predefined_task_descriptions_id_seq OWNED BY public.predefined_task_descriptions.id;


--
-- Name: project_activities; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_activities (
    id integer NOT NULL,
    date_creation bigint NOT NULL,
    event_name text NOT NULL,
    creator_id integer,
    project_id integer,
    task_id integer,
    data text
);


ALTER TABLE public.project_activities OWNER TO developer;

--
-- Name: project_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_activities_id_seq OWNER TO developer;

--
-- Name: project_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_activities_id_seq OWNED BY public.project_activities.id;


--
-- Name: project_daily_column_stats; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_daily_column_stats (
    id integer NOT NULL,
    day character(10) NOT NULL,
    project_id integer NOT NULL,
    column_id integer NOT NULL,
    total integer DEFAULT 0 NOT NULL,
    score integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.project_daily_column_stats OWNER TO developer;

--
-- Name: project_daily_stats; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_daily_stats (
    id integer NOT NULL,
    day character(10) NOT NULL,
    project_id integer NOT NULL,
    avg_lead_time integer DEFAULT 0 NOT NULL,
    avg_cycle_time integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.project_daily_stats OWNER TO developer;

--
-- Name: project_daily_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_daily_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_daily_stats_id_seq OWNER TO developer;

--
-- Name: project_daily_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_daily_stats_id_seq OWNED BY public.project_daily_stats.id;


--
-- Name: project_daily_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_daily_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_daily_summaries_id_seq OWNER TO developer;

--
-- Name: project_daily_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_daily_summaries_id_seq OWNED BY public.project_daily_column_stats.id;


--
-- Name: project_has_categories; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    project_id integer NOT NULL,
    description text,
    color_id character varying(50) DEFAULT NULL::character varying
);


ALTER TABLE public.project_has_categories OWNER TO developer;

--
-- Name: project_has_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_has_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_has_categories_id_seq OWNER TO developer;

--
-- Name: project_has_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_has_categories_id_seq OWNED BY public.project_has_categories.id;


--
-- Name: project_has_files; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_files (
    id integer NOT NULL,
    project_id integer NOT NULL,
    name text NOT NULL,
    path text NOT NULL,
    is_image boolean DEFAULT false,
    size integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    date integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.project_has_files OWNER TO developer;

--
-- Name: project_has_files_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_has_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_has_files_id_seq OWNER TO developer;

--
-- Name: project_has_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_has_files_id_seq OWNED BY public.project_has_files.id;


--
-- Name: project_has_groups; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_groups (
    group_id integer NOT NULL,
    project_id integer NOT NULL,
    role character varying(255) NOT NULL
);


ALTER TABLE public.project_has_groups OWNER TO developer;

--
-- Name: project_has_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_metadata (
    project_id integer NOT NULL,
    name character varying(50) NOT NULL,
    value character varying(255) DEFAULT ''::character varying,
    changed_by integer DEFAULT 0 NOT NULL,
    changed_on integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.project_has_metadata OWNER TO developer;

--
-- Name: project_has_notification_types; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_notification_types (
    id integer NOT NULL,
    project_id integer NOT NULL,
    notification_type character varying(50) NOT NULL
);


ALTER TABLE public.project_has_notification_types OWNER TO developer;

--
-- Name: project_has_notification_types_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_has_notification_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_has_notification_types_id_seq OWNER TO developer;

--
-- Name: project_has_notification_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_has_notification_types_id_seq OWNED BY public.project_has_notification_types.id;


--
-- Name: project_has_roles; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_roles (
    role_id integer NOT NULL,
    role character varying(255) NOT NULL,
    project_id integer NOT NULL
);


ALTER TABLE public.project_has_roles OWNER TO developer;

--
-- Name: project_has_roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_has_roles_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_has_roles_role_id_seq OWNER TO developer;

--
-- Name: project_has_roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_has_roles_role_id_seq OWNED BY public.project_has_roles.role_id;


--
-- Name: project_has_users; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_has_users (
    project_id integer NOT NULL,
    user_id integer NOT NULL,
    role character varying(255) DEFAULT 'project-viewer'::character varying NOT NULL
);


ALTER TABLE public.project_has_users OWNER TO developer;

--
-- Name: project_role_has_restrictions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_role_has_restrictions (
    restriction_id integer NOT NULL,
    project_id integer NOT NULL,
    role_id integer NOT NULL,
    rule character varying(255) NOT NULL
);


ALTER TABLE public.project_role_has_restrictions OWNER TO developer;

--
-- Name: project_role_has_restrictions_restriction_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.project_role_has_restrictions_restriction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_role_has_restrictions_restriction_id_seq OWNER TO developer;

--
-- Name: project_role_has_restrictions_restriction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.project_role_has_restrictions_restriction_id_seq OWNED BY public.project_role_has_restrictions.restriction_id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT true,
    token character varying(255),
    last_modified bigint DEFAULT 0,
    is_public boolean DEFAULT false,
    is_private boolean DEFAULT false,
    description text,
    identifier character varying(50) DEFAULT ''::character varying,
    start_date character varying(10) DEFAULT ''::character varying,
    end_date character varying(10) DEFAULT ''::character varying,
    owner_id integer DEFAULT 0,
    priority_default integer DEFAULT 0,
    priority_start integer DEFAULT 0,
    priority_end integer DEFAULT 3,
    email text,
    predefined_email_subjects text,
    per_swimlane_task_limits boolean DEFAULT false,
    task_limit integer DEFAULT 0,
    enable_global_tags boolean DEFAULT true
);


ALTER TABLE public.projects OWNER TO developer;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO developer;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: remember_me; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.remember_me (
    id integer NOT NULL,
    user_id integer,
    ip character varying(45),
    user_agent character varying(255),
    token character varying(255),
    sequence character varying(255),
    expiration integer,
    date_creation bigint
);


ALTER TABLE public.remember_me OWNER TO developer;

--
-- Name: remember_me_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.remember_me_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.remember_me_id_seq OWNER TO developer;

--
-- Name: remember_me_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.remember_me_id_seq OWNED BY public.remember_me.id;


--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.schema_version (
    version integer DEFAULT 0
);


ALTER TABLE public.schema_version OWNER TO developer;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    expire_at integer NOT NULL,
    data text DEFAULT ''::text
);


ALTER TABLE public.sessions OWNER TO developer;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.settings (
    option character varying(100) NOT NULL,
    value text DEFAULT ''::character varying,
    changed_by integer DEFAULT 0 NOT NULL,
    changed_on integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.settings OWNER TO developer;

--
-- Name: subtask_time_tracking; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.subtask_time_tracking (
    id integer NOT NULL,
    user_id integer NOT NULL,
    subtask_id integer NOT NULL,
    start bigint DEFAULT 0,
    "end" bigint DEFAULT 0,
    time_spent real DEFAULT 0
);


ALTER TABLE public.subtask_time_tracking OWNER TO developer;

--
-- Name: subtask_time_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.subtask_time_tracking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subtask_time_tracking_id_seq OWNER TO developer;

--
-- Name: subtask_time_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.subtask_time_tracking_id_seq OWNED BY public.subtask_time_tracking.id;


--
-- Name: subtasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.subtasks (
    id integer NOT NULL,
    title text NOT NULL,
    status smallint DEFAULT 0,
    time_estimated double precision DEFAULT 0,
    time_spent double precision DEFAULT 0,
    task_id integer NOT NULL,
    user_id integer,
    "position" integer DEFAULT 1
);


ALTER TABLE public.subtasks OWNER TO developer;

--
-- Name: swimlanes; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.swimlanes (
    id integer NOT NULL,
    name text NOT NULL,
    "position" integer DEFAULT 1,
    is_active boolean DEFAULT true,
    project_id integer,
    description text,
    task_limit integer DEFAULT 0
);


ALTER TABLE public.swimlanes OWNER TO developer;

--
-- Name: swimlanes_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.swimlanes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.swimlanes_id_seq OWNER TO developer;

--
-- Name: swimlanes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.swimlanes_id_seq OWNED BY public.swimlanes.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    project_id integer NOT NULL,
    color_id character varying(50) DEFAULT NULL::character varying
);


ALTER TABLE public.tags OWNER TO developer;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_id_seq OWNER TO developer;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: task_has_external_links; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_has_external_links (
    id integer NOT NULL,
    link_type character varying(100) NOT NULL,
    dependency character varying(100) NOT NULL,
    title text NOT NULL,
    url text NOT NULL,
    date_creation integer NOT NULL,
    date_modification integer NOT NULL,
    task_id integer NOT NULL,
    creator_id integer DEFAULT 0
);


ALTER TABLE public.task_has_external_links OWNER TO developer;

--
-- Name: task_has_external_links_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.task_has_external_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_has_external_links_id_seq OWNER TO developer;

--
-- Name: task_has_external_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.task_has_external_links_id_seq OWNED BY public.task_has_external_links.id;


--
-- Name: task_has_files; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_has_files (
    id integer NOT NULL,
    name text NOT NULL,
    path text,
    is_image boolean DEFAULT false,
    task_id integer NOT NULL,
    date bigint DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    size integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.task_has_files OWNER TO developer;

--
-- Name: task_has_files_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.task_has_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_has_files_id_seq OWNER TO developer;

--
-- Name: task_has_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.task_has_files_id_seq OWNED BY public.task_has_files.id;


--
-- Name: task_has_links; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_has_links (
    id integer NOT NULL,
    link_id integer NOT NULL,
    task_id integer NOT NULL,
    opposite_task_id integer NOT NULL
);


ALTER TABLE public.task_has_links OWNER TO developer;

--
-- Name: task_has_links_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.task_has_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_has_links_id_seq OWNER TO developer;

--
-- Name: task_has_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.task_has_links_id_seq OWNED BY public.task_has_links.id;


--
-- Name: task_has_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_has_metadata (
    task_id integer NOT NULL,
    name character varying(50) NOT NULL,
    value character varying(255) DEFAULT ''::character varying,
    changed_by integer DEFAULT 0 NOT NULL,
    changed_on integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.task_has_metadata OWNER TO developer;

--
-- Name: task_has_subtasks_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.task_has_subtasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_has_subtasks_id_seq OWNER TO developer;

--
-- Name: task_has_subtasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.task_has_subtasks_id_seq OWNED BY public.subtasks.id;


--
-- Name: task_has_tags; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_has_tags (
    task_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.task_has_tags OWNER TO developer;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    date_creation bigint,
    color_id character varying(255),
    project_id integer NOT NULL,
    column_id integer NOT NULL,
    owner_id integer DEFAULT 0,
    "position" integer,
    is_active boolean DEFAULT true,
    date_completed bigint,
    score integer,
    date_due bigint,
    category_id integer DEFAULT 0,
    creator_id integer DEFAULT 0,
    date_modification integer DEFAULT 0,
    reference text DEFAULT ''::character varying,
    date_started bigint,
    time_spent double precision DEFAULT 0,
    time_estimated double precision DEFAULT 0,
    swimlane_id integer NOT NULL,
    date_moved bigint DEFAULT 0,
    recurrence_status integer DEFAULT 0 NOT NULL,
    recurrence_trigger integer DEFAULT 0 NOT NULL,
    recurrence_factor integer DEFAULT 0 NOT NULL,
    recurrence_timeframe integer DEFAULT 0 NOT NULL,
    recurrence_basedate integer DEFAULT 0 NOT NULL,
    recurrence_parent integer,
    recurrence_child integer,
    priority integer DEFAULT 0,
    external_provider character varying(255),
    external_uri character varying(255)
);


ALTER TABLE public.tasks OWNER TO developer;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO developer;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: transitions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.transitions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    project_id integer NOT NULL,
    task_id integer NOT NULL,
    src_column_id integer NOT NULL,
    dst_column_id integer NOT NULL,
    date bigint NOT NULL,
    time_spent integer DEFAULT 0
);


ALTER TABLE public.transitions OWNER TO developer;

--
-- Name: transitions_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.transitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transitions_id_seq OWNER TO developer;

--
-- Name: transitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.transitions_id_seq OWNED BY public.transitions.id;


--
-- Name: user_has_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.user_has_metadata (
    user_id integer NOT NULL,
    name character varying(50) NOT NULL,
    value character varying(255) DEFAULT ''::character varying,
    changed_by integer DEFAULT 0 NOT NULL,
    changed_on integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_has_metadata OWNER TO developer;

--
-- Name: user_has_notification_types; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.user_has_notification_types (
    id integer NOT NULL,
    user_id integer NOT NULL,
    notification_type character varying(50)
);


ALTER TABLE public.user_has_notification_types OWNER TO developer;

--
-- Name: user_has_notification_types_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.user_has_notification_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_has_notification_types_id_seq OWNER TO developer;

--
-- Name: user_has_notification_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.user_has_notification_types_id_seq OWNED BY public.user_has_notification_types.id;


--
-- Name: user_has_notifications; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.user_has_notifications (
    user_id integer NOT NULL,
    project_id integer
);


ALTER TABLE public.user_has_notifications OWNER TO developer;

--
-- Name: user_has_unread_notifications; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.user_has_unread_notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    date_creation bigint NOT NULL,
    event_name text NOT NULL,
    event_data text NOT NULL
);


ALTER TABLE public.user_has_unread_notifications OWNER TO developer;

--
-- Name: user_has_unread_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.user_has_unread_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_has_unread_notifications_id_seq OWNER TO developer;

--
-- Name: user_has_unread_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.user_has_unread_notifications_id_seq OWNED BY public.user_has_unread_notifications.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password character varying(255),
    is_ldap_user boolean DEFAULT false,
    name character varying(255),
    email character varying(255),
    google_id character varying(255),
    github_id character varying(30),
    notifications_enabled boolean DEFAULT false,
    timezone character varying(50),
    language character varying(11),
    disable_login_form boolean DEFAULT false,
    twofactor_activated boolean DEFAULT false,
    twofactor_secret character(16),
    token character varying(255) DEFAULT ''::character varying,
    notifications_filter integer DEFAULT 4,
    nb_failed_login integer DEFAULT 0,
    lock_expiration_date bigint DEFAULT 0,
    gitlab_id integer,
    role character varying(25) DEFAULT 'app-user'::character varying NOT NULL,
    is_active boolean DEFAULT true,
    avatar_path character varying(255),
    api_access_token character varying(255) DEFAULT NULL::character varying,
    filter text DEFAULT NULL::character varying,
    theme text DEFAULT 'light'::text NOT NULL
);


ALTER TABLE public.users OWNER TO developer;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO developer;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: action_has_params id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.action_has_params ALTER COLUMN id SET DEFAULT nextval('public.action_has_params_id_seq'::regclass);


--
-- Name: actions id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.actions ALTER COLUMN id SET DEFAULT nextval('public.actions_id_seq'::regclass);


--
-- Name: column_has_move_restrictions restriction_id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions ALTER COLUMN restriction_id SET DEFAULT nextval('public.column_has_move_restrictions_restriction_id_seq'::regclass);


--
-- Name: column_has_restrictions restriction_id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions ALTER COLUMN restriction_id SET DEFAULT nextval('public.column_has_restrictions_restriction_id_seq'::regclass);


--
-- Name: columns id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.columns ALTER COLUMN id SET DEFAULT nextval('public.columns_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: custom_filters id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.custom_filters ALTER COLUMN id SET DEFAULT nextval('public.custom_filters_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: last_logins id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.last_logins ALTER COLUMN id SET DEFAULT nextval('public.last_logins_id_seq'::regclass);


--
-- Name: links id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.links ALTER COLUMN id SET DEFAULT nextval('public.links_id_seq'::regclass);


--
-- Name: predefined_task_descriptions id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.predefined_task_descriptions ALTER COLUMN id SET DEFAULT nextval('public.predefined_task_descriptions_id_seq'::regclass);


--
-- Name: project_activities id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_activities ALTER COLUMN id SET DEFAULT nextval('public.project_activities_id_seq'::regclass);


--
-- Name: project_daily_column_stats id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_column_stats ALTER COLUMN id SET DEFAULT nextval('public.project_daily_summaries_id_seq'::regclass);


--
-- Name: project_daily_stats id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_stats ALTER COLUMN id SET DEFAULT nextval('public.project_daily_stats_id_seq'::regclass);


--
-- Name: project_has_categories id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_categories ALTER COLUMN id SET DEFAULT nextval('public.project_has_categories_id_seq'::regclass);


--
-- Name: project_has_files id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_files ALTER COLUMN id SET DEFAULT nextval('public.project_has_files_id_seq'::regclass);


--
-- Name: project_has_notification_types id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_notification_types ALTER COLUMN id SET DEFAULT nextval('public.project_has_notification_types_id_seq'::regclass);


--
-- Name: project_has_roles role_id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_roles ALTER COLUMN role_id SET DEFAULT nextval('public.project_has_roles_role_id_seq'::regclass);


--
-- Name: project_role_has_restrictions restriction_id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_role_has_restrictions ALTER COLUMN restriction_id SET DEFAULT nextval('public.project_role_has_restrictions_restriction_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: remember_me id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.remember_me ALTER COLUMN id SET DEFAULT nextval('public.remember_me_id_seq'::regclass);


--
-- Name: subtask_time_tracking id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtask_time_tracking ALTER COLUMN id SET DEFAULT nextval('public.subtask_time_tracking_id_seq'::regclass);


--
-- Name: subtasks id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtasks ALTER COLUMN id SET DEFAULT nextval('public.task_has_subtasks_id_seq'::regclass);


--
-- Name: swimlanes id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.swimlanes ALTER COLUMN id SET DEFAULT nextval('public.swimlanes_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: task_has_external_links id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_external_links ALTER COLUMN id SET DEFAULT nextval('public.task_has_external_links_id_seq'::regclass);


--
-- Name: task_has_files id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_files ALTER COLUMN id SET DEFAULT nextval('public.task_has_files_id_seq'::regclass);


--
-- Name: task_has_links id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_links ALTER COLUMN id SET DEFAULT nextval('public.task_has_links_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: transitions id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions ALTER COLUMN id SET DEFAULT nextval('public.transitions_id_seq'::regclass);


--
-- Name: user_has_notification_types id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notification_types ALTER COLUMN id SET DEFAULT nextval('public.user_has_notification_types_id_seq'::regclass);


--
-- Name: user_has_unread_notifications id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_unread_notifications ALTER COLUMN id SET DEFAULT nextval('public.user_has_unread_notifications_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: action_has_params; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.action_has_params (id, action_id, name, value) FROM stdin;
\.


--
-- Data for Name: actions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.actions (id, project_id, event_name, action_name) FROM stdin;
\.


--
-- Data for Name: column_has_move_restrictions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.column_has_move_restrictions (restriction_id, project_id, role_id, src_column_id, dst_column_id, only_assigned) FROM stdin;
\.


--
-- Data for Name: column_has_restrictions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.column_has_restrictions (restriction_id, project_id, role_id, column_id, rule) FROM stdin;
\.


--
-- Data for Name: columns; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.columns (id, title, "position", project_id, task_limit, description, hide_in_dashboard) FROM stdin;
1	Backlog	1	1	0		f
2	Ready	2	1	0		f
3	Work in progress	3	1	0		f
4	Done	4	1	0		f
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.comments (id, task_id, user_id, date_creation, comment, reference, date_modification, visibility) FROM stdin;
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.currencies (currency, rate) FROM stdin;
\.


--
-- Data for Name: custom_filters; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.custom_filters (id, filter, project_id, user_id, name, is_shared, append) FROM stdin;
\.


--
-- Data for Name: group_has_users; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.group_has_users (group_id, user_id) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.groups (id, external_id, name) FROM stdin;
\.


--
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.invites (email, project_id, token) FROM stdin;
\.


--
-- Data for Name: last_logins; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.last_logins (id, auth_type, user_id, ip, user_agent, date_creation) FROM stdin;
1	Database	1	192.168.65.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	1752062887
\.


--
-- Data for Name: links; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.links (id, label, opposite_id) FROM stdin;
1	relates to	0
2	blocks	3
3	is blocked by	2
4	duplicates	5
5	is duplicated by	4
6	is a child of	7
7	is a parent of	6
8	targets milestone	9
9	is a milestone of	8
10	fixes	11
11	is fixed by	10
\.


--
-- Data for Name: password_reset; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.password_reset (token, user_id, date_expiration, date_creation, ip, user_agent, is_active) FROM stdin;
\.


--
-- Data for Name: plugin_schema_versions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.plugin_schema_versions (plugin, version) FROM stdin;
\.


--
-- Data for Name: predefined_task_descriptions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.predefined_task_descriptions (id, project_id, title, description) FROM stdin;
\.


--
-- Data for Name: project_activities; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_activities (id, date_creation, event_name, creator_id, project_id, task_id, data) FROM stdin;
\.


--
-- Data for Name: project_daily_column_stats; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_daily_column_stats (id, day, project_id, column_id, total, score) FROM stdin;
37	2025-07-09	1	1	30	0
\.


--
-- Data for Name: project_daily_stats; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_daily_stats (id, day, project_id, avg_lead_time, avg_cycle_time) FROM stdin;
37	2025-07-09	1	643	0
\.


--
-- Data for Name: project_has_categories; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_categories (id, name, project_id, description, color_id) FROM stdin;
\.


--
-- Data for Name: project_has_files; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_files (id, project_id, name, path, is_image, size, user_id, date) FROM stdin;
\.


--
-- Data for Name: project_has_groups; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_groups (group_id, project_id, role) FROM stdin;
\.


--
-- Data for Name: project_has_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_metadata (project_id, name, value, changed_by, changed_on) FROM stdin;
\.


--
-- Data for Name: project_has_notification_types; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_notification_types (id, project_id, notification_type) FROM stdin;
\.


--
-- Data for Name: project_has_roles; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_roles (role_id, role, project_id) FROM stdin;
\.


--
-- Data for Name: project_has_users; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_has_users (project_id, user_id, role) FROM stdin;
1	1	project-manager
\.


--
-- Data for Name: project_role_has_restrictions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_role_has_restrictions (restriction_id, project_id, role_id, rule) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.projects (id, name, is_active, token, last_modified, is_public, is_private, description, identifier, start_date, end_date, owner_id, priority_default, priority_start, priority_end, email, predefined_email_subjects, per_swimlane_task_limits, task_limit, enable_global_tags) FROM stdin;
1	mono	t		1752073077	f	f	\N				1	0	0	3	\N	\N	f	0	t
\.


--
-- Data for Name: remember_me; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.remember_me (id, user_id, ip, user_agent, token, sequence, expiration, date_creation) FROM stdin;
1	1	192.168.65.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36	40a425e8f04416c973a6f2eabd679ada6ca703df4cd3dca312c7ed6f9209c4ea	b4d64bf123ecd35a78f5f42e0bbab5b490b187558bda102a3ac9bc5c68f1	1757246887	1752062887
\.


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.schema_version (version) FROM stdin;
117
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.sessions (id, expire_at, data) FROM stdin;
688888cfdd6996cadd538e30d637e63a	1752074958	csrf_key|s:64:"683ac4aafe2f8fc8ccee34355b40c12bdc2775670b73891e3d775f112d388b7b";hasRememberMe|b:1;user|a:24:{s:2:"id";i:1;s:8:"username";s:5:"admin";s:12:"is_ldap_user";b:0;s:4:"name";N;s:5:"email";N;s:9:"google_id";N;s:9:"github_id";N;s:21:"notifications_enabled";b:0;s:8:"timezone";N;s:8:"language";N;s:18:"disable_login_form";b:0;s:19:"twofactor_activated";b:0;s:16:"twofactor_secret";N;s:5:"token";s:0:"";s:20:"notifications_filter";i:4;s:15:"nb_failed_login";i:0;s:20:"lock_expiration_date";i:0;s:9:"gitlab_id";N;s:4:"role";s:9:"app-admin";s:9:"is_active";b:1;s:11:"avatar_path";N;s:16:"api_access_token";N;s:6:"filter";N;s:5:"theme";s:5:"light";}postAuthenticationValidated|b:0;hasSubtaskInProgress|b:0;flash|a:0:{}filters:1|s:11:"status:open";pcsrf_key|s:64:"42540f52b42be4364e16e1bc792bd1c5b40a1e6b5a4e74540b962b767a9ccf67";
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.settings (option, value, changed_by, changed_on) FROM stdin;
board_highlight_period	172800	0	0
board_public_refresh_interval	60	0	0
board_private_refresh_interval	10	0	0
board_columns		0	0
webhook_token	15c4a94a1792dcdd49c81bd6b23966962617506b09ab4ca1cee6985afa5b	0	0
api_token	2e85cd5800c57f0ff4b7bc0d64848a3f41bd714245f4e9a6bc9398c6211b	0	0
application_language	en_US	0	0
application_timezone	UTC	0	0
application_url		0	0
application_date_format	m/d/Y	0	0
project_categories		0	0
subtask_restriction	0	0	0
application_stylesheet		0	0
application_currency	USD	0	0
integration_gravatar	0	0	0
calendar_user_subtasks_time_tracking	0	0	0
calendar_user_tasks	date_started	0	0
calendar_project_tasks	date_started	0	0
webhook_url		0	0
default_color	yellow	0	0
subtask_time_tracking	1	0	0
cfd_include_closed_tasks	1	0	0
password_reset	1	0	0
mail_sender_address		1	1752063124
mail_transport	smtp	1	1752063124
\.


--
-- Data for Name: subtask_time_tracking; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.subtask_time_tracking (id, user_id, subtask_id, start, "end", time_spent) FROM stdin;
\.


--
-- Data for Name: subtasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.subtasks (id, title, status, time_estimated, time_spent, task_id, user_id, "position") FROM stdin;
\.


--
-- Data for Name: swimlanes; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.swimlanes (id, name, "position", is_active, project_id, description, task_limit) FROM stdin;
1	Default swimlane	1	t	1		0
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.tags (id, name, project_id, color_id) FROM stdin;
1	security	1	\N
2	backend	1	\N
3	api	1	\N
4	bug	1	\N
5	compliance	1	\N
6	feature	1	\N
7	payment	1	\N
8	testing	1	\N
9	frontend	1	\N
10	infra	1	\N
11	performance	1	\N
12	database	1	\N
13	analytics	1	\N
14	mobile	1	\N
15	auth	1	\N
16	messaging	1	\N
17	docs	1	\N
18	roadmap	1	\N
19	status	1	\N
20	project-management	1	\N
21	subtask	1	\N
22	mfa	1	\N
23	content	1	\N
24	workflow	1	\N
25	template	1	\N
26	reference	1	\N
27	documentation	1	\N
28	clickdummy	1	\N
29	gdpr	1	\N
\.


--
-- Data for Name: task_has_external_links; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_has_external_links (id, link_type, dependency, title, url, date_creation, date_modification, task_id, creator_id) FROM stdin;
\.


--
-- Data for Name: task_has_files; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_has_files (id, name, path, is_image, task_id, date, user_id, size) FROM stdin;
\.


--
-- Data for Name: task_has_links; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_has_links (id, link_id, task_id, opposite_task_id) FROM stdin;
\.


--
-- Data for Name: task_has_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_has_metadata (task_id, name, value, changed_by, changed_on) FROM stdin;
\.


--
-- Data for Name: task_has_tags; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_has_tags (task_id, tag_id) FROM stdin;
4	1
4	2
4	3
4	4
5	1
5	2
5	4
5	5
6	6
6	2
6	3
6	7
7	8
7	2
7	9
8	8
8	9
8	10
9	11
9	2
9	12
10	6
10	2
10	9
10	13
11	6
11	9
11	14
12	6
12	2
12	3
12	15
13	6
13	2
13	10
14	6
14	2
14	9
14	4
15	3
15	2
15	7
16	3
16	2
16	13
17	9
17	6
17	4
18	9
18	6
18	16
19	17
19	3
20	10
20	8
20	1
21	4
21	9
21	13
22	4
22	10
22	2
23	18
23	19
23	20
24	17
24	1
24	21
24	22
25	17
25	7
25	21
26	17
26	8
26	21
27	17
27	13
27	9
27	21
28	17
28	23
28	24
28	21
29	25
29	26
30	26
30	27
30	28
31	17
31	5
31	29
31	21
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.tasks (id, title, description, date_creation, color_id, project_id, column_id, owner_id, "position", is_active, date_completed, score, date_due, category_id, creator_id, date_modification, reference, date_started, time_spent, time_estimated, swimlane_id, date_moved, recurrence_status, recurrence_trigger, recurrence_factor, recurrence_timeframe, recurrence_basedate, recurrence_parent, recurrence_child, priority, external_provider, external_uri) FROM stdin;
1	Test Task from MCP Integration	This is a test task created via the API to verify Kanboard integration is working properly	1752070710	blue	1	1	0	1	t	\N	0	0	0	0	1752071271		0	\N	\N	1	1752070710	0	0	0	0	0	\N	\N	1	\N	\N
2	Test after MCP fix		1752071109	yellow	1	1	0	2	t	\N	0	0	0	0	1752071277		0	\N	\N	1	1752071109	0	0	0	0	0	\N	\N	0	\N	\N
8	Testing Infrastructure - E2E Tests	Set up end-to-end testing framework and implement critical user journey tests.\n\nRequirements:\n- Playwright setup\n- Critical user flows testing\n- CI/CD integration\n- Test data management\n- Parallel test execution\n\nKey flows to test:\n- User registration/login\n- Job posting workflow\n- Messaging system\n- Payment flows	1752072316	orange	1	1	0	7	t	\N	0	0	0	0	1752072316		0	\N	\N	1	1752072316	0	0	0	0	0	\N	\N	2	\N	\N
9	Performance Optimization - Database Queries	Optimize database performance to maintain <200ms API response times.\n\nCurrent: 60% optimized\nIssues to address:\n- N+1 query problems\n- Missing indexes\n- Inefficient joins\n- Query result caching\n- Connection pooling optimization\n\nTools: Prisma query analysis, pgAdmin, Redis caching	1752072323	orange	1	1	0	8	t	\N	0	0	0	0	1752072323		0	\N	\N	1	1752072323	0	0	0	0	0	\N	\N	2	\N	\N
10	Advanced Analytics - User Behavior Tracking	Implement comprehensive user analytics system.\n\nRequirements:\n- User action tracking\n- Session analytics\n- Conversion funnel analysis\n- Custom event tracking\n- Privacy-compliant data collection\n- Real-time dashboards\n\nCurrent: 30% complete\nStack: PostHog/Mixpanel integration, custom analytics API	1752072330	orange	1	1	0	9	t	\N	0	0	0	0	1752072330		0	\N	\N	1	1752072330	0	0	0	0	0	\N	\N	2	\N	\N
11	Mobile Optimization - PWA Implementation	Convert the Next.js application into a Progressive Web App.\n\nRequirements:\n- Service worker implementation\n- Offline functionality\n- Push notifications\n- App manifest configuration\n- Cache strategies\n- Install prompts\n\nCurrent: 40% complete	1752072336	yellow	1	1	0	10	t	\N	0	0	0	0	1752072336		0	\N	\N	1	1752072336	0	0	0	0	0	\N	\N	1	\N	\N
12	Social Media Login Integration	Implement OAuth-based social login options.\n\nProviders to integrate:\n- Google OAuth 2.0\n- Facebook Login\n- LinkedIn Authentication\n- Apple Sign In\n\nRequirements:\n- Account linking for existing users\n- Profile data import\n- Security considerations	1752072343	yellow	1	1	0	11	t	\N	0	0	0	0	1752072343		0	\N	\N	1	1752072343	0	0	0	0	0	\N	\N	1	\N	\N
13	Workflow Automation - Temporal Integration	Complete Temporal workflow engine integration for complex business processes.\n\nUse cases:\n- Job application workflows\n- Content moderation pipelines\n- Payment processing workflows\n- User onboarding sequences\n- Notification scheduling\n\nTech: Temporal.io + Reactflow for visual workflow builder	1752072351	yellow	1	1	0	12	t	\N	0	0	0	0	1752072351		0	\N	\N	1	1752072351	0	0	0	0	0	\N	\N	1	\N	\N
15	API Endpoints - Payment Routes	Implement missing payment-related API endpoints.\n\nRequired endpoints:\n- POST /api/v1/payments/connect/onboard\n- POST /api/v1/payments/process\n- GET /api/v1/payments/history\n- POST /api/v1/payments/refund\n- GET /api/v1/payments/invoices\n- POST /api/v1/payments/escrow/release\n\nFollow 5-tier API architecture	1752072371	blue	1	1	0	14	t	\N	0	0	0	0	1752072371		0	\N	\N	1	1752072371	0	0	0	0	0	\N	\N	2	\N	\N
16	API Endpoints - Analytics Routes	Create analytics API endpoints for dashboard data.\n\nRequired endpoints:\n- GET /api/v1/analytics/users/behavior\n- GET /api/v1/analytics/revenue/summary\n- GET /api/v1/analytics/content/performance\n- POST /api/v1/analytics/events/track\n- GET /api/v1/analytics/funnels\n\nInclude proper caching strategies	1752072378	blue	1	1	0	15	t	\N	0	0	0	0	1752072378		0	\N	\N	1	1752072378	0	0	0	0	0	\N	\N	1	\N	\N
18	Frontend - Video Call Integration	Add video calling to messaging system.\n\nRequirements:\n- WebRTC implementation\n- Screen sharing capability\n- Recording options\n- In-call chat\n- Call scheduling\n- Integration with existing messaging\n\nOptions: Daily.co, Twilio Video, or Jitsi	1752072394	purple	1	1	0	17	t	\N	0	0	0	0	1752072394		0	\N	\N	1	1752072394	0	0	0	0	0	\N	\N	1	\N	\N
7	Testing Infrastructure - Unit Tests	Implement comprehensive unit testing across the codebase.\n\n## Current: 20% complete\n## Target: 80% code coverage\n\n## Areas to cover:\n- API endpoints (Fastify routes)\n- Business logic services\n- Database models (Prisma)\n- Utility functions\n- React components\n\n## Documentation Links:\n- 📚 Testing Guide: http://localhost:3005/development/testing/methodology\n- 📚 Coverage Types: http://localhost:3005/development/testing/types-and-coverage\n- 🎯 Test Examples: Check existing test files in `/apps/api/src/__tests__/`\n- 📖 Best Practices: http://localhost:3005/development/workflows/complete-workflow\n\n## Testing Structure:\n```\n/apps/api/src/__tests__/\n  /routes/    # API endpoint tests\n  /services/  # Business logic tests\n  /utils/     # Utility function tests\n\n/apps/web/src/__tests__/\n  /components/  # React component tests\n  /hooks/       # Custom hook tests\n  /utils/       # Frontend utility tests\n```\n\n## Tools: Vitest, React Testing Library, MSW for API mocking	1752072308	orange	1	1	0	6	t	\N	0	0	0	0	1752072950		0	\N	\N	1	1752072308	0	0	0	0	0	\N	\N	2	\N	\N
5	Implement Data Retention Policies	Create and implement comprehensive data retention policies for GDPR compliance.\n\n## Requirements:\n- User data retention settings\n- Automatic data purging mechanisms\n- Audit trail for data deletions\n- Configurable retention periods per data type\n- Right to be forgotten implementation\n\n## Documentation Links:\n- 📚 Security Docs: http://localhost:3005/architecture/security\n- 📚 Audit System: http://localhost:3005/platform/system-management/audit-system\n- 🎯 Clickdummy - Platform: http://localhost:4040/platform/settings/data-retention.php\n- 🎯 Clickdummy - User: http://localhost:4040/user/settings.php#privacy\n- 📖 GDPR Guide: http://localhost:3005/architecture/security/gdpr-compliance\n\n## Implementation Across Tiers:\n1. **Platform**: Global retention policies, compliance dashboard\n2. **Tenant**: Marketplace-specific data rules\n3. **User**: Privacy settings, data export/delete requests\n\n## Technical Implementation:\n- Cron jobs for automatic data purging\n- Soft delete with retention periods\n- Audit log for all deletions\n- Data export API endpoints\n- Anonymization procedures\n\n## Related Tasks:\n- Parent: Security & Compliance Epic\n- Related: #4 (MFA), #21 (Audit System)\n\nPriority: Critical for compliance	1752072292	red	1	1	0	4	t	\N	0	0	0	0	1752073066		0	\N	\N	1	1752072292	0	0	0	0	0	\N	\N	3	\N	\N
19	Documentation - API Reference Update	Update OpenAPI documentation for all new endpoints.\n\nTasks:\n- Document payment endpoints\n- Document analytics endpoints  \n- Add example requests/responses\n- Update Postman collection\n- Generate TypeScript types\n- Update API versioning guide	1752072401	grey	1	1	0	18	t	\N	0	0	0	0	1752072401		0	\N	\N	1	1752072401	0	0	0	0	0	\N	\N	0	\N	\N
20	Infrastructure - CI/CD Pipeline Enhancement	Improve GitHub Actions workflows.\n\nEnhancements:\n- Add automated testing on PR\n- Implement deployment previews\n- Add security scanning (Snyk/Dependabot)\n- Performance regression tests\n- Automated changelog generation\n- Docker image optimization	1752072409	grey	1	1	0	19	t	\N	0	0	0	0	1752072409		0	\N	\N	1	1752072409	0	0	0	0	0	\N	\N	1	\N	\N
21	Bug - Missing Portfolio Analytics	Portfolio analytics feature is documented but not implemented.\n\nMissing functionality:\n- View counts tracking\n- Engagement metrics\n- Conversion tracking\n- Performance over time graphs\n- Comparison with peers\n\nAffects user dashboard experience	1752072418	red	1	1	0	20	t	\N	0	0	0	0	1752072418		0	\N	\N	1	1752072418	0	0	0	0	0	\N	\N	1	\N	\N
22	Bug - Advanced Deployment Settings Missing	Deployment configuration options are not available in admin panel.\n\nMissing features:\n- Environment variable management\n- Feature flags configuration\n- Rollback mechanisms\n- Blue-green deployment settings\n- Auto-scaling configuration\n\nCurrently requires manual intervention	1752072424	orange	1	1	0	21	t	\N	0	0	0	0	1752072424		0	\N	\N	1	1752072424	0	0	0	0	0	\N	\N	1	\N	\N
23	PROJECT STATUS: Itellico Mono - Q1 2025 Roadmap	## Overall Project Status: 85% Core + 40% Advanced Features\n\n### Critical Issues (Priority 3):\n- [ ] Multi-Factor Authentication\n- [ ] Data Retention Policies  \n- [ ] Payment Integration (Stripe)\n\n### Q1 2025 Priorities (Priority 2):\n- [ ] Testing Infrastructure (20% → 80%)\n- [ ] Performance Optimization (60% → 95%)\n- [ ] Advanced Analytics (30% → 80%)\n\n### In Development (Priority 1):\n- [ ] Mobile PWA (40% → 100%)\n- [ ] Social Login Integration\n- [ ] Workflow Automation\n- [ ] Content Approval System\n\n### Metrics:\n- API Endpoints: 190+ implemented\n- Database Models: 40+ tables\n- Admin Modules: 30+ complete\n- Target Users: 700,000+\n\nUpdated weekly. Check individual tasks for details.	1752072482	green	1	1	0	22	t	\N	0	0	0	0	1752072482		0	\N	\N	1	1752072482	0	0	0	0	0	\N	\N	3	\N	\N
4	Implement Multi-Factor Authentication (MFA)	Implement MFA for enhanced security. This is a critical security requirement currently missing from the platform.\n\n## Requirements:\n- Support for TOTP (Time-based One-Time Password)\n- SMS-based authentication as backup\n- Recovery codes generation\n- Integration with existing JWT auth system\n\n## Documentation Links:\n- 📚 Docs: http://localhost:3005/architecture/security/authentication\n- 🎯 Clickdummy: http://localhost:4040/user/settings.php (Security Settings section)\n- 📖 API Design: http://localhost:3005/architecture/api-design\n\n## Tech Stack:\n- Fastify backend\n- speakeasy library for TOTP\n- Redis for temporary code storage\n\n## Subtasks:\n1. Create API endpoints for MFA setup/verify\n2. Update authentication flow documentation\n3. Add MFA UI components to settings page\n4. Create recovery code generation system\n5. Update clickdummy with MFA mockups	1752072285	red	1	1	0	3	t	\N	0	0	0	0	1752072905		0	\N	\N	1	1752072285	0	0	0	0	0	\N	\N	3	\N	\N
24	SUBTASK: Document MFA Implementation Guide	Create comprehensive documentation for Multi-Factor Authentication implementation.\n\n## Parent Task: #4 - Implement Multi-Factor Authentication (MFA)\n\n## Documentation Tasks:\n1. Create `/docs/architecture/security/mfa-implementation.md`\n2. Document API endpoints for MFA\n3. Create user guide for MFA setup\n4. Add MFA flow diagrams\n5. Update authentication.md with MFA details\n\n## Links:\n- 📚 Target: http://localhost:3005/architecture/security/mfa-implementation\n- 🔗 Parent Task: #4\n- 📖 Related: http://localhost:3005/architecture/security/authentication	1752072917	grey	1	1	0	23	t	\N	0	0	0	0	1752072917		0	\N	\N	1	1752072917	0	0	0	0	0	\N	\N	2	\N	\N
6	Payment Integration - Stripe Connect	Implement complete payment system using Stripe Connect for marketplace transactions.\n\n## Requirements:\n- Stripe Connect onboarding for vendors\n- Payment processing for jobs/gigs\n- Escrow system implementation\n- Invoice generation\n- Commission handling\n- Refund mechanisms\n\n## Documentation Links:\n- 📚 Docs: http://localhost:3005/platform/subscription-management\n- 🎯 Clickdummy - User: http://localhost:4040/user/wallet.php\n- 🎯 Clickdummy - Tenant: http://localhost:4040/tenant/finance/payments.php\n- 🎯 Clickdummy - Platform: http://localhost:4040/platform/finance/overview.php\n- 📖 API Design: http://localhost:3005/architecture/api-design\n\n## Implementation Areas:\n1. Platform Level: Global payment settings, commission rates\n2. Tenant Level: Marketplace-specific payment rules\n3. User Level: Wallet, transactions, payouts\n\n## Current Status: 0% complete\nPriority: Critical for marketplace functionality	1752072300	red	1	1	0	5	t	\N	0	0	0	0	1752072928		0	\N	\N	1	1752072300	0	0	0	0	0	\N	\N	3	\N	\N
25	SUBTASK: Create Payment System Documentation	Document the complete payment system architecture and implementation guide.\n\n## Parent Task: #6 - Payment Integration - Stripe Connect\n\n## Documentation Tasks:\n1. Create `/docs/platform/payment-system/stripe-connect.md`\n2. Document payment flow diagrams (platform → tenant → user)\n3. Create API endpoint documentation for payments\n4. Write integration testing guide\n5. Document escrow system design\n6. Create commission calculation guide\n\n## Clickdummy References:\n- User Wallet: http://localhost:4040/user/wallet.php\n- Payment History: http://localhost:4040/user/payment-history.php\n- Tenant Finance: http://localhost:4040/tenant/finance/payments.php\n\n## Links:\n- 📚 Target: http://localhost:3005/platform/payment-system\n- 🔗 Parent Task: #6\n- 📖 Related: http://localhost:3005/platform/subscription-management	1752072939	grey	1	1	0	24	t	\N	0	0	0	0	1752072939		0	\N	\N	1	1752072939	0	0	0	0	0	\N	\N	2	\N	\N
26	SUBTASK: Create Testing Documentation & Examples	Develop comprehensive testing documentation with examples for all test types.\n\n## Parent Task: #7 - Testing Infrastructure - Unit Tests\n\n## Documentation Tasks:\n1. Create `/docs/development/testing/unit-test-guide.md`\n2. Add example tests for each component type\n3. Document testing patterns and anti-patterns\n4. Create test data management guide\n5. Write mock strategy documentation\n6. Add CI/CD testing integration guide\n\n## Example Coverage Areas:\n- Fastify route testing examples\n- Prisma model testing patterns\n- React component testing with RTL\n- Custom hook testing strategies\n- API mocking with MSW\n\n## Links:\n- 📚 Target: http://localhost:3005/development/testing/unit-test-guide\n- 🔗 Parent Task: #7\n- 📖 Related: http://localhost:3005/development/testing/methodology	1752072960	grey	1	1	0	25	t	\N	0	0	0	0	1752072960		0	\N	\N	1	1752072960	0	0	0	0	0	\N	\N	1	\N	\N
17	Frontend - Advanced User Analytics Dashboard	Build comprehensive analytics dashboard for users.\n\n## Components needed:\n- Revenue charts (Chart.js/Recharts)\n- Performance metrics cards\n- Activity timeline\n- Conversion funnel visualization\n- Export functionality\n- Date range filters\n\n## Documentation Links:\n- 📚 Platform Analytics: http://localhost:3005/platform/system-management\n- 🎯 Clickdummy - User: http://localhost:4040/user/analytics/overview.php\n- 🎯 Clickdummy - Account: http://localhost:4040/account/analytics/performance.php\n- 🎯 Clickdummy - Tenant: http://localhost:4040/tenant/analytics/overview.php\n- 📖 Component Patterns: http://localhost:3005/architecture/performance/react-patterns\n\n## Implementation Reference:\n- User Level: Personal performance metrics\n- Account Level: Team/agency analytics\n- Tenant Level: Marketplace-wide analytics\n- Platform Level: Global system analytics\n\n## Currently missing from platform - Priority for user engagement	1752072387	purple	1	1	0	16	t	\N	0	0	0	0	1752072973		0	\N	\N	1	1752072387	0	0	0	0	0	\N	\N	1	\N	\N
27	SUBTASK: Document Analytics Dashboard Architecture	Create documentation for the multi-tier analytics system.\n\n## Parent Task: #17 - Frontend - Advanced User Analytics Dashboard\n\n## Documentation Tasks:\n1. Create `/docs/platform/analytics/dashboard-architecture.md`\n2. Document data flow for each tier's analytics\n3. Create component library for chart types\n4. Write performance optimization guide for large datasets\n5. Document export formats and API endpoints\n6. Add real-time update strategies\n\n## Tier-Specific Documentation:\n- Platform: System-wide metrics and monitoring\n- Tenant: Marketplace performance and trends\n- Account: Team productivity and revenue\n- User: Individual performance tracking\n\n## Clickdummy References:\n- User Analytics: http://localhost:4040/user/analytics/overview.php\n- Account Analytics: http://localhost:4040/account/analytics/performance.php\n- Tenant Analytics: http://localhost:4040/tenant/analytics/overview.php\n- Platform Analytics: http://localhost:4040/platform/analytics/system.php\n\n## Links:\n- 📚 Target: http://localhost:3005/platform/analytics/dashboard-architecture\n- 🔗 Parent Task: #17\n- 📖 Related: http://localhost:3005/architecture/performance/three-layer-caching	1752072988	grey	1	1	0	26	t	\N	0	0	0	0	1752072988		0	\N	\N	1	1752072988	0	0	0	0	0	\N	\N	1	\N	\N
14	Content Approval Workflows	Implement content moderation and approval system.\n\n## Requirements:\n- Multi-level approval chains\n- Role-based review assignments\n- Automated content checks\n- Manual review interface\n- Rejection reasons & feedback\n- Version control for content\n\n## Documentation Links:\n- 📚 Content Management: http://localhost:3005/platform/content-management\n- 📚 RBAC System: http://localhost:3005/platform/access-control/rbac-system\n- 🎯 Clickdummy - Moderation: http://localhost:4040/tenant/content/moderation.php\n- 🎯 Clickdummy - Review Queue: http://localhost:4040/account/content/review-queue.php\n- 📖 Workflow Patterns: http://localhost:3005/architecture/system-design\n\n## Implementation Levels:\n1. Platform: Global content policies, AI moderation rules\n2. Tenant: Marketplace-specific approval workflows\n3. Account: Team review assignments\n4. User: Content submission and revision interface\n\n## Integration Points:\n- Temporal workflow engine for approval chains\n- AI content moderation (text, image analysis)\n- Notification system for reviewers\n- Audit trail for all approval actions\n\n## Missing from current system - affects content quality control	1752072358	yellow	1	1	0	13	t	\N	0	0	0	0	1752073000		0	\N	\N	1	1752072358	0	0	0	0	0	\N	\N	1	\N	\N
28	SUBTASK: Design Content Approval Workflow System	Document the complete content approval and moderation system design.\n\n## Parent Task: #14 - Content Approval Workflows\n\n## Documentation Tasks:\n1. Create `/docs/platform/content-management/approval-workflows.md`\n2. Design approval chain configuration schema\n3. Document AI moderation integration points\n4. Create reviewer interface wireframes\n5. Write notification flow documentation\n6. Design audit trail structure\n\n## Workflow Examples:\n- Job posting approval (User → Account → Tenant)\n- Profile verification (User → Platform moderator)\n- Content flagging system (Community → Tenant admin)\n- Template approval (Tenant → Platform)\n\n## Clickdummy References:\n- Moderation Dashboard: http://localhost:4040/tenant/content/moderation.php\n- Review Queue: http://localhost:4040/account/content/review-queue.php\n- Content Policies: http://localhost:4040/platform/settings/content-policies.php\n\n## Links:\n- 📚 Target: http://localhost:3005/platform/content-management/approval-workflows\n- 🔗 Parent Task: #14\n- 📖 Related: http://localhost:3005/platform/access-control/permission-matrix	1752073011	grey	1	1	0	27	t	\N	0	0	0	0	1752073011		0	\N	\N	1	1752073011	0	0	0	0	0	\N	\N	1	\N	\N
29	TEMPLATE: Standard Task Format with Links	## 📋 Task Template - Use this format for all new tasks\n\n## Overview:\nBrief description of what needs to be implemented.\n\n## Requirements:\n- Requirement 1\n- Requirement 2\n- Requirement 3\n\n## Documentation Links:\n- 📚 Main Docs: http://localhost:3005/[relevant-section]\n- 🎯 Clickdummy: http://localhost:4040/[tier]/[page].php\n- 📖 API Reference: http://localhost:3001/docs#/[endpoint-group]\n- 🔧 Dev Guide: http://localhost:3005/development/[guide]\n\n## Implementation Tiers:\n1. **Platform**: [What platform admins need]\n2. **Tenant**: [What tenant admins need]\n3. **Account**: [What account managers need]\n4. **User**: [What end users need]\n5. **Public**: [What public visitors see]\n\n## Technical Details:\n- Frontend: [Components/pages to create]\n- Backend: [API endpoints needed]\n- Database: [Models/migrations required]\n- Cache: [Redis keys/strategies]\n\n## Related Tasks:\n- Parent: #[parent-task-id]\n- Blocks: #[task-ids-this-blocks]\n- Blocked by: #[task-ids-blocking-this]\n- Related: #[related-task-ids]\n\n## Acceptance Criteria:\n- [ ] Criterion 1\n- [ ] Criterion 2\n- [ ] Tests written and passing\n- [ ] Documentation updated\n\n## Subtasks Required:\n1. Create documentation (#[doc-task-id])\n2. Update clickdummy mockups\n3. Implement API endpoints\n4. Build frontend components\n5. Write tests\n6. Update changelog	1752073028	teal	1	1	0	28	t	\N	0	0	0	0	1752073028		0	\N	\N	1	1752073028	0	0	0	0	0	\N	\N	0	\N	\N
30	REFERENCE: Clickdummy & Documentation Index	## 🗺️ Complete Reference Map for itellico Mono\n\n## Clickdummy URLs (http://localhost:4040)\n\n### Platform Tier (/platform/)\n- Dashboard: /platform/dashboard.php\n- Tenants: /platform/tenants/list.php\n- Features: /platform/features/list.php\n- Analytics: /platform/analytics/system.php\n- Finance: /platform/finance/overview.php\n- Settings: /platform/settings/general.php\n\n### Tenant Tier (/tenant/)\n- Dashboard: /tenant/dashboard.php\n- Accounts: /tenant/accounts/list.php\n- Plans: /tenant/plans/list.php\n- Content: /tenant/content/moderation.php\n- Analytics: /tenant/analytics/overview.php\n- Finance: /tenant/finance/payments.php\n\n### Account Tier (/account/)\n- Dashboard: /account/dashboard.php\n- Team: /account/team/members.php\n- Projects: /account/projects/list.php\n- Analytics: /account/analytics/performance.php\n- Content: /account/content/review-queue.php\n\n### User Tier (/user/)\n- Profile: /user/profile.php\n- Portfolio: /user/portfolio/showcase.php\n- Jobs: /user/jobs/browse.php\n- Messages: /user/messages/inbox.php\n- Wallet: /user/wallet.php\n- Settings: /user/settings.php\n- Analytics: /user/analytics/overview.php\n\n### Public Tier (/public/)\n- Homepage: /public/index.php\n- Marketplace: /public/marketplace/browse.php\n- Job Board: /public/jobs/listings.php\n- Profiles: /public/profiles/search.php\n\n## Documentation Structure (http://localhost:3005)\n\n### Architecture (/architecture/)\n- System Design\n- API Design\n- Data Models\n- Security\n- Performance\n\n### Platform Features (/platform/)\n- Access Control & RBAC\n- Content Management\n- Subscription Management\n- Developer Tools\n- System Management\n\n### Development (/development/)\n- Getting Started\n- Testing\n- Deployment\n- Tools\n- Workflows\n\n## API Documentation\n- Swagger/OpenAPI: http://localhost:3001/docs\n- Postman Collection: /docs/api/postman-collection.json\n\n## Quick Links for Common Tasks:\n1. Add new feature: Check clickdummy → Create API → Build UI → Document\n2. Fix bug: Reproduce in clickdummy → Fix → Test → Update docs\n3. New API endpoint: Design in OpenAPI → Implement → Test → Document\n\n## Task Relationships:\n- Features link to multiple clickdummy pages\n- Each tier has specific documentation sections\n- API endpoints map to clickdummy functionality\n- Tests verify clickdummy behavior matches implementation	1752073051	cyan	1	1	0	29	t	\N	0	0	0	0	1752073051		0	\N	\N	1	1752073051	0	0	0	0	0	\N	\N	3	\N	\N
31	SUBTASK: GDPR Compliance Documentation	Create comprehensive GDPR compliance documentation and implementation guide.\n\n## Parent Task: #5 - Implement Data Retention Policies\n\n## Documentation Tasks:\n1. Create `/docs/architecture/security/gdpr-compliance.md`\n2. Document data retention policy templates\n3. Create user data rights documentation\n4. Write data purging procedures\n5. Design compliance audit checklist\n6. Create privacy policy templates\n\n## Implementation Guides:\n- Right to access (data export)\n- Right to rectification (data updates)\n- Right to erasure (data deletion)\n- Right to portability (data transfer)\n- Consent management system\n\n## Clickdummy References:\n- Platform Compliance: http://localhost:4040/platform/settings/data-retention.php\n- User Privacy: http://localhost:4040/user/settings.php#privacy\n- Data Export: http://localhost:4040/user/settings.php#export-data\n\n## Links:\n- 📚 Target: http://localhost:3005/architecture/security/gdpr-compliance\n- 🔗 Parent Task: #5\n- 📖 Related: http://localhost:3005/platform/system-management/audit-system	1752073077	grey	1	1	0	30	t	\N	0	0	0	0	1752073077		0	\N	\N	1	1752073077	0	0	0	0	0	\N	\N	2	\N	\N
\.


--
-- Data for Name: transitions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.transitions (id, user_id, project_id, task_id, src_column_id, dst_column_id, date, time_spent) FROM stdin;
\.


--
-- Data for Name: user_has_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.user_has_metadata (user_id, name, value, changed_by, changed_on) FROM stdin;
\.


--
-- Data for Name: user_has_notification_types; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.user_has_notification_types (id, user_id, notification_type) FROM stdin;
\.


--
-- Data for Name: user_has_notifications; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.user_has_notifications (user_id, project_id) FROM stdin;
\.


--
-- Data for Name: user_has_unread_notifications; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.user_has_unread_notifications (id, user_id, date_creation, event_name, event_data) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.users (id, username, password, is_ldap_user, name, email, google_id, github_id, notifications_enabled, timezone, language, disable_login_form, twofactor_activated, twofactor_secret, token, notifications_filter, nb_failed_login, lock_expiration_date, gitlab_id, role, is_active, avatar_path, api_access_token, filter, theme) FROM stdin;
1	admin	$2y$10$rJ9jGas8srQP7BuByccgJueXRTAMHMNt8KMNNtfIkYWo/XX86FlZu	f	\N	\N	\N	\N	f	\N	\N	f	f	\N		4	0	0	\N	app-admin	t	\N	\N	\N	light
\.


--
-- Name: action_has_params_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.action_has_params_id_seq', 1, false);


--
-- Name: actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.actions_id_seq', 1, false);


--
-- Name: column_has_move_restrictions_restriction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.column_has_move_restrictions_restriction_id_seq', 1, false);


--
-- Name: column_has_restrictions_restriction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.column_has_restrictions_restriction_id_seq', 1, false);


--
-- Name: columns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.columns_id_seq', 4, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.comments_id_seq', 1, false);


--
-- Name: custom_filters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.custom_filters_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- Name: last_logins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.last_logins_id_seq', 1, true);


--
-- Name: links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.links_id_seq', 11, true);


--
-- Name: predefined_task_descriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.predefined_task_descriptions_id_seq', 1, false);


--
-- Name: project_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_activities_id_seq', 1, false);


--
-- Name: project_daily_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_daily_stats_id_seq', 37, true);


--
-- Name: project_daily_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_daily_summaries_id_seq', 37, true);


--
-- Name: project_has_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_has_categories_id_seq', 1, false);


--
-- Name: project_has_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_has_files_id_seq', 1, false);


--
-- Name: project_has_notification_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_has_notification_types_id_seq', 1, false);


--
-- Name: project_has_roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_has_roles_role_id_seq', 1, false);


--
-- Name: project_role_has_restrictions_restriction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.project_role_has_restrictions_restriction_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, true);


--
-- Name: remember_me_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.remember_me_id_seq', 1, true);


--
-- Name: subtask_time_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.subtask_time_tracking_id_seq', 1, false);


--
-- Name: swimlanes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.swimlanes_id_seq', 1, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.tags_id_seq', 29, true);


--
-- Name: task_has_external_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.task_has_external_links_id_seq', 1, false);


--
-- Name: task_has_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.task_has_files_id_seq', 1, false);


--
-- Name: task_has_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.task_has_links_id_seq', 1, false);


--
-- Name: task_has_subtasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.task_has_subtasks_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.tasks_id_seq', 31, true);


--
-- Name: transitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.transitions_id_seq', 1, false);


--
-- Name: user_has_notification_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.user_has_notification_types_id_seq', 1, false);


--
-- Name: user_has_unread_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.user_has_unread_notifications_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: action_has_params action_has_params_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.action_has_params
    ADD CONSTRAINT action_has_params_pkey PRIMARY KEY (id);


--
-- Name: actions actions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_pkey PRIMARY KEY (id);


--
-- Name: column_has_move_restrictions column_has_move_restrictions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_pkey PRIMARY KEY (restriction_id);


--
-- Name: column_has_move_restrictions column_has_move_restrictions_role_id_src_column_id_dst_colu_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_role_id_src_column_id_dst_colu_key UNIQUE (role_id, src_column_id, dst_column_id);


--
-- Name: column_has_restrictions column_has_restrictions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions
    ADD CONSTRAINT column_has_restrictions_pkey PRIMARY KEY (restriction_id);


--
-- Name: column_has_restrictions column_has_restrictions_role_id_column_id_rule_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions
    ADD CONSTRAINT column_has_restrictions_role_id_column_id_rule_key UNIQUE (role_id, column_id, rule);


--
-- Name: columns columns_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.columns
    ADD CONSTRAINT columns_pkey PRIMARY KEY (id);


--
-- Name: columns columns_title_project_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.columns
    ADD CONSTRAINT columns_title_project_id_key UNIQUE (title, project_id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_currency_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_currency_key UNIQUE (currency);


--
-- Name: custom_filters custom_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.custom_filters
    ADD CONSTRAINT custom_filters_pkey PRIMARY KEY (id);


--
-- Name: group_has_users group_has_users_group_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.group_has_users
    ADD CONSTRAINT group_has_users_group_id_user_id_key UNIQUE (group_id, user_id);


--
-- Name: groups groups_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_name_key UNIQUE (name);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: invites invites_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_pkey PRIMARY KEY (email, token);


--
-- Name: last_logins last_logins_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.last_logins
    ADD CONSTRAINT last_logins_pkey PRIMARY KEY (id);


--
-- Name: links links_label_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_label_key UNIQUE (label);


--
-- Name: links links_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_pkey PRIMARY KEY (id);


--
-- Name: password_reset password_reset_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.password_reset
    ADD CONSTRAINT password_reset_pkey PRIMARY KEY (token);


--
-- Name: plugin_schema_versions plugin_schema_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.plugin_schema_versions
    ADD CONSTRAINT plugin_schema_versions_pkey PRIMARY KEY (plugin);


--
-- Name: predefined_task_descriptions predefined_task_descriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.predefined_task_descriptions
    ADD CONSTRAINT predefined_task_descriptions_pkey PRIMARY KEY (id);


--
-- Name: project_activities project_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_activities
    ADD CONSTRAINT project_activities_pkey PRIMARY KEY (id);


--
-- Name: project_daily_stats project_daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_stats
    ADD CONSTRAINT project_daily_stats_pkey PRIMARY KEY (id);


--
-- Name: project_daily_column_stats project_daily_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_column_stats
    ADD CONSTRAINT project_daily_summaries_pkey PRIMARY KEY (id);


--
-- Name: project_has_categories project_has_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_categories
    ADD CONSTRAINT project_has_categories_pkey PRIMARY KEY (id);


--
-- Name: project_has_categories project_has_categories_project_id_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_categories
    ADD CONSTRAINT project_has_categories_project_id_name_key UNIQUE (project_id, name);


--
-- Name: project_has_files project_has_files_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_files
    ADD CONSTRAINT project_has_files_pkey PRIMARY KEY (id);


--
-- Name: project_has_groups project_has_groups_group_id_project_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_groups
    ADD CONSTRAINT project_has_groups_group_id_project_id_key UNIQUE (group_id, project_id);


--
-- Name: project_has_metadata project_has_metadata_project_id_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_metadata
    ADD CONSTRAINT project_has_metadata_project_id_name_key UNIQUE (project_id, name);


--
-- Name: project_has_notification_types project_has_notification_types_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_notification_types
    ADD CONSTRAINT project_has_notification_types_pkey PRIMARY KEY (id);


--
-- Name: project_has_notification_types project_has_notification_types_project_id_notification_type_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_notification_types
    ADD CONSTRAINT project_has_notification_types_project_id_notification_type_key UNIQUE (project_id, notification_type);


--
-- Name: project_has_roles project_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_roles
    ADD CONSTRAINT project_has_roles_pkey PRIMARY KEY (role_id);


--
-- Name: project_has_roles project_has_roles_project_id_role_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_roles
    ADD CONSTRAINT project_has_roles_project_id_role_key UNIQUE (project_id, role);


--
-- Name: project_has_users project_has_users_project_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_users
    ADD CONSTRAINT project_has_users_project_id_user_id_key UNIQUE (project_id, user_id);


--
-- Name: project_role_has_restrictions project_role_has_restrictions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_role_has_restrictions
    ADD CONSTRAINT project_role_has_restrictions_pkey PRIMARY KEY (restriction_id);


--
-- Name: project_role_has_restrictions project_role_has_restrictions_role_id_rule_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_role_has_restrictions
    ADD CONSTRAINT project_role_has_restrictions_role_id_rule_key UNIQUE (role_id, rule);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: remember_me remember_me_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.remember_me
    ADD CONSTRAINT remember_me_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (option);


--
-- Name: subtask_time_tracking subtask_time_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtask_time_tracking
    ADD CONSTRAINT subtask_time_tracking_pkey PRIMARY KEY (id);


--
-- Name: swimlanes swimlanes_name_project_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.swimlanes
    ADD CONSTRAINT swimlanes_name_project_id_key UNIQUE (name, project_id);


--
-- Name: swimlanes swimlanes_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.swimlanes
    ADD CONSTRAINT swimlanes_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_project_id_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_project_id_name_key UNIQUE (project_id, name);


--
-- Name: task_has_external_links task_has_external_links_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_external_links
    ADD CONSTRAINT task_has_external_links_pkey PRIMARY KEY (id);


--
-- Name: task_has_files task_has_files_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_files
    ADD CONSTRAINT task_has_files_pkey PRIMARY KEY (id);


--
-- Name: task_has_links task_has_links_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_links
    ADD CONSTRAINT task_has_links_pkey PRIMARY KEY (id);


--
-- Name: task_has_metadata task_has_metadata_task_id_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_metadata
    ADD CONSTRAINT task_has_metadata_task_id_name_key UNIQUE (task_id, name);


--
-- Name: subtasks task_has_subtasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtasks
    ADD CONSTRAINT task_has_subtasks_pkey PRIMARY KEY (id);


--
-- Name: task_has_tags task_has_tags_tag_id_task_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_tags
    ADD CONSTRAINT task_has_tags_tag_id_task_id_key UNIQUE (tag_id, task_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: transitions transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_pkey PRIMARY KEY (id);


--
-- Name: user_has_metadata user_has_metadata_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_metadata
    ADD CONSTRAINT user_has_metadata_user_id_name_key UNIQUE (user_id, name);


--
-- Name: user_has_notification_types user_has_notification_types_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notification_types
    ADD CONSTRAINT user_has_notification_types_pkey PRIMARY KEY (id);


--
-- Name: user_has_notifications user_has_notifications_project_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notifications
    ADD CONSTRAINT user_has_notifications_project_id_user_id_key UNIQUE (project_id, user_id);


--
-- Name: user_has_unread_notifications user_has_unread_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_unread_notifications
    ADD CONSTRAINT user_has_unread_notifications_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: categories_project_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX categories_project_idx ON public.project_has_categories USING btree (project_id);


--
-- Name: columns_project_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX columns_project_idx ON public.columns USING btree (project_id);


--
-- Name: comments_reference_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX comments_reference_idx ON public.comments USING btree (reference);


--
-- Name: comments_task_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX comments_task_idx ON public.comments USING btree (task_id);


--
-- Name: files_task_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX files_task_idx ON public.task_has_files USING btree (task_id);


--
-- Name: project_daily_column_stats_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX project_daily_column_stats_idx ON public.project_daily_column_stats USING btree (day, project_id, column_id);


--
-- Name: project_daily_stats_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX project_daily_stats_idx ON public.project_daily_stats USING btree (day, project_id);


--
-- Name: subtasks_task_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX subtasks_task_idx ON public.subtasks USING btree (task_id);


--
-- Name: swimlanes_project_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX swimlanes_project_idx ON public.swimlanes USING btree (project_id);


--
-- Name: task_has_links_task_index; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX task_has_links_task_index ON public.task_has_links USING btree (task_id);


--
-- Name: task_has_links_unique; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX task_has_links_unique ON public.task_has_links USING btree (link_id, task_id, opposite_task_id);


--
-- Name: tasks_project_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX tasks_project_idx ON public.tasks USING btree (project_id);


--
-- Name: tasks_reference_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX tasks_reference_idx ON public.tasks USING btree (reference);


--
-- Name: transitions_project_index; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX transitions_project_index ON public.transitions USING btree (project_id);


--
-- Name: transitions_task_index; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX transitions_task_index ON public.transitions USING btree (task_id);


--
-- Name: transitions_user_index; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX transitions_user_index ON public.transitions USING btree (user_id);


--
-- Name: user_has_notification_types_user_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX user_has_notification_types_user_idx ON public.user_has_notification_types USING btree (user_id, notification_type);


--
-- Name: users_username_idx; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX users_username_idx ON public.users USING btree (username);


--
-- Name: action_has_params action_has_params_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.action_has_params
    ADD CONSTRAINT action_has_params_action_id_fkey FOREIGN KEY (action_id) REFERENCES public.actions(id) ON DELETE CASCADE;


--
-- Name: actions actions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: column_has_move_restrictions column_has_move_restrictions_dst_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_dst_column_id_fkey FOREIGN KEY (dst_column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: column_has_move_restrictions column_has_move_restrictions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: column_has_move_restrictions column_has_move_restrictions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.project_has_roles(role_id) ON DELETE CASCADE;


--
-- Name: column_has_move_restrictions column_has_move_restrictions_src_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_move_restrictions
    ADD CONSTRAINT column_has_move_restrictions_src_column_id_fkey FOREIGN KEY (src_column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: column_has_restrictions column_has_restrictions_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions
    ADD CONSTRAINT column_has_restrictions_column_id_fkey FOREIGN KEY (column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: column_has_restrictions column_has_restrictions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions
    ADD CONSTRAINT column_has_restrictions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: column_has_restrictions column_has_restrictions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.column_has_restrictions
    ADD CONSTRAINT column_has_restrictions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.project_has_roles(role_id) ON DELETE CASCADE;


--
-- Name: columns columns_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.columns
    ADD CONSTRAINT columns_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: comments comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: group_has_users group_has_users_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.group_has_users
    ADD CONSTRAINT group_has_users_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_has_users group_has_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.group_has_users
    ADD CONSTRAINT group_has_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: last_logins last_logins_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.last_logins
    ADD CONSTRAINT last_logins_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset password_reset_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.password_reset
    ADD CONSTRAINT password_reset_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: predefined_task_descriptions predefined_task_descriptions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.predefined_task_descriptions
    ADD CONSTRAINT predefined_task_descriptions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_activities project_activities_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_activities
    ADD CONSTRAINT project_activities_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: project_activities project_activities_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_activities
    ADD CONSTRAINT project_activities_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_activities project_activities_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_activities
    ADD CONSTRAINT project_activities_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: project_daily_stats project_daily_stats_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_stats
    ADD CONSTRAINT project_daily_stats_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_daily_column_stats project_daily_summaries_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_column_stats
    ADD CONSTRAINT project_daily_summaries_column_id_fkey FOREIGN KEY (column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: project_daily_column_stats project_daily_summaries_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_daily_column_stats
    ADD CONSTRAINT project_daily_summaries_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_categories project_has_categories_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_categories
    ADD CONSTRAINT project_has_categories_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_files project_has_files_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_files
    ADD CONSTRAINT project_has_files_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_groups project_has_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_groups
    ADD CONSTRAINT project_has_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: project_has_groups project_has_groups_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_groups
    ADD CONSTRAINT project_has_groups_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_metadata project_has_metadata_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_metadata
    ADD CONSTRAINT project_has_metadata_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_notification_types project_has_notification_types_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_notification_types
    ADD CONSTRAINT project_has_notification_types_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_roles project_has_roles_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_roles
    ADD CONSTRAINT project_has_roles_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_users project_has_users_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_users
    ADD CONSTRAINT project_has_users_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_has_users project_has_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_has_users
    ADD CONSTRAINT project_has_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: project_role_has_restrictions project_role_has_restrictions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_role_has_restrictions
    ADD CONSTRAINT project_role_has_restrictions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_role_has_restrictions project_role_has_restrictions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_role_has_restrictions
    ADD CONSTRAINT project_role_has_restrictions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.project_has_roles(role_id) ON DELETE CASCADE;


--
-- Name: remember_me remember_me_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.remember_me
    ADD CONSTRAINT remember_me_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subtask_time_tracking subtask_time_tracking_subtask_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtask_time_tracking
    ADD CONSTRAINT subtask_time_tracking_subtask_id_fkey FOREIGN KEY (subtask_id) REFERENCES public.subtasks(id) ON DELETE CASCADE;


--
-- Name: subtask_time_tracking subtask_time_tracking_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtask_time_tracking
    ADD CONSTRAINT subtask_time_tracking_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: swimlanes swimlanes_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.swimlanes
    ADD CONSTRAINT swimlanes_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: task_has_external_links task_has_external_links_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_external_links
    ADD CONSTRAINT task_has_external_links_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_has_files task_has_files_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_files
    ADD CONSTRAINT task_has_files_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_has_links task_has_links_link_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_links
    ADD CONSTRAINT task_has_links_link_id_fkey FOREIGN KEY (link_id) REFERENCES public.links(id) ON DELETE CASCADE;


--
-- Name: task_has_links task_has_links_opposite_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_links
    ADD CONSTRAINT task_has_links_opposite_task_id_fkey FOREIGN KEY (opposite_task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_has_links task_has_links_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_links
    ADD CONSTRAINT task_has_links_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_has_metadata task_has_metadata_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_metadata
    ADD CONSTRAINT task_has_metadata_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: subtasks task_has_subtasks_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.subtasks
    ADD CONSTRAINT task_has_subtasks_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_has_tags task_has_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_tags
    ADD CONSTRAINT task_has_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: task_has_tags task_has_tags_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_has_tags
    ADD CONSTRAINT task_has_tags_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_column_id_fkey FOREIGN KEY (column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_swimlane_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_swimlane_id_fkey FOREIGN KEY (swimlane_id) REFERENCES public.swimlanes(id) ON DELETE CASCADE;


--
-- Name: transitions transitions_dst_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_dst_column_id_fkey FOREIGN KEY (dst_column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: transitions transitions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: transitions transitions_src_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_src_column_id_fkey FOREIGN KEY (src_column_id) REFERENCES public.columns(id) ON DELETE CASCADE;


--
-- Name: transitions transitions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: transitions transitions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transitions
    ADD CONSTRAINT transitions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_has_metadata user_has_metadata_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_metadata
    ADD CONSTRAINT user_has_metadata_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_has_notification_types user_has_notification_types_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notification_types
    ADD CONSTRAINT user_has_notification_types_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_has_notifications user_has_notifications_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notifications
    ADD CONSTRAINT user_has_notifications_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: user_has_notifications user_has_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_notifications
    ADD CONSTRAINT user_has_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_has_unread_notifications user_has_unread_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_has_unread_notifications
    ADD CONSTRAINT user_has_unread_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

--
-- Database "mono" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: mono; Type: DATABASE; Schema: -; Owner: developer
--

CREATE DATABASE mono WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE mono OWNER TO developer;

\connect mono

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "n8n" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: n8n; Type: DATABASE; Schema: -; Owner: developer
--

CREATE DATABASE n8n WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE n8n OWNER TO developer;

\connect n8n

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: annotation_tag_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.annotation_tag_entity (
    id character varying(16) NOT NULL,
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.annotation_tag_entity OWNER TO developer;

--
-- Name: auth_identity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.auth_identity (
    "userId" uuid,
    "providerId" character varying(64) NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.auth_identity OWNER TO developer;

--
-- Name: auth_provider_sync_history; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.auth_provider_sync_history (
    id integer NOT NULL,
    "providerType" character varying(32) NOT NULL,
    "runMode" text NOT NULL,
    status text NOT NULL,
    "startedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    scanned integer NOT NULL,
    created integer NOT NULL,
    updated integer NOT NULL,
    disabled integer NOT NULL,
    error text
);


ALTER TABLE public.auth_provider_sync_history OWNER TO developer;

--
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.auth_provider_sync_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_provider_sync_history_id_seq OWNER TO developer;

--
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.auth_provider_sync_history_id_seq OWNED BY public.auth_provider_sync_history.id;


--
-- Name: credentials_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.credentials_entity (
    name character varying(128) NOT NULL,
    data text NOT NULL,
    type character varying(128) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL,
    "isManaged" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.credentials_entity OWNER TO developer;

--
-- Name: event_destinations; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.event_destinations (
    id uuid NOT NULL,
    destination jsonb NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.event_destinations OWNER TO developer;

--
-- Name: execution_annotation_tags; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.execution_annotation_tags (
    "annotationId" integer NOT NULL,
    "tagId" character varying(24) NOT NULL
);


ALTER TABLE public.execution_annotation_tags OWNER TO developer;

--
-- Name: execution_annotations; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.execution_annotations (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    vote character varying(6),
    note text,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.execution_annotations OWNER TO developer;

--
-- Name: execution_annotations_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.execution_annotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.execution_annotations_id_seq OWNER TO developer;

--
-- Name: execution_annotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.execution_annotations_id_seq OWNED BY public.execution_annotations.id;


--
-- Name: execution_data; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.execution_data (
    "executionId" integer NOT NULL,
    "workflowData" json NOT NULL,
    data text NOT NULL
);


ALTER TABLE public.execution_data OWNER TO developer;

--
-- Name: execution_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.execution_entity (
    id integer NOT NULL,
    finished boolean NOT NULL,
    mode character varying NOT NULL,
    "retryOf" character varying,
    "retrySuccessId" character varying,
    "startedAt" timestamp(3) with time zone,
    "stoppedAt" timestamp(3) with time zone,
    "waitTill" timestamp(3) with time zone,
    status character varying NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "deletedAt" timestamp(3) with time zone,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.execution_entity OWNER TO developer;

--
-- Name: execution_entity_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.execution_entity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.execution_entity_id_seq OWNER TO developer;

--
-- Name: execution_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.execution_entity_id_seq OWNED BY public.execution_entity.id;


--
-- Name: execution_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.execution_metadata (
    id integer NOT NULL,
    "executionId" integer NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.execution_metadata OWNER TO developer;

--
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.execution_metadata_temp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.execution_metadata_temp_id_seq OWNER TO developer;

--
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.execution_metadata_temp_id_seq OWNED BY public.execution_metadata.id;


--
-- Name: folder; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.folder (
    id character varying(36) NOT NULL,
    name character varying(128) NOT NULL,
    "parentFolderId" character varying(36),
    "projectId" character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.folder OWNER TO developer;

--
-- Name: folder_tag; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.folder_tag (
    "folderId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


ALTER TABLE public.folder_tag OWNER TO developer;

--
-- Name: insights_by_period; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.insights_by_period (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "periodUnit" integer NOT NULL,
    "periodStart" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.insights_by_period OWNER TO developer;

--
-- Name: COLUMN insights_by_period.type; Type: COMMENT; Schema: public; Owner: developer
--

COMMENT ON COLUMN public.insights_by_period.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- Name: COLUMN insights_by_period."periodUnit"; Type: COMMENT; Schema: public; Owner: developer
--

COMMENT ON COLUMN public.insights_by_period."periodUnit" IS '0: hour, 1: day, 2: week';


--
-- Name: insights_by_period_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

ALTER TABLE public.insights_by_period ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.insights_by_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: insights_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.insights_metadata (
    "metaId" integer NOT NULL,
    "workflowId" character varying(16),
    "projectId" character varying(36),
    "workflowName" character varying(128) NOT NULL,
    "projectName" character varying(255) NOT NULL
);


ALTER TABLE public.insights_metadata OWNER TO developer;

--
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

ALTER TABLE public.insights_metadata ALTER COLUMN "metaId" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."insights_metadata_metaId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: insights_raw; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.insights_raw (
    id integer NOT NULL,
    "metaId" integer NOT NULL,
    type integer NOT NULL,
    value integer NOT NULL,
    "timestamp" timestamp(0) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.insights_raw OWNER TO developer;

--
-- Name: COLUMN insights_raw.type; Type: COMMENT; Schema: public; Owner: developer
--

COMMENT ON COLUMN public.insights_raw.type IS '0: time_saved_minutes, 1: runtime_milliseconds, 2: success, 3: failure';


--
-- Name: insights_raw_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

ALTER TABLE public.insights_raw ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.insights_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: installed_nodes; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.installed_nodes (
    name character varying(200) NOT NULL,
    type character varying(200) NOT NULL,
    "latestVersion" integer DEFAULT 1 NOT NULL,
    package character varying(241) NOT NULL
);


ALTER TABLE public.installed_nodes OWNER TO developer;

--
-- Name: installed_packages; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.installed_packages (
    "packageName" character varying(214) NOT NULL,
    "installedVersion" character varying(50) NOT NULL,
    "authorName" character varying(70),
    "authorEmail" character varying(70),
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.installed_packages OWNER TO developer;

--
-- Name: invalid_auth_token; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.invalid_auth_token (
    token character varying(512) NOT NULL,
    "expiresAt" timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.invalid_auth_token OWNER TO developer;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO developer;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO developer;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: processed_data; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.processed_data (
    "workflowId" character varying(36) NOT NULL,
    context character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.processed_data OWNER TO developer;

--
-- Name: project; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(36) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    icon json,
    description character varying(512)
);


ALTER TABLE public.project OWNER TO developer;

--
-- Name: project_relation; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.project_relation (
    "projectId" character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    role character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.project_relation OWNER TO developer;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.settings (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    "loadOnStartup" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.settings OWNER TO developer;

--
-- Name: shared_credentials; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.shared_credentials (
    "credentialsId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.shared_credentials OWNER TO developer;

--
-- Name: shared_workflow; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.shared_workflow (
    "workflowId" character varying(36) NOT NULL,
    "projectId" character varying(36) NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.shared_workflow OWNER TO developer;

--
-- Name: tag_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.tag_entity (
    name character varying(24) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    id character varying(36) NOT NULL
);


ALTER TABLE public.tag_entity OWNER TO developer;

--
-- Name: test_case_execution; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.test_case_execution (
    id character varying(36) NOT NULL,
    "testRunId" character varying(36) NOT NULL,
    "executionId" integer,
    status character varying NOT NULL,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    "errorCode" character varying,
    "errorDetails" json,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.test_case_execution OWNER TO developer;

--
-- Name: test_run; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.test_run (
    id character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    status character varying NOT NULL,
    "errorCode" character varying,
    "errorDetails" json,
    "runAt" timestamp(3) with time zone,
    "completedAt" timestamp(3) with time zone,
    metrics json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL
);


ALTER TABLE public.test_run OWNER TO developer;

--
-- Name: user; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public."user" (
    id uuid DEFAULT uuid_in((OVERLAY(OVERLAY(md5((((random())::text || ':'::text) || (clock_timestamp())::text)) PLACING '4'::text FROM 13) PLACING to_hex((floor(((random() * (((11 - 8) + 1))::double precision) + (8)::double precision)))::integer) FROM 17))::cstring) NOT NULL,
    email character varying(255),
    "firstName" character varying(32),
    "lastName" character varying(32),
    password character varying(255),
    "personalizationAnswers" json,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    disabled boolean DEFAULT false NOT NULL,
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "mfaSecret" text,
    "mfaRecoveryCodes" text,
    role text NOT NULL
);


ALTER TABLE public."user" OWNER TO developer;

--
-- Name: user_api_keys; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.user_api_keys (
    id character varying(36) NOT NULL,
    "userId" uuid NOT NULL,
    label character varying(100) NOT NULL,
    "apiKey" character varying NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    scopes json
);


ALTER TABLE public.user_api_keys OWNER TO developer;

--
-- Name: variables; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.variables (
    key character varying(50) NOT NULL,
    type character varying(50) DEFAULT 'string'::character varying NOT NULL,
    value character varying(255),
    id character varying(36) NOT NULL
);


ALTER TABLE public.variables OWNER TO developer;

--
-- Name: webhook_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.webhook_entity (
    "webhookPath" character varying NOT NULL,
    method character varying NOT NULL,
    node character varying NOT NULL,
    "webhookId" character varying,
    "pathLength" integer,
    "workflowId" character varying(36) NOT NULL
);


ALTER TABLE public.webhook_entity OWNER TO developer;

--
-- Name: workflow_entity; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.workflow_entity (
    name character varying(128) NOT NULL,
    active boolean NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    settings json,
    "staticData" json,
    "pinData" json,
    "versionId" character(36),
    "triggerCount" integer DEFAULT 0 NOT NULL,
    id character varying(36) NOT NULL,
    meta json,
    "parentFolderId" character varying(36) DEFAULT NULL::character varying,
    "isArchived" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.workflow_entity OWNER TO developer;

--
-- Name: workflow_history; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.workflow_history (
    "versionId" character varying(36) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    authors character varying(255) NOT NULL,
    "createdAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    "updatedAt" timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP(3) NOT NULL,
    nodes json NOT NULL,
    connections json NOT NULL
);


ALTER TABLE public.workflow_history OWNER TO developer;

--
-- Name: workflow_statistics; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.workflow_statistics (
    count integer DEFAULT 0,
    "latestEvent" timestamp(3) with time zone,
    name character varying(128) NOT NULL,
    "workflowId" character varying(36) NOT NULL,
    "rootCount" integer DEFAULT 0
);


ALTER TABLE public.workflow_statistics OWNER TO developer;

--
-- Name: workflows_tags; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.workflows_tags (
    "workflowId" character varying(36) NOT NULL,
    "tagId" character varying(36) NOT NULL
);


ALTER TABLE public.workflows_tags OWNER TO developer;

--
-- Name: auth_provider_sync_history id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.auth_provider_sync_history ALTER COLUMN id SET DEFAULT nextval('public.auth_provider_sync_history_id_seq'::regclass);


--
-- Name: execution_annotations id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotations ALTER COLUMN id SET DEFAULT nextval('public.execution_annotations_id_seq'::regclass);


--
-- Name: execution_entity id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_entity ALTER COLUMN id SET DEFAULT nextval('public.execution_entity_id_seq'::regclass);


--
-- Name: execution_metadata id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_metadata ALTER COLUMN id SET DEFAULT nextval('public.execution_metadata_temp_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: annotation_tag_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.annotation_tag_entity (id, name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: auth_identity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.auth_identity ("userId", "providerId", "providerType", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: auth_provider_sync_history; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.auth_provider_sync_history (id, "providerType", "runMode", status, "startedAt", "endedAt", scanned, created, updated, disabled, error) FROM stdin;
\.


--
-- Data for Name: credentials_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.credentials_entity (name, data, type, "createdAt", "updatedAt", id, "isManaged") FROM stdin;
\.


--
-- Data for Name: event_destinations; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.event_destinations (id, destination, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: execution_annotation_tags; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.execution_annotation_tags ("annotationId", "tagId") FROM stdin;
\.


--
-- Data for Name: execution_annotations; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.execution_annotations (id, "executionId", vote, note, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: execution_data; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.execution_data ("executionId", "workflowData", data) FROM stdin;
\.


--
-- Data for Name: execution_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.execution_entity (id, finished, mode, "retryOf", "retrySuccessId", "startedAt", "stoppedAt", "waitTill", status, "workflowId", "deletedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: execution_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.execution_metadata (id, "executionId", key, value) FROM stdin;
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.folder (id, name, "parentFolderId", "projectId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: folder_tag; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.folder_tag ("folderId", "tagId") FROM stdin;
\.


--
-- Data for Name: insights_by_period; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.insights_by_period (id, "metaId", type, value, "periodUnit", "periodStart") FROM stdin;
\.


--
-- Data for Name: insights_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.insights_metadata ("metaId", "workflowId", "projectId", "workflowName", "projectName") FROM stdin;
\.


--
-- Data for Name: insights_raw; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.insights_raw (id, "metaId", type, value, "timestamp") FROM stdin;
\.


--
-- Data for Name: installed_nodes; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.installed_nodes (name, type, "latestVersion", package) FROM stdin;
\.


--
-- Data for Name: installed_packages; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.installed_packages ("packageName", "installedVersion", "authorName", "authorEmail", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invalid_auth_token; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.invalid_auth_token (token, "expiresAt") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
1	1587669153312	InitialMigration1587669153312
2	1589476000887	WebhookModel1589476000887
3	1594828256133	CreateIndexStoppedAt1594828256133
4	1607431743768	MakeStoppedAtNullable1607431743768
5	1611144599516	AddWebhookId1611144599516
6	1617270242566	CreateTagEntity1617270242566
7	1620824779533	UniqueWorkflowNames1620824779533
8	1626176912946	AddwaitTill1626176912946
9	1630419189837	UpdateWorkflowCredentials1630419189837
10	1644422880309	AddExecutionEntityIndexes1644422880309
11	1646834195327	IncreaseTypeVarcharLimit1646834195327
12	1646992772331	CreateUserManagement1646992772331
13	1648740597343	LowerCaseUserEmail1648740597343
14	1652254514002	CommunityNodes1652254514002
15	1652367743993	AddUserSettings1652367743993
16	1652905585850	AddAPIKeyColumn1652905585850
17	1654090467022	IntroducePinData1654090467022
18	1658932090381	AddNodeIds1658932090381
19	1659902242948	AddJsonKeyPinData1659902242948
20	1660062385367	CreateCredentialsUserRole1660062385367
21	1663755770893	CreateWorkflowsEditorRole1663755770893
22	1664196174001	WorkflowStatistics1664196174001
23	1665484192212	CreateCredentialUsageTable1665484192212
24	1665754637025	RemoveCredentialUsageTable1665754637025
25	1669739707126	AddWorkflowVersionIdColumn1669739707126
26	1669823906995	AddTriggerCountColumn1669823906995
27	1671535397530	MessageEventBusDestinations1671535397530
28	1671726148421	RemoveWorkflowDataLoadedFlag1671726148421
29	1673268682475	DeleteExecutionsWithWorkflows1673268682475
30	1674138566000	AddStatusToExecutions1674138566000
31	1674509946020	CreateLdapEntities1674509946020
32	1675940580449	PurgeInvalidWorkflowConnections1675940580449
33	1676996103000	MigrateExecutionStatus1676996103000
34	1677236854063	UpdateRunningExecutionStatus1677236854063
35	1677501636754	CreateVariables1677501636754
36	1679416281778	CreateExecutionMetadataTable1679416281778
37	1681134145996	AddUserActivatedProperty1681134145996
38	1681134145997	RemoveSkipOwnerSetup1681134145997
39	1690000000000	MigrateIntegerKeysToString1690000000000
40	1690000000020	SeparateExecutionData1690000000020
41	1690000000030	RemoveResetPasswordColumns1690000000030
42	1690000000030	AddMfaColumns1690000000030
43	1690787606731	AddMissingPrimaryKeyOnExecutionData1690787606731
44	1691088862123	CreateWorkflowNameIndex1691088862123
45	1692967111175	CreateWorkflowHistoryTable1692967111175
46	1693491613982	ExecutionSoftDelete1693491613982
47	1693554410387	DisallowOrphanExecutions1693554410387
48	1694091729095	MigrateToTimestampTz1694091729095
49	1695128658538	AddWorkflowMetadata1695128658538
50	1695829275184	ModifyWorkflowHistoryNodesAndConnections1695829275184
51	1700571993961	AddGlobalAdminRole1700571993961
52	1705429061930	DropRoleMapping1705429061930
53	1711018413374	RemoveFailedExecutionStatus1711018413374
54	1711390882123	MoveSshKeysToDatabase1711390882123
55	1712044305787	RemoveNodesAccess1712044305787
56	1714133768519	CreateProject1714133768519
57	1714133768521	MakeExecutionStatusNonNullable1714133768521
58	1717498465931	AddActivatedAtUserSetting1717498465931
59	1720101653148	AddConstraintToExecutionMetadata1720101653148
60	1721377157740	FixExecutionMetadataSequence1721377157740
61	1723627610222	CreateInvalidAuthTokenTable1723627610222
62	1723796243146	RefactorExecutionIndices1723796243146
63	1724753530828	CreateAnnotationTables1724753530828
64	1724951148974	AddApiKeysTable1724951148974
65	1726606152711	CreateProcessedDataTable1726606152711
66	1727427440136	SeparateExecutionCreationFromStart1727427440136
67	1728659839644	AddMissingPrimaryKeyOnAnnotationTagMapping1728659839644
68	1729607673464	UpdateProcessedDataValueColumnToText1729607673464
69	1729607673469	AddProjectIcons1729607673469
70	1730386903556	CreateTestDefinitionTable1730386903556
71	1731404028106	AddDescriptionToTestDefinition1731404028106
72	1731582748663	MigrateTestDefinitionKeyToString1731582748663
73	1732271325258	CreateTestMetricTable1732271325258
74	1732549866705	CreateTestRun1732549866705
75	1733133775640	AddMockedNodesColumnToTestDefinition1733133775640
76	1734479635324	AddManagedColumnToCredentialsTable1734479635324
77	1736172058779	AddStatsColumnsToTestRun1736172058779
78	1736947513045	CreateTestCaseExecutionTable1736947513045
79	1737715421462	AddErrorColumnsToTestRuns1737715421462
80	1738709609940	CreateFolderTable1738709609940
81	1739549398681	CreateAnalyticsTables1739549398681
82	1740445074052	UpdateParentFolderIdColumn1740445074052
83	1741167584277	RenameAnalyticsToInsights1741167584277
84	1742918400000	AddScopesColumnToApiKeys1742918400000
85	1745322634000	ClearEvaluation1745322634000
86	1745587087521	AddWorkflowStatisticsRootCount1745587087521
87	1745934666076	AddWorkflowArchivedColumn1745934666076
88	1745934666077	DropRoleTable1745934666077
89	1747824239000	AddProjectDescriptionColumn1747824239000
\.


--
-- Data for Name: processed_data; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.processed_data ("workflowId", context, "createdAt", "updatedAt", value) FROM stdin;
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project (id, name, type, "createdAt", "updatedAt", icon, description) FROM stdin;
XD4y1Txvf8MBeyvs	itellico gmbh <m@itellico.at>	personal	2025-07-09 06:46:10.312+00	2025-07-09 14:56:55.874+00	\N	\N
\.


--
-- Data for Name: project_relation; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.project_relation ("projectId", "userId", role, "createdAt", "updatedAt") FROM stdin;
XD4y1Txvf8MBeyvs	9a95718c-b8e2-47d7-877f-0c124a281de4	project:personalOwner	2025-07-09 06:46:10.312+00	2025-07-09 06:46:10.312+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.settings (key, value, "loadOnStartup") FROM stdin;
ui.banners.dismissed	["V1"]	t
features.ldap	{"loginEnabled":false,"loginLabel":"","connectionUrl":"","allowUnauthorizedCerts":false,"connectionSecurity":"none","connectionPort":389,"baseDn":"","bindingAdminDn":"","bindingAdminPassword":"","firstNameAttribute":"","lastNameAttribute":"","emailAttribute":"","loginIdAttribute":"","ldapIdAttribute":"","userFilter":"","synchronizationEnabled":false,"synchronizationInterval":60,"searchPageSize":0,"searchTimeout":60}	t
userManagement.isInstanceOwnerSetUp	true	t
\.


--
-- Data for Name: shared_credentials; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.shared_credentials ("credentialsId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: shared_workflow; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.shared_workflow ("workflowId", "projectId", role, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tag_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.tag_entity (name, "createdAt", "updatedAt", id) FROM stdin;
\.


--
-- Data for Name: test_case_execution; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.test_case_execution (id, "testRunId", "executionId", status, "runAt", "completedAt", "errorCode", "errorDetails", metrics, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: test_run; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.test_run (id, "workflowId", status, "errorCode", "errorDetails", "runAt", "completedAt", metrics, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public."user" (id, email, "firstName", "lastName", password, "personalizationAnswers", "createdAt", "updatedAt", settings, disabled, "mfaEnabled", "mfaSecret", "mfaRecoveryCodes", role) FROM stdin;
9a95718c-b8e2-47d7-877f-0c124a281de4	m@itellico.at	itellico	gmbh	$2a$10$uESYLYGqIVK.b1H.hpXFOOi86o6ziMdZehXaHq/ZUYNLK6BogFVCO	{"version":"v4","personalization_survey_submitted_at":"2025-07-09T14:56:58.347Z","personalization_survey_n8n_version":"1.100.1"}	2025-07-09 06:46:09.897+00	2025-07-09 14:56:58.368+00	{"userActivated": false}	f	f	\N	\N	global:owner
\.


--
-- Data for Name: user_api_keys; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.user_api_keys (id, "userId", label, "apiKey", "createdAt", "updatedAt", scopes) FROM stdin;
\.


--
-- Data for Name: variables; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.variables (key, type, value, id) FROM stdin;
\.


--
-- Data for Name: webhook_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.webhook_entity ("webhookPath", method, node, "webhookId", "pathLength", "workflowId") FROM stdin;
\.


--
-- Data for Name: workflow_entity; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.workflow_entity (name, active, nodes, connections, "createdAt", "updatedAt", settings, "staticData", "pinData", "versionId", "triggerCount", id, meta, "parentFolderId", "isArchived") FROM stdin;
\.


--
-- Data for Name: workflow_history; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.workflow_history ("versionId", "workflowId", authors, "createdAt", "updatedAt", nodes, connections) FROM stdin;
\.


--
-- Data for Name: workflow_statistics; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.workflow_statistics (count, "latestEvent", name, "workflowId", "rootCount") FROM stdin;
\.


--
-- Data for Name: workflows_tags; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.workflows_tags ("workflowId", "tagId") FROM stdin;
\.


--
-- Name: auth_provider_sync_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.auth_provider_sync_history_id_seq', 1, false);


--
-- Name: execution_annotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.execution_annotations_id_seq', 1, false);


--
-- Name: execution_entity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.execution_entity_id_seq', 1, false);


--
-- Name: execution_metadata_temp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.execution_metadata_temp_id_seq', 1, false);


--
-- Name: insights_by_period_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.insights_by_period_id_seq', 1, false);


--
-- Name: insights_metadata_metaId_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public."insights_metadata_metaId_seq"', 1, false);


--
-- Name: insights_raw_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.insights_raw_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.migrations_id_seq', 89, true);


--
-- Name: test_run PK_011c050f566e9db509a0fadb9b9; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.test_run
    ADD CONSTRAINT "PK_011c050f566e9db509a0fadb9b9" PRIMARY KEY (id);


--
-- Name: installed_packages PK_08cc9197c39b028c1e9beca225940576fd1a5804; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.installed_packages
    ADD CONSTRAINT "PK_08cc9197c39b028c1e9beca225940576fd1a5804" PRIMARY KEY ("packageName");


--
-- Name: execution_metadata PK_17a0b6284f8d626aae88e1c16e4; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_metadata
    ADD CONSTRAINT "PK_17a0b6284f8d626aae88e1c16e4" PRIMARY KEY (id);


--
-- Name: project_relation PK_1caaa312a5d7184a003be0f0cb6; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_relation
    ADD CONSTRAINT "PK_1caaa312a5d7184a003be0f0cb6" PRIMARY KEY ("projectId", "userId");


--
-- Name: folder_tag PK_27e4e00852f6b06a925a4d83a3e; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder_tag
    ADD CONSTRAINT "PK_27e4e00852f6b06a925a4d83a3e" PRIMARY KEY ("folderId", "tagId");


--
-- Name: project PK_4d68b1358bb5b766d3e78f32f57; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT "PK_4d68b1358bb5b766d3e78f32f57" PRIMARY KEY (id);


--
-- Name: invalid_auth_token PK_5779069b7235b256d91f7af1a15; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.invalid_auth_token
    ADD CONSTRAINT "PK_5779069b7235b256d91f7af1a15" PRIMARY KEY (token);


--
-- Name: shared_workflow PK_5ba87620386b847201c9531c58f; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_workflow
    ADD CONSTRAINT "PK_5ba87620386b847201c9531c58f" PRIMARY KEY ("workflowId", "projectId");


--
-- Name: folder PK_6278a41a706740c94c02e288df8; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT "PK_6278a41a706740c94c02e288df8" PRIMARY KEY (id);


--
-- Name: annotation_tag_entity PK_69dfa041592c30bbc0d4b84aa00; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.annotation_tag_entity
    ADD CONSTRAINT "PK_69dfa041592c30bbc0d4b84aa00" PRIMARY KEY (id);


--
-- Name: execution_annotations PK_7afcf93ffa20c4252869a7c6a23; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotations
    ADD CONSTRAINT "PK_7afcf93ffa20c4252869a7c6a23" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: installed_nodes PK_8ebd28194e4f792f96b5933423fc439df97d9689; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.installed_nodes
    ADD CONSTRAINT "PK_8ebd28194e4f792f96b5933423fc439df97d9689" PRIMARY KEY (name);


--
-- Name: shared_credentials PK_8ef3a59796a228913f251779cff; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_credentials
    ADD CONSTRAINT "PK_8ef3a59796a228913f251779cff" PRIMARY KEY ("credentialsId", "projectId");


--
-- Name: test_case_execution PK_90c121f77a78a6580e94b794bce; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.test_case_execution
    ADD CONSTRAINT "PK_90c121f77a78a6580e94b794bce" PRIMARY KEY (id);


--
-- Name: user_api_keys PK_978fa5caa3468f463dac9d92e69; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_api_keys
    ADD CONSTRAINT "PK_978fa5caa3468f463dac9d92e69" PRIMARY KEY (id);


--
-- Name: execution_annotation_tags PK_979ec03d31294cca484be65d11f; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotation_tags
    ADD CONSTRAINT "PK_979ec03d31294cca484be65d11f" PRIMARY KEY ("annotationId", "tagId");


--
-- Name: webhook_entity PK_b21ace2e13596ccd87dc9bf4ea6; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.webhook_entity
    ADD CONSTRAINT "PK_b21ace2e13596ccd87dc9bf4ea6" PRIMARY KEY ("webhookPath", method);


--
-- Name: insights_by_period PK_b606942249b90cc39b0265f0575; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_by_period
    ADD CONSTRAINT "PK_b606942249b90cc39b0265f0575" PRIMARY KEY (id);


--
-- Name: workflow_history PK_b6572dd6173e4cd06fe79937b58; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_history
    ADD CONSTRAINT "PK_b6572dd6173e4cd06fe79937b58" PRIMARY KEY ("versionId");


--
-- Name: processed_data PK_ca04b9d8dc72de268fe07a65773; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.processed_data
    ADD CONSTRAINT "PK_ca04b9d8dc72de268fe07a65773" PRIMARY KEY ("workflowId", context);


--
-- Name: settings PK_dc0fe14e6d9943f268e7b119f69ab8bd; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT "PK_dc0fe14e6d9943f268e7b119f69ab8bd" PRIMARY KEY (key);


--
-- Name: user PK_ea8f538c94b6e352418254ed6474a81f; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_ea8f538c94b6e352418254ed6474a81f" PRIMARY KEY (id);


--
-- Name: insights_raw PK_ec15125755151e3a7e00e00014f; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_raw
    ADD CONSTRAINT "PK_ec15125755151e3a7e00e00014f" PRIMARY KEY (id);


--
-- Name: insights_metadata PK_f448a94c35218b6208ce20cf5a1; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_metadata
    ADD CONSTRAINT "PK_f448a94c35218b6208ce20cf5a1" PRIMARY KEY ("metaId");


--
-- Name: user UQ_e12875dfb3b1d92d7d7c5377e2; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e2" UNIQUE (email);


--
-- Name: auth_identity auth_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.auth_identity
    ADD CONSTRAINT auth_identity_pkey PRIMARY KEY ("providerId", "providerType");


--
-- Name: auth_provider_sync_history auth_provider_sync_history_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.auth_provider_sync_history
    ADD CONSTRAINT auth_provider_sync_history_pkey PRIMARY KEY (id);


--
-- Name: credentials_entity credentials_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.credentials_entity
    ADD CONSTRAINT credentials_entity_pkey PRIMARY KEY (id);


--
-- Name: event_destinations event_destinations_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.event_destinations
    ADD CONSTRAINT event_destinations_pkey PRIMARY KEY (id);


--
-- Name: execution_data execution_data_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_data
    ADD CONSTRAINT execution_data_pkey PRIMARY KEY ("executionId");


--
-- Name: execution_entity pk_e3e63bbf986767844bbe1166d4e; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_entity
    ADD CONSTRAINT pk_e3e63bbf986767844bbe1166d4e PRIMARY KEY (id);


--
-- Name: workflow_statistics pk_workflow_statistics; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_statistics
    ADD CONSTRAINT pk_workflow_statistics PRIMARY KEY ("workflowId", name);


--
-- Name: workflows_tags pk_workflows_tags; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflows_tags
    ADD CONSTRAINT pk_workflows_tags PRIMARY KEY ("workflowId", "tagId");


--
-- Name: tag_entity tag_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tag_entity
    ADD CONSTRAINT tag_entity_pkey PRIMARY KEY (id);


--
-- Name: variables variables_key_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.variables
    ADD CONSTRAINT variables_key_key UNIQUE (key);


--
-- Name: variables variables_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.variables
    ADD CONSTRAINT variables_pkey PRIMARY KEY (id);


--
-- Name: workflow_entity workflow_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_entity
    ADD CONSTRAINT workflow_entity_pkey PRIMARY KEY (id);


--
-- Name: IDX_14f68deffaf858465715995508; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_14f68deffaf858465715995508" ON public.folder USING btree ("projectId", id);


--
-- Name: IDX_1d8ab99d5861c9388d2dc1cf73; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_1d8ab99d5861c9388d2dc1cf73" ON public.insights_metadata USING btree ("workflowId");


--
-- Name: IDX_1e31657f5fe46816c34be7c1b4; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_1e31657f5fe46816c34be7c1b4" ON public.workflow_history USING btree ("workflowId");


--
-- Name: IDX_1ef35bac35d20bdae979d917a3; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_1ef35bac35d20bdae979d917a3" ON public.user_api_keys USING btree ("apiKey");


--
-- Name: IDX_5f0643f6717905a05164090dde; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_5f0643f6717905a05164090dde" ON public.project_relation USING btree ("userId");


--
-- Name: IDX_60b6a84299eeb3f671dfec7693; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_60b6a84299eeb3f671dfec7693" ON public.insights_by_period USING btree ("periodStart", type, "periodUnit", "metaId");


--
-- Name: IDX_61448d56d61802b5dfde5cdb00; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_61448d56d61802b5dfde5cdb00" ON public.project_relation USING btree ("projectId");


--
-- Name: IDX_63d7bbae72c767cf162d459fcc; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_63d7bbae72c767cf162d459fcc" ON public.user_api_keys USING btree ("userId", label);


--
-- Name: IDX_8e4b4774db42f1e6dda3452b2a; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_8e4b4774db42f1e6dda3452b2a" ON public.test_case_execution USING btree ("testRunId");


--
-- Name: IDX_97f863fa83c4786f1956508496; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_97f863fa83c4786f1956508496" ON public.execution_annotations USING btree ("executionId");


--
-- Name: IDX_a3697779b366e131b2bbdae297; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_a3697779b366e131b2bbdae297" ON public.execution_annotation_tags USING btree ("tagId");


--
-- Name: IDX_ae51b54c4bb430cf92f48b623f; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_ae51b54c4bb430cf92f48b623f" ON public.annotation_tag_entity USING btree (name);


--
-- Name: IDX_c1519757391996eb06064f0e7c; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_c1519757391996eb06064f0e7c" ON public.execution_annotation_tags USING btree ("annotationId");


--
-- Name: IDX_cec8eea3bf49551482ccb4933e; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX "IDX_cec8eea3bf49551482ccb4933e" ON public.execution_metadata USING btree ("executionId", key);


--
-- Name: IDX_d6870d3b6e4c185d33926f423c; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_d6870d3b6e4c185d33926f423c" ON public.test_run USING btree ("workflowId");


--
-- Name: IDX_execution_entity_deletedAt; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_execution_entity_deletedAt" ON public.execution_entity USING btree ("deletedAt");


--
-- Name: IDX_workflow_entity_name; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX "IDX_workflow_entity_name" ON public.workflow_entity USING btree (name);


--
-- Name: idx_07fde106c0b471d8cc80a64fc8; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_07fde106c0b471d8cc80a64fc8 ON public.credentials_entity USING btree (type);


--
-- Name: idx_16f4436789e804e3e1c9eeb240; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_16f4436789e804e3e1c9eeb240 ON public.webhook_entity USING btree ("webhookId", method, "pathLength");


--
-- Name: idx_812eb05f7451ca757fb98444ce; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX idx_812eb05f7451ca757fb98444ce ON public.tag_entity USING btree (name);


--
-- Name: idx_execution_entity_stopped_at_status_deleted_at; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_execution_entity_stopped_at_status_deleted_at ON public.execution_entity USING btree ("stoppedAt", status, "deletedAt") WHERE (("stoppedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- Name: idx_execution_entity_wait_till_status_deleted_at; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_execution_entity_wait_till_status_deleted_at ON public.execution_entity USING btree ("waitTill", status, "deletedAt") WHERE (("waitTill" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- Name: idx_execution_entity_workflow_id_started_at; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_execution_entity_workflow_id_started_at ON public.execution_entity USING btree ("workflowId", "startedAt") WHERE (("startedAt" IS NOT NULL) AND ("deletedAt" IS NULL));


--
-- Name: idx_workflows_tags_workflow_id; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX idx_workflows_tags_workflow_id ON public.workflows_tags USING btree ("workflowId");


--
-- Name: pk_credentials_entity_id; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX pk_credentials_entity_id ON public.credentials_entity USING btree (id);


--
-- Name: pk_tag_entity_id; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX pk_tag_entity_id ON public.tag_entity USING btree (id);


--
-- Name: pk_variables_id; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX pk_variables_id ON public.variables USING btree (id);


--
-- Name: pk_workflow_entity_id; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX pk_workflow_entity_id ON public.workflow_entity USING btree (id);


--
-- Name: processed_data FK_06a69a7032c97a763c2c7599464; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.processed_data
    ADD CONSTRAINT "FK_06a69a7032c97a763c2c7599464" FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: insights_metadata FK_1d8ab99d5861c9388d2dc1cf733; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_metadata
    ADD CONSTRAINT "FK_1d8ab99d5861c9388d2dc1cf733" FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE SET NULL;


--
-- Name: workflow_history FK_1e31657f5fe46816c34be7c1b4b; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_history
    ADD CONSTRAINT "FK_1e31657f5fe46816c34be7c1b4b" FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: insights_metadata FK_2375a1eda085adb16b24615b69c; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_metadata
    ADD CONSTRAINT "FK_2375a1eda085adb16b24615b69c" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE SET NULL;


--
-- Name: execution_metadata FK_31d0b4c93fb85ced26f6005cda3; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_metadata
    ADD CONSTRAINT "FK_31d0b4c93fb85ced26f6005cda3" FOREIGN KEY ("executionId") REFERENCES public.execution_entity(id) ON DELETE CASCADE;


--
-- Name: shared_credentials FK_416f66fc846c7c442970c094ccf; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_credentials
    ADD CONSTRAINT "FK_416f66fc846c7c442970c094ccf" FOREIGN KEY ("credentialsId") REFERENCES public.credentials_entity(id) ON DELETE CASCADE;


--
-- Name: project_relation FK_5f0643f6717905a05164090dde7; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_relation
    ADD CONSTRAINT "FK_5f0643f6717905a05164090dde7" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: project_relation FK_61448d56d61802b5dfde5cdb002; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.project_relation
    ADD CONSTRAINT "FK_61448d56d61802b5dfde5cdb002" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: insights_by_period FK_6414cfed98daabbfdd61a1cfbc0; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_by_period
    ADD CONSTRAINT "FK_6414cfed98daabbfdd61a1cfbc0" FOREIGN KEY ("metaId") REFERENCES public.insights_metadata("metaId") ON DELETE CASCADE;


--
-- Name: insights_raw FK_6e2e33741adef2a7c5d66befa4e; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.insights_raw
    ADD CONSTRAINT "FK_6e2e33741adef2a7c5d66befa4e" FOREIGN KEY ("metaId") REFERENCES public.insights_metadata("metaId") ON DELETE CASCADE;


--
-- Name: installed_nodes FK_73f857fc5dce682cef8a99c11dbddbc969618951; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.installed_nodes
    ADD CONSTRAINT "FK_73f857fc5dce682cef8a99c11dbddbc969618951" FOREIGN KEY (package) REFERENCES public.installed_packages("packageName") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: folder FK_804ea52f6729e3940498bd54d78; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT "FK_804ea52f6729e3940498bd54d78" FOREIGN KEY ("parentFolderId") REFERENCES public.folder(id) ON DELETE CASCADE;


--
-- Name: shared_credentials FK_812c2852270da1247756e77f5a4; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_credentials
    ADD CONSTRAINT "FK_812c2852270da1247756e77f5a4" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: test_case_execution FK_8e4b4774db42f1e6dda3452b2af; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.test_case_execution
    ADD CONSTRAINT "FK_8e4b4774db42f1e6dda3452b2af" FOREIGN KEY ("testRunId") REFERENCES public.test_run(id) ON DELETE CASCADE;


--
-- Name: folder_tag FK_94a60854e06f2897b2e0d39edba; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder_tag
    ADD CONSTRAINT "FK_94a60854e06f2897b2e0d39edba" FOREIGN KEY ("folderId") REFERENCES public.folder(id) ON DELETE CASCADE;


--
-- Name: execution_annotations FK_97f863fa83c4786f19565084960; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotations
    ADD CONSTRAINT "FK_97f863fa83c4786f19565084960" FOREIGN KEY ("executionId") REFERENCES public.execution_entity(id) ON DELETE CASCADE;


--
-- Name: execution_annotation_tags FK_a3697779b366e131b2bbdae2976; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotation_tags
    ADD CONSTRAINT "FK_a3697779b366e131b2bbdae2976" FOREIGN KEY ("tagId") REFERENCES public.annotation_tag_entity(id) ON DELETE CASCADE;


--
-- Name: shared_workflow FK_a45ea5f27bcfdc21af9b4188560; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_workflow
    ADD CONSTRAINT "FK_a45ea5f27bcfdc21af9b4188560" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: folder FK_a8260b0b36939c6247f385b8221; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT "FK_a8260b0b36939c6247f385b8221" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: execution_annotation_tags FK_c1519757391996eb06064f0e7c8; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_annotation_tags
    ADD CONSTRAINT "FK_c1519757391996eb06064f0e7c8" FOREIGN KEY ("annotationId") REFERENCES public.execution_annotations(id) ON DELETE CASCADE;


--
-- Name: test_run FK_d6870d3b6e4c185d33926f423c8; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.test_run
    ADD CONSTRAINT "FK_d6870d3b6e4c185d33926f423c8" FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: shared_workflow FK_daa206a04983d47d0a9c34649ce; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shared_workflow
    ADD CONSTRAINT "FK_daa206a04983d47d0a9c34649ce" FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: folder_tag FK_dc88164176283de80af47621746; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.folder_tag
    ADD CONSTRAINT "FK_dc88164176283de80af47621746" FOREIGN KEY ("tagId") REFERENCES public.tag_entity(id) ON DELETE CASCADE;


--
-- Name: user_api_keys FK_e131705cbbc8fb589889b02d457; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.user_api_keys
    ADD CONSTRAINT "FK_e131705cbbc8fb589889b02d457" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: test_case_execution FK_e48965fac35d0f5b9e7f51d8c44; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.test_case_execution
    ADD CONSTRAINT "FK_e48965fac35d0f5b9e7f51d8c44" FOREIGN KEY ("executionId") REFERENCES public.execution_entity(id) ON DELETE SET NULL;


--
-- Name: auth_identity auth_identity_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.auth_identity
    ADD CONSTRAINT "auth_identity_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."user"(id);


--
-- Name: execution_data execution_data_fk; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_data
    ADD CONSTRAINT execution_data_fk FOREIGN KEY ("executionId") REFERENCES public.execution_entity(id) ON DELETE CASCADE;


--
-- Name: execution_entity fk_execution_entity_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.execution_entity
    ADD CONSTRAINT fk_execution_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: webhook_entity fk_webhook_entity_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.webhook_entity
    ADD CONSTRAINT fk_webhook_entity_workflow_id FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: workflow_entity fk_workflow_parent_folder; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_entity
    ADD CONSTRAINT fk_workflow_parent_folder FOREIGN KEY ("parentFolderId") REFERENCES public.folder(id) ON DELETE CASCADE;


--
-- Name: workflow_statistics fk_workflow_statistics_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflow_statistics
    ADD CONSTRAINT fk_workflow_statistics_workflow_id FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- Name: workflows_tags fk_workflows_tags_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_tag_id FOREIGN KEY ("tagId") REFERENCES public.tag_entity(id) ON DELETE CASCADE;


--
-- Name: workflows_tags fk_workflows_tags_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.workflows_tags
    ADD CONSTRAINT fk_workflows_tags_workflow_id FOREIGN KEY ("workflowId") REFERENCES public.workflow_entity(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "temporal" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: temporal; Type: DATABASE; Schema: -; Owner: developer
--

CREATE DATABASE temporal WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE temporal OWNER TO developer;

\connect temporal

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_info_maps; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.activity_info_maps (
    shard_id integer NOT NULL,
    namespace_id bytea NOT NULL,
    workflow_id character varying(255) NOT NULL,
    run_id bytea NOT NULL,
    schedule_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16)
);


ALTER TABLE public.activity_info_maps OWNER TO developer;

--
-- Name: buffered_events; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.buffered_events (
    shard_id integer NOT NULL,
    namespace_id bytea NOT NULL,
    workflow_id character varying(255) NOT NULL,
    run_id bytea NOT NULL,
    id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.buffered_events OWNER TO developer;

--
-- Name: buffered_events_id_seq; Type: SEQUENCE; Schema: public; Owner: developer
--

CREATE SEQUENCE public.buffered_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.buffered_events_id_seq OWNER TO developer;

--
-- Name: buffered_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: developer
--

ALTER SEQUENCE public.buffered_events_id_seq OWNED BY public.buffered_events.id;


--
-- Name: build_id_to_task_queue; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.build_id_to_task_queue (
    namespace_id bytea NOT NULL,
    build_id character varying(255) NOT NULL,
    task_queue_name character varying(255) NOT NULL
);


ALTER TABLE public.build_id_to_task_queue OWNER TO developer;

--
-- Name: child_execution_info_maps; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.child_execution_info_maps (
    shard_id integer NOT NULL,
    namespace_id bytea NOT NULL,
    workflow_id character varying(255) NOT NULL,
    run_id bytea NOT NULL,
    initiated_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16)
);


ALTER TABLE public.child_execution_info_maps OWNER TO developer;

--
-- Name: cluster_membership; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.cluster_membership (
    membership_partition integer NOT NULL,
    host_id bytea NOT NULL,
    rpc_address character varying(128) NOT NULL,
    rpc_port smallint NOT NULL,
    role smallint NOT NULL,
    session_start timestamp without time zone DEFAULT '1970-01-01 00:00:01'::timestamp without time zone,
    last_heartbeat timestamp without time zone DEFAULT '1970-01-01 00:00:01'::timestamp without time zone,
    record_expiry timestamp without time zone DEFAULT '1970-01-01 00:00:01'::timestamp without time zone
);


ALTER TABLE public.cluster_membership OWNER TO developer;

--
-- Name: cluster_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.cluster_metadata (
    metadata_partition integer NOT NULL,
    data bytea DEFAULT '\x'::bytea NOT NULL,
    data_encoding character varying(16) DEFAULT 'Proto3'::character varying NOT NULL,
    version bigint DEFAULT 1 NOT NULL
);


ALTER TABLE public.cluster_metadata OWNER TO developer;

--
-- Name: cluster_metadata_info; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.cluster_metadata_info (
    metadata_partition integer NOT NULL,
    cluster_name character varying(255) NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL,
    version bigint NOT NULL
);


ALTER TABLE public.cluster_metadata_info OWNER TO developer;

--
-- Name: current_executions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.current_executions (
    shard_id integer NOT NULL,
    namespace_id bytea NOT NULL,
    workflow_id character varying(255) NOT NULL,
    run_id bytea NOT NULL,
    create_request_id character varying(255) NOT NULL,
    state integer NOT NULL,
    status integer NOT NULL,
    start_version bigint DEFAULT 0 NOT NULL,
    last_write_version bigint NOT NULL
);


ALTER TABLE public.current_executions OWNER TO developer;

--
-- Name: executions; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.executions (
    shard_id integer NOT NULL,
    namespace_id bytea NOT NULL,
    workflow_id character varying(255) NOT NULL,
    run_id bytea NOT NULL,
    next_event_id bigint NOT NULL,
    last_write_version bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL,
    state bytea NOT NULL,
    state_encoding character varying(16) NOT NULL,
    db_record_version bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.executions OWNER TO developer;

--
-- Name: history_immediate_tasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.history_immediate_tasks (
    shard_id integer NOT NULL,
    category_id integer NOT NULL,
    task_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.history_immediate_tasks OWNER TO developer;

--
-- Name: history_node; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.history_node (
    shard_id integer NOT NULL,
    tree_id bytea NOT NULL,
    branch_id bytea NOT NULL,
    node_id bigint NOT NULL,
    txn_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL,
    prev_txn_id bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.history_node OWNER TO developer;

--
-- Name: history_scheduled_tasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.history_scheduled_tasks (
    shard_id integer NOT NULL,
    category_id integer NOT NULL,
    visibility_timestamp timestamp without time zone NOT NULL,
    task_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.history_scheduled_tasks OWNER TO developer;

--
-- Name: history_tree; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.history_tree (
    shard_id integer NOT NULL,
    tree_id bytea NOT NULL,
    branch_id bytea NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.history_tree OWNER TO developer;

--
-- Name: namespace_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.namespace_metadata (
    partition_id integer NOT NULL,
    notification_version bigint NOT NULL
);


ALTER TABLE public.namespace_metadata OWNER TO developer;

--
-- Name: namespaces; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.namespaces (
    partition_id integer NOT NULL,
    id bytea NOT NULL,
    name character varying(255) NOT NULL,
    notification_version bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL,
    is_global boolean NOT NULL
);


ALTER TABLE public.namespaces OWNER TO developer;

--
-- Name: queue; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.queue (
    queue_type integer NOT NULL,
    message_id bigint NOT NULL,
    message_payload bytea NOT NULL,
    message_encoding character varying(16) DEFAULT 'Json'::character varying NOT NULL
);


ALTER TABLE public.queue OWNER TO developer;

--
-- Name: queue_metadata; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.queue_metadata (
    queue_type integer NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) DEFAULT 'Json'::character varying NOT NULL,
    version bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.queue_metadata OWNER TO developer;

--
-- Name: replication_tasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.replication_tasks (
    shard_id integer NOT NULL,
    task_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.replication_tasks OWNER TO developer;

--
-- Name: replication_tasks_dlq; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.replication_tasks_dlq (
    source_cluster_name character varying(255) NOT NULL,
    shard_id integer NOT NULL,
    task_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.replication_tasks_dlq OWNER TO developer;

--
-- Name: request_cancel_info_maps; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.request_cancel_info_maps (
    shard_id integer NOT NULL,
    namespace_id bytea NOT NULL,
    workflow_id character varying(255) NOT NULL,
    run_id bytea NOT NULL,
    initiated_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16)
);


ALTER TABLE public.request_cancel_info_maps OWNER TO developer;

--
-- Name: schema_update_history; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.schema_update_history (
    version_partition integer NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    update_time timestamp without time zone NOT NULL,
    description character varying(255),
    manifest_md5 character varying(64),
    new_version character varying(64),
    old_version character varying(64)
);


ALTER TABLE public.schema_update_history OWNER TO developer;

--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.schema_version (
    version_partition integer NOT NULL,
    db_name character varying(255) NOT NULL,
    creation_time timestamp without time zone,
    curr_version character varying(64),
    min_compatible_version character varying(64)
);


ALTER TABLE public.schema_version OWNER TO developer;

--
-- Name: shards; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.shards (
    shard_id integer NOT NULL,
    range_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.shards OWNER TO developer;

--
-- Name: signal_info_maps; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.signal_info_maps (
    shard_id integer NOT NULL,
    namespace_id bytea NOT NULL,
    workflow_id character varying(255) NOT NULL,
    run_id bytea NOT NULL,
    initiated_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16)
);


ALTER TABLE public.signal_info_maps OWNER TO developer;

--
-- Name: signals_requested_sets; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.signals_requested_sets (
    shard_id integer NOT NULL,
    namespace_id bytea NOT NULL,
    workflow_id character varying(255) NOT NULL,
    run_id bytea NOT NULL,
    signal_id character varying(255) NOT NULL
);


ALTER TABLE public.signals_requested_sets OWNER TO developer;

--
-- Name: task_queue_user_data; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_queue_user_data (
    namespace_id bytea NOT NULL,
    task_queue_name character varying(255) NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL,
    version bigint NOT NULL
);


ALTER TABLE public.task_queue_user_data OWNER TO developer;

--
-- Name: task_queues; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.task_queues (
    range_hash bigint NOT NULL,
    task_queue_id bytea NOT NULL,
    range_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.task_queues OWNER TO developer;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.tasks (
    range_hash bigint NOT NULL,
    task_queue_id bytea NOT NULL,
    task_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.tasks OWNER TO developer;

--
-- Name: timer_info_maps; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.timer_info_maps (
    shard_id integer NOT NULL,
    namespace_id bytea NOT NULL,
    workflow_id character varying(255) NOT NULL,
    run_id bytea NOT NULL,
    timer_id character varying(255) NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16)
);


ALTER TABLE public.timer_info_maps OWNER TO developer;

--
-- Name: timer_tasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.timer_tasks (
    shard_id integer NOT NULL,
    visibility_timestamp timestamp without time zone NOT NULL,
    task_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.timer_tasks OWNER TO developer;

--
-- Name: transfer_tasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.transfer_tasks (
    shard_id integer NOT NULL,
    task_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.transfer_tasks OWNER TO developer;

--
-- Name: visibility_tasks; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.visibility_tasks (
    shard_id integer NOT NULL,
    task_id bigint NOT NULL,
    data bytea NOT NULL,
    data_encoding character varying(16) NOT NULL
);


ALTER TABLE public.visibility_tasks OWNER TO developer;

--
-- Name: buffered_events id; Type: DEFAULT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.buffered_events ALTER COLUMN id SET DEFAULT nextval('public.buffered_events_id_seq'::regclass);


--
-- Data for Name: activity_info_maps; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.activity_info_maps (shard_id, namespace_id, workflow_id, run_id, schedule_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: buffered_events; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.buffered_events (shard_id, namespace_id, workflow_id, run_id, id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: build_id_to_task_queue; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.build_id_to_task_queue (namespace_id, build_id, task_queue_name) FROM stdin;
\.


--
-- Data for Name: child_execution_info_maps; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.child_execution_info_maps (shard_id, namespace_id, workflow_id, run_id, initiated_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: cluster_membership; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.cluster_membership (membership_partition, host_id, rpc_address, rpc_port, role, session_start, last_heartbeat, record_expiry) FROM stdin;
0	\\xf6a498ac5c8d11f0a244fe5b6d058c35	172.20.0.11	6933	1	2025-07-09 06:28:44.687633	2025-07-09 10:20:14.751953	2025-07-11 10:20:14.751953
0	\\x5de6d5275cae11f0ac1192059f990dff	172.20.0.11	6935	3	2025-07-09 10:20:41.858007	2025-07-09 10:21:05.870759	2025-07-11 10:21:05.870759
0	\\x5dedb88c5cae11f0ac1192059f990dff	172.20.0.11	6939	4	2025-07-09 10:20:41.857945	2025-07-09 10:21:07.873302	2025-07-11 10:21:07.873302
0	\\x5de4e56a5cae11f0ac1192059f990dff	172.20.0.11	6934	2	2025-07-09 10:20:41.859652	2025-07-09 10:21:09.876429	2025-07-11 10:21:09.876429
0	\\x5debc29d5cae11f0ac1192059f990dff	172.20.0.11	6933	1	2025-07-09 10:20:41.861802	2025-07-09 10:21:14.88691	2025-07-11 10:21:14.88691
0	\\x19110e435cbb11f09fc252072b59eb43	172.20.0.13	6935	3	2025-07-09 11:51:49.881096	2025-07-09 15:05:14.435888	2025-07-11 15:05:14.435888
0	\\x1915b91f5cbb11f09fc252072b59eb43	172.20.0.13	6933	1	2025-07-09 11:51:49.890943	2025-07-09 15:05:15.246796	2025-07-11 15:05:15.246796
0	\\x190cc8f65cbb11f09fc252072b59eb43	172.20.0.13	6934	2	2025-07-09 11:51:49.884232	2025-07-09 15:05:20.199837	2025-07-11 15:05:20.199837
0	\\x191bcc245cbb11f09fc252072b59eb43	172.20.0.13	6939	4	2025-07-09 11:51:49.881003	2025-07-09 15:05:20.322482	2025-07-11 15:05:20.322482
0	\\x33d0c6ec5cd611f0971096cc6bb7ca90	172.20.0.13	6934	2	2025-07-09 15:05:51.141932	2025-07-09 16:12:32.208642	2025-07-11 16:12:32.208642
0	\\xb4393fa05cae11f08f0396655bdfcc9b	172.20.0.12	6939	4	2025-07-09 10:23:06.638202	2025-07-09 11:01:52.047506	2025-07-11 11:01:52.047506
0	\\xb42f4f265cae11f08f0396655bdfcc9b	172.20.0.12	6934	2	2025-07-09 10:23:06.641506	2025-07-09 11:01:52.97254	2025-07-11 11:01:52.97254
0	\\xb4344d9a5cae11f08f0396655bdfcc9b	172.20.0.12	6935	3	2025-07-09 10:23:06.638685	2025-07-09 11:01:56.997563	2025-07-11 11:01:56.997563
0	\\xb436c9c15cae11f08f0396655bdfcc9b	172.20.0.12	6933	1	2025-07-09 10:23:06.643805	2025-07-09 11:01:58.940662	2025-07-11 11:01:58.940662
0	\\x33db03625cd611f0971096cc6bb7ca90	172.20.0.13	6939	4	2025-07-09 15:05:51.14252	2025-07-09 16:12:40.201397	2025-07-11 16:12:40.201397
0	\\x33d585525cd611f0971096cc6bb7ca90	172.20.0.13	6933	1	2025-07-09 15:05:51.145894	2025-07-09 16:12:41.234287	2025-07-11 16:12:41.234287
0	\\x33d3b0685cd611f0971096cc6bb7ca90	172.20.0.13	6935	3	2025-07-09 15:05:51.141153	2025-07-09 16:12:42.189132	2025-07-11 16:12:42.189132
0	\\x856c90ad5cae11f0a53d5ae64cd0cced	172.20.0.11	6935	3	2025-07-09 10:21:48.145823	2025-07-09 10:22:27.173086	2025-07-11 10:22:27.173086
0	\\x856e95b75cae11f0a53d5ae64cd0cced	172.20.0.11	6933	1	2025-07-09 10:21:48.151907	2025-07-09 10:22:35.1796	2025-07-11 10:22:35.1796
0	\\x856a457b5cae11f0a53d5ae64cd0cced	172.20.0.11	6934	2	2025-07-09 10:21:48.145876	2025-07-09 10:22:36.174142	2025-07-11 10:22:36.174142
0	\\x85705ec25cae11f0a53d5ae64cd0cced	172.20.0.11	6939	4	2025-07-09 10:21:48.146018	2025-07-09 10:22:39.184397	2025-07-11 10:22:39.184397
0	\\x2ef351fd5cb411f09fa2ca9bdb51d05c	172.20.0.12	6933	1	2025-07-09 11:02:20.039641	2025-07-09 11:08:22.208839	2025-07-11 11:08:22.208839
0	\\x2eec11f15cb411f09fa2ca9bdb51d05c	172.20.0.12	6934	2	2025-07-09 11:02:20.036621	2025-07-09 11:08:24.2592	2025-07-11 11:08:24.2592
0	\\x2ef54b055cb411f09fa2ca9bdb51d05c	172.20.0.12	6939	4	2025-07-09 11:02:20.033996	2025-07-09 11:08:24.265504	2025-07-11 11:08:24.265504
0	\\x2eee0fbe5cb411f09fa2ca9bdb51d05c	172.20.0.12	6935	3	2025-07-09 11:02:20.034006	2025-07-09 11:08:30.276167	2025-07-11 11:08:30.276167
0	\\xf6a670815c8d11f0a244fe5b6d058c35	172.20.0.11	6939	4	2025-07-09 06:28:44.687573	2025-07-09 10:20:03.740773	2025-07-11 10:20:03.740773
0	\\xf69fc22e5c8d11f0a244fe5b6d058c35	172.20.0.11	6934	2	2025-07-09 06:28:44.691303	2025-07-09 10:20:07.818362	2025-07-11 10:20:07.818362
0	\\xf6a2beae5c8d11f0a244fe5b6d058c35	172.20.0.11	6935	3	2025-07-09 06:28:44.687532	2025-07-09 10:20:09.739099	2025-07-11 10:20:09.739099
\.


--
-- Data for Name: cluster_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.cluster_metadata (metadata_partition, data, data_encoding, version) FROM stdin;
\.


--
-- Data for Name: cluster_metadata_info; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.cluster_metadata_info (metadata_partition, cluster_name, data, data_encoding, version) FROM stdin;
0	active	\\x0a0661637469766510041a2435653736346136352d616362662d346338612d613764652d39613230353164303638653822580a100a06312e32322e34120608e0ec86ad0612100a06312e32382e30120608bb92fcc20622240a20f09faa902041206e65772072656c6561736520697320617661696c61626c652110032a0c08cf8abac30610c981ff9f032aaa030a1374656d706f72616c5f7669736962696c6974791292030a0c0a08446f75626c65303310040a090a05496e74303310030a0d0a094b6579776f7264303710020a110a0d4b6579776f72644c697374303110070a0a0a06426f6f6c303110050a0c0a08446f75626c65303110040a0d0a094b6579776f7264303510020a0a0a06426f6f6c303210050a0d0a094b6579776f7264303210020a0d0a094b6579776f7264313010020a0d0a094b6579776f7264303110020a0a0a0654657874303210010a0e0a0a4461746574696d65303310060a090a05496e74303110030a110a0d4b6579776f72644c697374303210070a0d0a094b6579776f7264303610020a0c0a08446f75626c65303210040a0d0a094b6579776f7264303910020a0a0a0654657874303110010a0d0a094b6579776f7264303310020a0d0a094b6579776f7264303410020a0a0a06426f6f6c303310050a090a05496e74303210030a0a0a0654657874303310010a110a0d4b6579776f72644c697374303310070a0e0a0a4461746574696d65303110060a0e0a0a4461746574696d65303210060a0d0a094b6579776f7264303810022aa2010a00129d010a150a11437573746f6d537472696e674669656c6410010a130a0f437573746f6d546578744669656c6410010a130a0f437573746f6d426f6f6c4669656c6410050a170a13437573746f6d4461746574696d654669656c6410060a150a11437573746f6d446f75626c654669656c6410040a120a0e437573746f6d496e744669656c6410030a160a12437573746f6d4b6579776f72644669656c641002320e3132372e302e302e313a37323333380a400150015801	Proto3	6
\.


--
-- Data for Name: current_executions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.current_executions (shard_id, namespace_id, workflow_id, run_id, create_request_id, state, status, start_version, last_write_version) FROM stdin;
3	\\x32049b68787240948e63d0dd59896a83	temporal-sys-add-search-attributes-workflow	\\x544cea09062b4801a68d3e48f55071ef	7254195c-9564-4195-852f-454bbd26faa3	3	2	0	0
4	\\x32049b68787240948e63d0dd59896a83	temporal-sys-history-scanner	\\xb219f01ceae44cd5b621d733e931d038	670633bd-f4d9-4970-ae39-d682ad70ac29	1	1	0	0
4	\\x32049b68787240948e63d0dd59896a83	temporal-sys-tq-scanner	\\x4696755b37ca42bab8a888e7a54efddc	4d5267c3-7217-4f03-bbcf-5a11b6ab7a32	1	1	0	0
\.


--
-- Data for Name: executions; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.executions (shard_id, namespace_id, workflow_id, run_id, next_event_id, last_write_version, data, data_encoding, state, state_encoding, db_record_version) FROM stdin;
3	\\x32049b68787240948e63d0dd59896a83	temporal-sys-add-search-attributes-workflow	\\x544cea09062b4801a68d3e48f55071ef	24	0	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833122b74656d706f72616c2d7379732d6164642d7365617263682d617474726962757465732d776f726b666c6f7738164a1164656661756c742d776f726b65722d7471522b74656d706f72616c2d7379732d6164642d7365617263682d617474726962757465732d776f726b666c6f775a0062006a02080a8801bf8040900116980115a2010c089e98b8c306108febb2f602aa010c089e98b8c30610b0ddf18b03ca0100d00101da0100e20100f2010c089e98b8c30610d291b08903fa0109656d707479557569649802019a035c0a5a0a203639633339373932316565316439353634643634353463643839653133333565122435343463656130392d303632622d343830312d613638642d3365343866353530373165661804220c089e98b8c30610b79182fc023001a203790a084275696c64496473126d0a160a08656e636f64696e67120a6a736f6e2f706c61696e0a130a0474797065120b4b6579776f72644c697374123e5b22756e76657273696f6e6564222c22756e76657273696f6e65643a3639633339373932316565316439353634643634353463643839653133333565225db2035412520a4c0a2435343463656130392d303632622d343830312d613638642d336534386635353037316566122433613931376666392d396364662d346564302d386666392d34346361363130313538633512020817ba032435343463656130392d303632622d343830312d613638642d336534386635353037316566c2030308f316ca030b088092b8c398feffffff01d003c08040d8030fe2030c089e98b8c306108febb2f6028004c280408804c3804092040c089e98b8c30610f5d7f08b03b80403f204220a203639633339373932316565316439353634643634353463643839653133333565	Proto3	\\x0a2437323534313935632d393536342d343139352d383532662d343534626264323666616133122435343463656130392d303632622d343830312d613638642d33653438663535303731656618032002	Proto3	16
4	\\x32049b68787240948e63d0dd59896a83	temporal-sys-history-scanner	\\x5e71d67ed8c846ae8f9a3b3fb29bd27a	12	0	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121c74656d706f72616c2d7379732d686973746f72792d7363616e6e6572380a4a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d30522574656d706f72616c2d7379732d686973746f72792d7363616e6e65722d776f726b666c6f775a0062006a02080a8801b280800390010a980109a2010b089d98b8c30610daa19a33aa010c08c0b3b9c30610fda1b88601ca0100d00101da0100e20100f2010c08c0b3b9c30610ce87fd8001fa0109656d70747955756964980201da020c30202a2f3132202a202a202a9a03690a670a203639633339373932316565316439353634643634353463643839653133333565122435653731643637652d643863382d343661652d386639612d3362336662323962643237611804220b08c0b3b9c3061092c3f3602a0c08c0a8dec306109acbb586013001a203790a084275696c64496473126d0a130a0474797065120b4b6579776f72644c6973740a160a08656e636f64696e67120a6a736f6e2f706c61696e123e5b22756e76657273696f6e6564222c22756e76657273696f6e65643a3639633339373932316565316439353634643634353463643839653133333565225db2035412520a4c0a2435653731643637652d643863382d343661652d386639612d336233666232396264323761122465643534323733342d306435662d343261662d623263392d3665633163366361386630301202080bba032435653731643637652d643863382d343661652d386639612d336233666232396264323761c2030308c20aca030b088092b8c398feffffff01d003b3808003d80309e2030b08c0b3b9c30610daa19a33ea032462323139663031632d656165342d346364352d623632312d6437333365393331643033388004b78080038804b880800392040c08c0b3b9c30610e6fbe58501b80401f204220a203639633339373932316565316439353634643634353463643839653133333565	Proto3	\\x0a2431663762383433382d376634372d343664372d383962332d623563356339643365656535122435653731643637652d643863382d343661652d386639612d33623366623239626432376118032002	Proto3	10
4	\\x32049b68787240948e63d0dd59896a83	temporal-sys-tq-scanner	\\x795e30177b5d40b6be08fe88c1e91ecb	12	0	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121774656d706f72616c2d7379732d74712d7363616e6e6572380a4a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d30522074656d706f72616c2d7379732d74712d7363616e6e65722d776f726b666c6f775a0062040880af1a6a02080a8801c680800390010a980109a2010b089d98b8c30610f2e8d333aa010c0886b4b9c306108cb6de9201ca0100d00101da0100e20100f2010c0886b4b9c30610d3d3f88501fa0109656d70747955756964980201da020c30202a2f3132202a202a202a9a03690a670a203639633339373932316565316439353634643634353463643839653133333565122437393565333031372d376235642d343062362d626530382d6665383863316539316563621804220b08c0b3b9c30610eedcf3602a0c0886a9dec30610af80c792013001a203790a084275696c64496473126d0a130a0474797065120b4b6579776f72644c6973740a160a08656e636f64696e67120a6a736f6e2f706c61696e123e5b22756e76657273696f6e6564222c22756e76657273696f6e65643a3639633339373932316565316439353634643634353463643839653133333565225db2035412520a4c0a2437393565333031372d376235642d343062362d626530382d666538386331653931656362122466653635663534352d306339342d346432322d613030642d3539316631663630373338301202080bba032437393565333031372d376235642d343062362d626530382d666538386331653931656362c2030308af09ca030b08c0e2d3c30610f2e8d333d003c7808003d8030ae2030b08c0b3b9c30610f2e8d333ea032434363936373535622d333763612d343262612d623861382d3838653761353465666464638004cb8080038804cc80800392040c0886b4b9c30610e3ecef9101b80401f204220a203639633339373932316565316439353634643634353463643839653133333565	Proto3	\\x0a2463363032333266332d376362392d343438632d613133662d313764643238663935383733122437393565333031372d376235642d343062362d626530382d66653838633165393165636218032002	Proto3	11
4	\\x32049b68787240948e63d0dd59896a83	temporal-sys-history-scanner	\\xb219f01ceae44cd5b621d733e931d038	2	0	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121c74656d706f72616c2d7379732d686973746f72792d7363616e6e65724a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d30522574656d706f72616c2d7379732d686973746f72792d7363616e6e65722d776f726b666c6f775a0062006a02080a8801b4808003900101a2010c08c0b3b9c306109acbb58601aa010c08c0b3b9c30610dee3b88601ca0100d00101fa0109656d70747955756964980201da020c30202a2f3132202a202a202a9a03690a670a203639633339373932316565316439353634643634353463643839653133333565122435653731643637652d643863382d343661652d386639612d3362336662323962643237611804220b08c0b3b9c3061092c3f3602a0c08c0a8dec306109acbb586013001b2035412520a4c0a2462323139663031632d656165342d346364352d623632312d643733336539333164303338122434363334643266612d393166302d346236622d383235612d63383038646561663830356212020801ba032435653731643637652d643863382d343661652d386639612d336233666232396264323761c20303089803ca030b088092b8c398feffffff01d003b5808003d80301e2030c088085bcc306109acbb58601	Proto3	\\x0a2436373036333362642d663464392d343937302d616533392d643638326164373061633239122462323139663031632d656165342d346364352d623632312d64373333653933316430333818012001	Proto3	2
4	\\x32049b68787240948e63d0dd59896a83	temporal-sys-tq-scanner	\\x4696755b37ca42bab8a888e7a54efddc	2	0	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121774656d706f72616c2d7379732d74712d7363616e6e65724a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d30522074656d706f72616c2d7379732d74712d7363616e6e65722d776f726b666c6f775a0062040880af1a6a02080a8801c8808003900101a2010c0886b4b9c30610af80c79201aa010c0886b4b9c306108bc1df9201ca0100d00101fa0109656d70747955756964980201da020c30202a2f3132202a202a202a9a03690a670a203639633339373932316565316439353634643634353463643839653133333565122437393565333031372d376235642d343062362d626530382d6665383863316539316563621804220b08c0b3b9c30610eedcf3602a0c0886a9dec30610af80c792013001b2035412520a4c0a2434363936373535622d333763612d343262612d623861382d383865376135346566646463122461396637303532302d613131622d343331302d613833642d61343961396538666531623912020801ba032437393565333031372d376235642d343062362d626530382d666538386331653931656362c20303088d03ca030c0880b4d6c30610af80c79201d003c9808003d80301e2030c088085bcc30610af80c79201	Proto3	\\x0a2434643532363763332d373231372d346630332d626263662d356131316236616237613332122434363936373535622d333763612d343262612d623861382d38386537613534656664646318012001	Proto3	2
\.


--
-- Data for Name: history_immediate_tasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.history_immediate_tasks (shard_id, category_id, task_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: history_node; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.history_node (shard_id, tree_id, branch_id, node_id, txn_id, data, data_encoding, prev_txn_id) FROM stdin;
4	\\x5e71d67ed8c846ae8f9a3b3fb29bd27a	\\xed5427340d5f42afb2c96ec1c6ca8f00	1	-1048577	\\x0a92020801120b089d98b8c30610daa19a3318012880804032fa010a270a2574656d706f72616c2d7379732d686973746f72792d7363616e6e65722d776f726b666c6f772a2c0a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3010013a0042004a02080a5803722435653731643637652d643863382d343661652d386639612d3362336662323962643237617a0f31403765393633653837643666624082012435653731643637652d643863382d343661652d386639612d336233666232396264323761900101a2010c30202a2f3132202a202a202aaa010408a39b01ca0100e2011c74656d706f72616c2d7379732d686973746f72792d7363616e6e6572	Proto3	0
4	\\x795e30177b5d40b6be08fe88c1e91ecb	\\xfe65f5450c944d22a00d591f1f607380	1	-1048582	\\x0a87020801120b089d98b8c30610f2e8d33318012885804032ef010a220a2074656d706f72616c2d7379732d74712d7363616e6e65722d776f726b666c6f772a270a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3010013a0042040880af1a4a02080a5803722437393565333031372d376235642d343062362d626530382d6665383863316539316563627a0f31403765393633653837643666624082012437393565333031372d376235642d343062362d626530382d666538386331653931656362900101a2010c30202a2f3132202a202a202aaa010408a39b01ca0100e2011774656d706f72616c2d7379732d74712d7363616e6e6572	Proto3	0
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	1	-1048578	\\x0af6030801120c089e98b8c306108febb2f60218012880804032dd030a2d0a2b74656d706f72616c2d7379732d6164642d7365617263682d617474726962757465732d776f726b666c6f772a150a1164656661756c742d776f726b65722d7471100132f7010af4010a160a08656e636f64696e67120a6a736f6e2f706c61696e12d9017b22496e6465784e616d65223a22222c22437573746f6d41747472696275746573546f416464223a7b22437573746f6d426f6f6c4669656c64223a352c22437573746f6d4461746574696d654669656c64223a362c22437573746f6d446f75626c654669656c64223a342c22437573746f6d496e744669656c64223a332c22437573746f6d4b6579776f72644669656c64223a322c22437573746f6d537472696e674669656c64223a312c22437573746f6d546578744669656c64223a317d2c22536b6970536368656d61557064617465223a66616c73657d3a0042004a02080a722435343463656130392d303632622d343830312d613638642d3365343866353530373165667a0f31403765393633653837643666624082012435343463656130392d303632622d343830312d613638642d336534386635353037316566900101aa0100ca0100e2012b74656d706f72616c2d7379732d6164642d7365617263682d617474726962757465732d776f726b666c6f770a350802120c089e98b8c30610c2ceb6f602180528818040521d0a150a1164656661756c742d776f726b65722d747110011202080a1801	Proto3	0
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	3	-1048583	\\x0a540803120c089e98b8c30610d59dd7f9021806288680405a3c0802120f3140376539363365383764366662401a2436666263373231342d306538382d343734652d623665362d65343163353438353664336228b004	Proto3	1048578
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	4	-1048588	\\x0a6d0804120c089e98b8c30610d58782fc021807288a80406255080210031a0f3140376539363365383764366662402a220a20363963333937393231656531643935363464363435346364383965313333356532181201031a0b74656d706f72616c2d676f2206312e32352e316a000af1020805120c089e98b8c30610ebcd84fc02180a288b80407ad8020a0135121b0a1941646445534d617070696e674669656c64416374697669747922150a1164656661756c742d776f726b65722d747110012a0032f7010af4010a160a08656e636f64696e67120a6a736f6e2f706c61696e12d9017b22496e6465784e616d65223a22222c22437573746f6d41747472696275746573546f416464223a7b22437573746f6d426f6f6c4669656c64223a352c22437573746f6d4461746574696d654669656c64223a362c22437573746f6d446f75626c654669656c64223a342c22437573746f6d496e744669656c64223a332c22437573746f6d4b6579776f72644669656c64223a322c22437573746f6d537472696e674669656c64223a312c22437573746f6d546578744669656c64223a317d2c22536b6970536368656d61557064617465223a66616c73657d3a02081e4202081e4a02080a5200580462110a0208011100000000000000401a0208646801	Proto3	1048583
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	6	-1048597	\\x0a540806120c089e98b8c30610c285befd02180b2892804082013b0805120f3140376539363365383764366662401a2433626661633861322d363537622d343738322d623562652d34336231343862636162653920010a2e0807120c089e98b8c3061091dafcfe02180c289380408a011510051806220f3140376539363365383764366662400a680808120c089e98b8c30610b4f8fcfe0218052894804052500a480a313765393633653837643666623a35353035663965622d313437382d346363652d623839612d35353231613933613166616410021a1164656661756c742d776f726b65722d74711202080a1801	Proto3	1048588
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	9	-1048601	\\x0a540809120c089e98b8c30610b3dbbf80031806289880405a3c0808120f3140376539363365383764366662401a2465303031623066362d313834382d343037322d623961622d31316266653137643366633728d90a	Proto3	1048597
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	10	-1048606	\\x0a55080a120c089e98b8c306108b9bdf81031807289c8040623d080810091a0f3140376539363365383764366662402a220a20363963333937393231656531643935363464363435346364383965313333356532006a000a9b01080b120c089e98b8c30610e9e8e08103180a289d80407a82010a023131121d0a1b57616974466f7259656c6c6f77537461747573416374697669747922150a1164656661756c742d776f726b65722d747110012a00321e0a1c0a160a08656e636f64696e67120a6a736f6e2f706c61696e120222223a02083c4202083c4a0208145200580a62120a0208051100000000000000401a0308f4036801	Proto3	1048601
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	12	-1048614	\\x0a54080c120c089e98b8c30610a3f2998303180b28a3804082013b080b120f3140376539363365383764366662401a2464613731333733352d633439302d343664612d396163352d37326538653463306133326320010a2e080d120c089e98b8c30610d0ce9d8403180c28a480408a0115100b180c220f3140376539363365383764366662400a68080e120c089e98b8c3061082e89d8403180528a5804052500a480a313765393633653837643666623a35353035663965622d313437382d346363652d623839612d35353231613933613166616410021a1164656661756c742d776f726b65722d74711202080a1801	Proto3	1048606
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	15	-1048618	\\x0a54080f120c089e98b8c30610e6e4ac8503180628a980405a3c080e120f3140376539363365383764366662401a2435623932616666312d643533352d343033312d626364372d62653439346237623635356528940f	Proto3	1048614
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	16	-1048623	\\x0a550810120c089e98b8c30610849eb48603180728ad8040623d080e100f1a0f3140376539363365383764366662402a220a20363963333937393231656531643935363464363435346364383965313333356532006a000af6020811120c089e98b8c3061089c3b58603180a28ae80407add020a023137121f0a1d557064617465436c75737465724d65746164617461416374697669747922150a1164656661756c742d776f726b65722d747110012a0032f7010af4010a160a08656e636f64696e67120a6a736f6e2f706c61696e12d9017b22496e6465784e616d65223a22222c22437573746f6d41747472696275746573546f416464223a7b22437573746f6d426f6f6c4669656c64223a352c22437573746f6d4461746574696d654669656c64223a362c22437573746f6d446f75626c654669656c64223a342c22437573746f6d496e744669656c64223a332c22437573746f6d4b6579776f72644669656c64223a322c22437573746f6d537472696e674669656c64223a312c22437573746f6d546578744669656c64223a317d2c22536b6970536368656d61557064617465223a66616c73657d3a02080a4202080a4a0208025200581062110a0208011100000000000000401a0208646801	Proto3	1048618
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	18	-1048631	\\x0a540812120c089e98b8c30610d7a2b98703180b28b4804082013b0811120f3140376539363365383764366662401a2439323337376635302d643332312d343038322d396339612d33326136353233313166383720010a2e0813120c089e98b8c306109c87b08903180c28b580408a011510111812220f3140376539363365383764366662400a680814120c089e98b8c30610e09ab08903180528b6804052500a480a313765393633653837643666623a35353035663965622d313437382d346363652d623839612d35353231613933613166616410021a1164656661756c742d776f726b65722d74711202080a1801	Proto3	1048623
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	21	-1048635	\\x0a540815120c089e98b8c30610e987b78a03180628ba80405a3c0814120f3140376539363365383764366662401a2438633436336133622d323636662d346334322d623664352d64313066643133643634326228aa15	Proto3	1048631
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	22	-1048640	\\x0a550816120c089e98b8c30610d8a4ed8b03180728be8040623d081410151a0f3140376539363365383764366662402a220a20363963333937393231656531643935363464363435346364383965313333356532006a000a1a0817120c089e98b8c30610f5d7f08b03180228bf80403a021016	Proto3	1048635
4	\\xe3d24e986a9643c6bcaa0b9846ed7564	\\x4ab65abf6daa4edc9272d7b6e58ce5f2	1	-2097153	\\x0a88020801120c08f984b9c30610b3dae6ce031801288080800132ee010a220a2074656d706f72616c2d7379732d74712d7363616e6e65722d776f726b666c6f772a270a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3010013a0042040880af1a4a02080a5803722465336432346539382d366139362d343363362d626361612d3062393834366564373536347a0f31403634353865633031643663614082012465336432346539382d366139362d343363362d626361612d306239383436656437353634900101a2010c30202a2f3132202a202a202aaa010308c72eca0100e2011774656d706f72616c2d7379732d74712d7363616e6e6572	Proto3	0
4	\\x73ff63b3c68e4d8988401cf29915f146	\\x9a29185a3d5048c280e48022edccb287	1	-2097158	\\x0a93020801120c08f984b9c30610a589fece031801288580800132f9010a270a2574656d706f72616c2d7379732d686973746f72792d7363616e6e65722d776f726b666c6f772a2c0a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3010013a0042004a02080a5803722437336666363362332d633638652d346438392d383834302d3163663239393135663134367a0f31403634353865633031643663614082012437336666363362332d633638652d346438392d383834302d316366323939313566313436900101a2010c30202a2f3132202a202a202aaa010308c72eca0100e2011c74656d706f72616c2d7379732d686973746f72792d7363616e6e6572	Proto3	0
4	\\x9397ff6396b5422fa901ea5c9efd6a59	\\xfb82b723fbf642eab3b35accf302fb11	1	-3145729	\\x0a87020801120b08bc85b9c30610caa4a2511801288080c00132ee010a220a2074656d706f72616c2d7379732d74712d7363616e6e65722d776f726b666c6f772a270a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3010013a0042040880af1a4a02080a5803722439333937666636332d393662352d343232662d613930312d6561356339656664366135397a0f31403639356466636633633530644082012439333937666636332d393662352d343232662d613930312d656135633965666436613539900101a2010c30202a2f3132202a202a202aaa010308842eca0100e2011774656d706f72616c2d7379732d74712d7363616e6e6572	Proto3	0
4	\\x903d85ee183142f7b2dac3e94689b951	\\x7f35a7f019734f9fa68ee10fd9f0d54f	1	-3145734	\\x0a92020801120b08bc85b9c3061080aebe511801288580c00132f9010a270a2574656d706f72616c2d7379732d686973746f72792d7363616e6e65722d776f726b666c6f772a2c0a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3010013a0042004a02080a5803722439303364383565652d313833312d343266372d623264612d6333653934363839623935317a0f31403639356466636633633530644082012439303364383565652d313833312d343266372d623264612d633365393436383962393531900101a2010c30202a2f3132202a202a202aaa010308842eca0100e2011c74656d706f72616c2d7379732d686973746f72792d7363616e6e6572	Proto3	0
4	\\x45d22a45fbac4222864542be794a60a2	\\xa67c0b4960b34ca380cf7585bc739d9c	1	-4194305	\\x0a93020801120c088a86b9c3061097bbfbe4021801288080800232f9010a270a2574656d706f72616c2d7379732d686973746f72792d7363616e6e65722d776f726b666c6f772a2c0a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3010013a0042004a02080a5803722434356432326134352d666261632d343232322d383634352d3432626537393461363061327a0f31403938643432636635643662654082012434356432326134352d666261632d343232322d383634352d343262653739346136306132900101a2010c30202a2f3132202a202a202aaa010308b62dca0100e2011c74656d706f72616c2d7379732d686973746f72792d7363616e6e6572	Proto3	0
4	\\x32d74d33f61b46b2b26b9d89bbbf8430	\\x99c21a3fe0074438845da43adc2f5ff9	1	-4194309	\\x0a88020801120c088a86b9c30610d5b18ae5021801288480800232ee010a220a2074656d706f72616c2d7379732d74712d7363616e6e65722d776f726b666c6f772a270a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3010013a0042040880af1a4a02080a5803722433326437346433332d663631622d343662322d623236622d3964383962626266383433307a0f31403938643432636635643662654082012433326437346433332d663631622d343662322d623236622d396438396262626638343330900101a2010c30202a2f3132202a202a202aaa010308b62dca0100e2011774656d706f72616c2d7379732d74712d7363616e6e6572	Proto3	0
4	\\xb2df759f9b8c4e54b256511ce05ce49b	\\x797e90da90a0475eaf9b556cba2f1bb4	1	-5242881	\\x0a92020801120b08bc98b9c30610e5a59d2b1801288080c00232f9010a270a2574656d706f72616c2d7379732d686973746f72792d7363616e6e65722d776f726b666c6f772a2c0a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3010013a0042004a02080a5803722462326466373539662d396238632d346535342d623235362d3531316365303563653439627a0f31403032323331386333326466634082012462326466373539662d396238632d346535342d623235362d353131636530356365343962900101a2010c30202a2f3132202a202a202aaa010308841bca0100e2011c74656d706f72616c2d7379732d686973746f72792d7363616e6e6572	Proto3	0
4	\\xc92e1e642e944311b5cbacfc27a9e4d9	\\x289374a109b44184a7242d2a8011835a	1	-5242885	\\x0a87020801120b08bc98b9c306109fd39a2b1801288480c00232ee010a220a2074656d706f72616c2d7379732d74712d7363616e6e65722d776f726b666c6f772a270a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3010013a0042040880af1a4a02080a5803722463393265316536342d326539342d343331312d623563622d6163666332376139653464397a0f31403032323331386333326466634082012463393265316536342d326539342d343331312d623563622d616366633237613965346439900101a2010c30202a2f3132202a202a202aaa010308841bca0100e2011774656d706f72616c2d7379732d74712d7363616e6e6572	Proto3	0
4	\\xbc4147e60bce4bc194c9c3ccb4f2b858	\\x12dad8805b4a4b00bd5675530740f798	1	-6291457	\\x0a88020801120c08d5afb9c30610f0b6f6b8031801288080800332ee010a220a2074656d706f72616c2d7379732d74712d7363616e6e65722d776f726b666c6f772a270a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3010013a0042040880af1a4a02080a5803722462633431343765362d306263652d346263312d393463392d6333636362346632623835387a0f31403562353339376430303730354082012462633431343765362d306263652d346263312d393463392d633363636234663262383538900101a2010c30202a2f3132202a202a202aaa010308eb03ca0100e2011774656d706f72616c2d7379732d74712d7363616e6e6572	Proto3	0
4	\\x7dc37ba6ddfb4f63b61616ff7f1f634b	\\x76e9f8ac71484c3e8d13ef807c505f81	1	-6291462	\\x0a93020801120c08d5afb9c30610f1bec9c3031801288580800332f9010a270a2574656d706f72616c2d7379732d686973746f72792d7363616e6e65722d776f726b666c6f772a2c0a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3010013a0042004a02080a5803722437646333376261362d646466622d346636332d623631362d3136666637663166363334627a0f31403562353339376430303730354082012437646333376261362d646466622d346636332d623631362d313666663766316636333462900101a2010c30202a2f3132202a202a202aaa010308eb03ca0100e2011c74656d706f72616c2d7379732d686973746f72792d7363616e6e6572	Proto3	0
4	\\x795e30177b5d40b6be08fe88c1e91ecb	\\xfe65f5450c944d22a00d591f1f607380	2	-6291466	\\x0a470802120b08c0b3b9c30610ababee4318052889808003522f0a270a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3010011202080a1801	Proto3	1048582
4	\\x5e71d67ed8c846ae8f9a3b3fb29bd27a	\\xed5427340d5f42afb2c96ec1c6ca8f00	2	-6291469	\\x0a4c0802120b08c0b3b9c30610908fff431805288c80800352340a2c0a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3010011202080a1801	Proto3	1048577
4	\\x795e30177b5d40b6be08fe88c1e91ecb	\\xfe65f5450c944d22a00d591f1f607380	3	-6291472	\\x0a540803120b08c0b3b9c30610ff8f9f511806288f8080035a3c0802120f3140356235333937643030373035401a2433346336633262372d363937372d343830622d393663642d65333934613335316232653228d302	Proto3	6291466
4	\\x5e71d67ed8c846ae8f9a3b3fb29bd27a	\\xed5427340d5f42afb2c96ec1c6ca8f00	3	-6291476	\\x0a540803120b08c0b3b9c30610c2cd9f51180628938080035a3c0802120f3140356235333937643030373035401a2434336238336132622d303030342d346563352d396138662d39646238376431393364356328e302	Proto3	6291469
4	\\x795e30177b5d40b6be08fe88c1e91ecb	\\xfe65f5450c944d22a00d591f1f607380	4	-6291481	\\x0a6d0804120b08c0b3b9c30610bbd1f360180728978080036255080210031a0f3140356235333937643030373035402a220a20363963333937393231656531643935363464363435346364383965313333356532181201031a0b74656d706f72616c2d676f2206312e32352e316a000a9e010805120b08c0b3b9c30610deac8b62180a28988080037a85010a013512270a2574656d706f72616c2d7379732d74712d7363616e6e65722d736376672d616374697669747922270a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3010012a003a040880af1a420308ac024a040880af1a520308ac02580462120a02080a11333333333333fb3f1a0308ac026801	Proto3	6291472
4	\\x5e71d67ed8c846ae8f9a3b3fb29bd27a	\\xed5427340d5f42afb2c96ec1c6ca8f00	4	-6291487	\\x0a6d0804120b08c0b3b9c30610ecb3f3601807289d8080036255080210031a0f3140356235333937643030373035402a220a20363963333937393231656531643935363464363435346364383965313333356532181201031a0b74656d706f72616c2d676f2206312e32352e316a000aa6010805120b08c0b3b9c30610a6dcf861180a289e8080037a8d010a0135122c0a2a74656d706f72616c2d7379732d686973746f72792d7363616e6e65722d736376672d6163746976697479222c0a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3010012a003a00420308ac024a0608808ce0ac02520308ac02580462120a02080a11333333333333fb3f1a0308ac026801	Proto3	6291476
4	\\x5e71d67ed8c846ae8f9a3b3fb29bd27a	\\xed5427340d5f42afb2c96ec1c6ca8f00	6	-6291498	\\x0a540806120b08c0b3b9c3061090bb9c6d180b28a780800382013b0805120f3140356235333937643030373035401a2432393666376536342d323166392d346335342d383636662d35383035623864376564653920010aa3010807120c08c0b3b9c30610c3c5fc8001180c28a88080038a0188010a710a6f0a160a08656e636f64696e67120a6a736f6e2f706c61696e12557b2253756363657373436f756e74223a302c224572726f72436f756e74223a302c22536b6970436f756e74223a31332c2243757272656e7450616765223a312c224e65787450616765546f6b656e223a6e756c6c7d10051806220f3140356235333937643030373035400a80010808120c08c0b3b9c30610b29efd8001180528a980800352670a5f0a313562353339376430303730353a64313232303531312d343262322d343337372d383865362d64363763623832376131653110021a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d301202080a1801	Proto3	6291487
4	\\x5e71d67ed8c846ae8f9a3b3fb29bd27a	\\xed5427340d5f42afb2c96ec1c6ca8f00	9	-6291502	\\x0a550809120c08c0b3b9c306108496968301180628ad8080035a3c0808120f3140356235333937643030373035401a2437303030393831642d346133392d343861632d393964332d37393061366664333538656428d008	Proto3	6291498
4	\\x5e71d67ed8c846ae8f9a3b3fb29bd27a	\\xed5427340d5f42afb2c96ec1c6ca8f00	10	-6291507	\\x0a56080a120c08c0b3b9c30610d0e8d28501180728b1808003623d080810091a0f3140356235333937643030373035402a220a20363963333937393231656531643935363464363435346364383965313333356532006a000a41080b120c08c0b3b9c30610e6fbe58501180228b28080033a28100a1a2462323139663031632d656165342d346364352d623632312d643733336539333164303338	Proto3	6291502
4	\\xb219f01ceae44cd5b621d733e931d038	\\x4634d2fa91f04b6b825ac808deaf805b	1	-6291509	\\x0a95030801120c08c0b3b9c306109acbb58601180128b480800332fb020a270a2574656d706f72616c2d7379732d686973746f72792d7363616e6e65722d776f726b666c6f772a2c0a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3010013a0042004a02080a522435653731643637652d643863382d343661652d386639612d3362336662323962643237615803722462323139663031632d656165342d346364352d623632312d64373333653933316430333882012435653731643637652d643863382d343661652d386639612d336233666232396264323761900101a2010c30202a2f3132202a202a202aaa010408c0d102c201690a670a203639633339373932316565316439353634643634353463643839653133333565122435653731643637652d643863382d343661652d386639612d3362336662323962643237611804220b08c0b3b9c3061092c3f3602a0c08c0a8dec306109acbb586013001ca0100e2011c74656d706f72616c2d7379732d686973746f72792d7363616e6e6572	Proto3	0
4	\\x795e30177b5d40b6be08fe88c1e91ecb	\\xfe65f5450c944d22a00d591f1f607380	6	-6291518	\\x0a540806120b08c0b3b9c30610e3ce916d180b28bb80800382013b0805120f3140356235333937643030373035401a2432653438363530372d363635302d346431642d623965652d33306237303434653065653720010a2f0807120c0886b4b9c30610c3a4f78501180c28bc8080038a011510051806220f3140356235333937643030373035400a7b0808120c0886b4b9c30610ff87fa8501180528bd80800352620a5a0a313562353339376430303730353a35326539356638642d643662342d346535642d383530322d37363137396435383065396110021a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d301202080a1801	Proto3	6291481
4	\\x795e30177b5d40b6be08fe88c1e91ecb	\\xfe65f5450c944d22a00d591f1f607380	9	-6291522	\\x0a550809120c0886b4b9c30610848ac88c01180628c18080035a3c0808120f3140356235333937643030373035401a2463623764646165622d363864652d343631342d616465352d30386633363735646238343928bd07	Proto3	6291518
4	\\x795e30177b5d40b6be08fe88c1e91ecb	\\xfe65f5450c944d22a00d591f1f607380	10	-6291527	\\x0a56080a120c0886b4b9c30610e39fdf9101180728c5808003623d080810091a0f3140356235333937643030373035402a220a20363963333937393231656531643935363464363435346364383965313333356532006a000a41080b120c0886b4b9c30610e3ecef9101180228c68080033a28100a1a2434363936373535622d333763612d343262612d623861382d383865376135346566646463	Proto3	6291522
4	\\x4696755b37ca42bab8a888e7a54efddc	\\xa9f70520a11b4310a83da49a9e8fe1b9	1	-6291529	\\x0a8a030801120c0886b4b9c30610af80c79201180128c880800332f0020a220a2074656d706f72616c2d7379732d74712d7363616e6e65722d776f726b666c6f772a270a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3010013a0042040880af1a4a02080a522437393565333031372d376235642d343062362d626530382d6665383863316539316563625803722434363936373535622d333763612d343262612d623861382d38386537613534656664646382012437393565333031372d376235642d343062362d626530382d666538386331653931656362900101a2010c30202a2f3132202a202a202aaa010408fad002c201690a670a203639633339373932316565316439353634643634353463643839653133333565122437393565333031372d376235642d343062362d626530382d6665383863316539316563621804220b08c0b3b9c30610eedcf3602a0c0886a9dec30610af80c792013001ca0100e2011774656d706f72616c2d7379732d74712d7363616e6e6572	Proto3	0
4	\\xc3ff0ca09e76437eb8b7c40c7a337d34	\\x4cf38558944645a1ab18d8fc3fa3f355	1	-7340033	\\x0a93020801120b08cf8abac3061084b088721801288080c00332fa010a270a2574656d706f72616c2d7379732d686973746f72792d7363616e6e65722d776f726b666c6f772a2c0a2874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3010013a0042004a02080a5803722463336666306361302d396537362d343337652d623862372d6334306337613333376433347a0f31403162336334323166396633334082012463336666306361302d396537362d343337652d623862372d633430633761333337643334900101a2010c30202a2f3132202a202a202aaa010408b1fa01ca0100e2011c74656d706f72616c2d7379732d686973746f72792d7363616e6e6572	Proto3	0
4	\\x017de7877e534c67abc46eacbbd39435	\\x6decf9db0b2c460d85c1f9292018f357	1	-7340037	\\x0a88020801120b08cf8abac30610afa2fa711801288480c00332ef010a220a2074656d706f72616c2d7379732d74712d7363616e6e65722d776f726b666c6f772a270a2374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3010013a0042040880af1a4a02080a5803722430313764653738372d376535332d346336372d616263342d3665616362626433393433357a0f31403162336334323166396633334082012430313764653738372d376535332d346336372d616263342d366561636262643339343335900101a2010c30202a2f3132202a202a202aaa010408b1fa01ca0100e2011774656d706f72616c2d7379732d74712d7363616e6e6572	Proto3	0
\.


--
-- Data for Name: history_scheduled_tasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.history_scheduled_tasks (shard_id, category_id, visibility_timestamp, task_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: history_tree; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.history_tree (shard_id, tree_id, branch_id, data, data_encoding) FROM stdin;
4	\\x5e71d67ed8c846ae8f9a3b3fb29bd27a	\\xed5427340d5f42afb2c96ec1c6ca8f00	\\x0a4c0a2435653731643637652d643863382d343661652d386639612d336233666232396264323761122465643534323733342d306435662d343261662d623263392d366563316336636138663030120b089d98b8c3061094acd1331a6633323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d686973746f72792d7363616e6e65723a35653731643637652d643863382d343661652d386639612d336233666232396264323761224c0a2435653731643637652d643863382d343661652d386639612d336233666232396264323761122465643534323733342d306435662d343261662d623263392d366563316336636138663030	Proto3
4	\\x795e30177b5d40b6be08fe88c1e91ecb	\\xfe65f5450c944d22a00d591f1f607380	\\x0a4c0a2437393565333031372d376235642d343062362d626530382d666538386331653931656362122466653635663534352d306339342d346432322d613030642d353931663166363037333830120b089d98b8c30610c791ab361a6133323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d74712d7363616e6e65723a37393565333031372d376235642d343062362d626530382d666538386331653931656362224c0a2437393565333031372d376235642d343062362d626530382d666538386331653931656362122466653635663534352d306339342d346432322d613030642d353931663166363037333830	Proto3
3	\\x544cea09062b4801a68d3e48f55071ef	\\x3a917ff99cdf4ed08ff944ca610158c5	\\x0a4c0a2435343463656130392d303632622d343830312d613638642d336534386635353037316566122433613931376666392d396364662d346564302d386666392d343463613631303135386335120c089e98b8c306108e88bcf6021a7533323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d6164642d7365617263682d617474726962757465732d776f726b666c6f773a35343463656130392d303632622d343830312d613638642d336534386635353037316566224c0a2435343463656130392d303632622d343830312d613638642d336534386635353037316566122433613931376666392d396364662d346564302d386666392d343463613631303135386335	Proto3
4	\\xe3d24e986a9643c6bcaa0b9846ed7564	\\x4ab65abf6daa4edc9272d7b6e58ce5f2	\\x0a4c0a2465336432346539382d366139362d343363362d626361612d306239383436656437353634122434616236356162662d366461612d346564632d393237322d643762366535386365356632120c08f984b9c30610ae87f9ce031a6133323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d74712d7363616e6e65723a65336432346539382d366139362d343363362d626361612d306239383436656437353634224c0a2465336432346539382d366139362d343363362d626361612d306239383436656437353634122434616236356162662d366461612d346564632d393237322d643762366535386365356632	Proto3
4	\\x73ff63b3c68e4d8988401cf29915f146	\\x9a29185a3d5048c280e48022edccb287	\\x0a4c0a2437336666363362332d633638652d346438392d383834302d316366323939313566313436122439613239313835612d336435302d343863322d383065342d383032326564636362323837120c08f984b9c30610f8b199d1031a6633323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d686973746f72792d7363616e6e65723a37336666363362332d633638652d346438392d383834302d316366323939313566313436224c0a2437336666363362332d633638652d346438392d383834302d316366323939313566313436122439613239313835612d336435302d343863322d383065342d383032326564636362323837	Proto3
4	\\x9397ff6396b5422fa901ea5c9efd6a59	\\xfb82b723fbf642eab3b35accf302fb11	\\x0a4c0a2439333937666636332d393662352d343232662d613930312d656135633965666436613539122466623832623732332d666266362d343265612d623362332d356163636633303266623131120b08bc85b9c30610a291b6511a6133323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d74712d7363616e6e65723a39333937666636332d393662352d343232662d613930312d656135633965666436613539224c0a2439333937666636332d393662352d343232662d613930312d656135633965666436613539122466623832623732332d666266362d343265612d623362332d356163636633303266623131	Proto3
4	\\x903d85ee183142f7b2dac3e94689b951	\\x7f35a7f019734f9fa68ee10fd9f0d54f	\\x0a4c0a2439303364383565652d313833312d343266372d623264612d633365393436383962393531122437663335613766302d313937332d346639662d613638652d653130666439663064353466120b08bc85b9c3061096e594551a6633323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d686973746f72792d7363616e6e65723a39303364383565652d313833312d343266372d623264612d633365393436383962393531224c0a2439303364383565652d313833312d343266372d623264612d633365393436383962393531122437663335613766302d313937332d346639662d613638652d653130666439663064353466	Proto3
4	\\x45d22a45fbac4222864542be794a60a2	\\xa67c0b4960b34ca380cf7585bc739d9c	\\x0a4c0a2434356432326134352d666261632d343232322d383634352d343262653739346136306132122461363763306234392d363062332d346361332d383063662d373538356263373339643963120c088a86b9c30610d8c9a2e5021a6633323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d686973746f72792d7363616e6e65723a34356432326134352d666261632d343232322d383634352d343262653739346136306132224c0a2434356432326134352d666261632d343232322d383634352d343262653739346136306132122461363763306234392d363062332d346361332d383063662d373538356263373339643963	Proto3
4	\\x32d74d33f61b46b2b26b9d89bbbf8430	\\x99c21a3fe0074438845da43adc2f5ff9	\\x0a4c0a2433326437346433332d663631622d343662322d623236622d396438396262626638343330122439396332316133662d653030372d343433382d383435642d613433616463326635666639120c088a86b9c30610d899dfe7021a6133323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d74712d7363616e6e65723a33326437346433332d663631622d343662322d623236622d396438396262626638343330224c0a2433326437346433332d663631622d343662322d623236622d396438396262626638343330122439396332316133662d653030372d343433382d383435642d613433616463326635666639	Proto3
4	\\xb2df759f9b8c4e54b256511ce05ce49b	\\x797e90da90a0475eaf9b556cba2f1bb4	\\x0a4c0a2462326466373539662d396238632d346535342d623235362d353131636530356365343962122437393765393064612d393061302d343735652d616639622d353536636261326631626234120b08bc98b9c306108286a92b1a6633323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d686973746f72792d7363616e6e65723a62326466373539662d396238632d346535342d623235362d353131636530356365343962224c0a2462326466373539662d396238632d346535342d623235362d353131636530356365343962122437393765393064612d393061302d343735652d616639622d353536636261326631626234	Proto3
4	\\xc92e1e642e944311b5cbacfc27a9e4d9	\\x289374a109b44184a7242d2a8011835a	\\x0a4c0a2463393265316536342d326539342d343331312d623563622d616366633237613965346439122432383933373461312d303962342d343138342d613732342d326432613830313138333561120b08bc98b9c30610ff97a22d1a6133323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d74712d7363616e6e65723a63393265316536342d326539342d343331312d623563622d616366633237613965346439224c0a2463393265316536342d326539342d343331312d623563622d616366633237613965346439122432383933373461312d303962342d343138342d613732342d326432613830313138333561	Proto3
4	\\xbc4147e60bce4bc194c9c3ccb4f2b858	\\x12dad8805b4a4b00bd5675530740f798	\\x0a4c0a2462633431343765362d306263652d346263312d393463392d633363636234663262383538122431326461643838302d356234612d346230302d626435362d373535333037343066373938120c08d5afb9c306108ae4d7c1031a6133323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d74712d7363616e6e65723a62633431343765362d306263652d346263312d393463392d633363636234663262383538224c0a2462633431343765362d306263652d346263312d393463392d633363636234663262383538122431326461643838302d356234612d346230302d626435362d373535333037343066373938	Proto3
4	\\x7dc37ba6ddfb4f63b61616ff7f1f634b	\\x76e9f8ac71484c3e8d13ef807c505f81	\\x0a4c0a2437646333376261362d646466622d346636332d623631362d313666663766316636333462122437366539663861632d373134382d346333652d386431332d656638303763353035663831120c08d5afb9c3061085adc1ca031a6633323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d686973746f72792d7363616e6e65723a37646333376261362d646466622d346636332d623631362d313666663766316636333462224c0a2437646333376261362d646466622d346636332d623631362d313666663766316636333462122437366539663861632d373134382d346333652d386431332d656638303763353035663831	Proto3
4	\\xb219f01ceae44cd5b621d733e931d038	\\x4634d2fa91f04b6b825ac808deaf805b	\\x0a4c0a2462323139663031632d656165342d346364352d623632312d643733336539333164303338122434363334643266612d393166302d346236622d383235612d633830386465616638303562120c08c0b3b9c30610f280bb86011a6633323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d686973746f72792d7363616e6e65723a62323139663031632d656165342d346364352d623632312d643733336539333164303338224c0a2462323139663031632d656165342d346364352d623632312d643733336539333164303338122434363334643266612d393166302d346236622d383235612d633830386465616638303562	Proto3
4	\\x4696755b37ca42bab8a888e7a54efddc	\\xa9f70520a11b4310a83da49a9e8fe1b9	\\x0a4c0a2434363936373535622d333763612d343262612d623861382d383865376135346566646463122461396637303532302d613131622d343331302d613833642d613439613965386665316239120c0886b4b9c30610d8e1e392011a6133323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d74712d7363616e6e65723a34363936373535622d333763612d343262612d623861382d383865376135346566646463224c0a2434363936373535622d333763612d343262612d623861382d383865376135346566646463122461396637303532302d613131622d343331302d613833642d613439613965386665316239	Proto3
4	\\xc3ff0ca09e76437eb8b7c40c7a337d34	\\x4cf38558944645a1ab18d8fc3fa3f355	\\x0a4c0a2463336666306361302d396537362d343337652d623862372d633430633761333337643334122434636633383535382d393434362d343561312d616231382d643866633366613366333535120b08cf8abac30610d4e9ad721a6633323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d686973746f72792d7363616e6e65723a63336666306361302d396537362d343337652d623862372d633430633761333337643334224c0a2463336666306361302d396537362d343337652d623862372d633430633761333337643334122434636633383535382d393434362d343561312d616231382d643866633366613366333535	Proto3
4	\\x017de7877e534c67abc46eacbbd39435	\\x6decf9db0b2c460d85c1f9292018f357	\\x0a4c0a2430313764653738372d376535332d346336372d616263342d366561636262643339343335122436646563663964622d306232632d343630642d383563312d663932393230313866333537120b08cf8abac30610fb828f751a6133323034396236382d373837322d343039342d386536332d6430646435393839366138333a74656d706f72616c2d7379732d74712d7363616e6e65723a30313764653738372d376535332d346336372d616263342d366561636262643339343335224c0a2430313764653738372d376535332d346336372d616263342d366561636262643339343335122436646563663964622d306232632d343630642d383563312d663932393230313866333537	Proto3
\.


--
-- Data for Name: namespace_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.namespace_metadata (partition_id, notification_version) FROM stdin;
54321	3
\.


--
-- Data for Name: namespaces; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.namespaces (partition_id, id, name, notification_version, data, data_encoding, is_global) FROM stdin;
54321	\\x32049b68787240948e63d0dd59896a83	temporal-system	1	\\x0a780a2433323034396236382d373837322d343039342d386536332d64306464353938393661383310011a0f74656d706f72616c2d73797374656d222254656d706f72616c20696e7465726e616c2073797374656d206e616d6573706163652a1974656d706f72616c2d636f72654074656d706f72616c2e696f120a0a040880f524200130011a100a06616374697665120661637469766528ffffffffffffffffff01	Proto3	f
54321	\\xcd9e02c77af34ee0b69fe4988ee0a941	default	2	\\x0a590a2463643965303263372d376166332d346565302d623639662d65343938386565306139343110011a0764656661756c74222644656661756c74206e616d65737061636520666f722054656d706f72616c205365727665722e120c0a040880a3051a00200130011a120a0661637469766512066163746976651801	Proto3	f
\.


--
-- Data for Name: queue; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.queue (queue_type, message_id, message_payload, message_encoding) FROM stdin;
\.


--
-- Data for Name: queue_metadata; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.queue_metadata (queue_type, data, data_encoding, version) FROM stdin;
1	\\x	Proto3	0
-1	\\x	Proto3	0
\.


--
-- Data for Name: replication_tasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.replication_tasks (shard_id, task_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: replication_tasks_dlq; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.replication_tasks_dlq (source_cluster_name, shard_id, task_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: request_cancel_info_maps; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.request_cancel_info_maps (shard_id, namespace_id, workflow_id, run_id, initiated_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: schema_update_history; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.schema_update_history (version_partition, year, month, update_time, description, manifest_md5, new_version, old_version) FROM stdin;
0	2025	7	2025-07-09 06:28:44.332998	initial version		0.0	0
0	2025	7	2025-07-09 06:28:44.424124	base version of schema	55b84ca114ac34d84bdc5f52c198fa33	1.0	0.0
0	2025	7	2025-07-09 06:28:44.426069	schema update for cluster metadata	58f06841bbb187cb210db32a090c21ee	1.1	1.0
0	2025	7	2025-07-09 06:28:44.427789	schema update for RPC replication	c6bdeea21882e2625038927a84929b16	1.2	1.1
0	2025	7	2025-07-09 06:28:44.430823	schema update for kafka deprecation	3beee7d470421674194475f94b58d89b	1.3	1.2
0	2025	7	2025-07-09 06:28:44.432157	schema update for cluster metadata cleanup	c53e2e9cea5660c8a1f3b2ac73cdb138	1.4	1.3
0	2025	7	2025-07-09 06:28:44.434066	schema update for cluster_membership, executions and history_node tables	bfb307ba10ac0fdec83e0065dc5ffee4	1.5	1.4
0	2025	7	2025-07-09 06:28:44.434955	schema update for queue_metadata	978e1a6500d377ba91c6e37e5275a59b	1.6	1.5
0	2025	7	2025-07-09 06:28:44.440514	create cluster metadata info table to store cluster information and executions to store tiered storage queue	366b8b49d6701a6a09778e51ad1682ed	1.7	1.6
0	2025	7	2025-07-09 06:28:44.443723	drop unused tasks table; Expand VARCHAR columns governed by maxIDLength to VARCHAR(255)	229846b5beb0b96f49e7a3c5fde09fa7	1.8	1.7
0	2025	7	2025-07-09 06:28:44.450616	add history tasks table	b62e4e5826967e152e00b75da42d12ea	1.9	1.8
0	2025	7	2025-07-09 06:28:44.456998	add storage for update records and create task_queue_user_data table	2b0c361b0d4ab7cf09ead5566f0db520	1.10	1.9
\.


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.schema_version (version_partition, db_name, creation_time, curr_version, min_compatible_version) FROM stdin;
0	temporal	2025-07-09 06:28:44.456592	1.10	1.0
\.


--
-- Data for Name: shards; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.shards (shard_id, range_id, data, data_encoding) FROM stdin;
3	7	\\x080310071a373137322e32302e302e31333a373233342d312d34353062383063652d366232622d343565622d393330382d3137383733653762326235343a0b08c4a7bac30610c4e0ee148a010d0804120912070a00108080c0038a011408051210120e0a0c08fca5bac3061080a8b2d1038a011408021210120e0a0c088aa5bac30610c0d2aac8038a010d0801120912070a00108080c003	Proto3
1	7	\\x080110071a373137322e32302e302e31333a373233342d322d65303336356330372d353339612d346633352d613466392d3330376137343439383264373a0c08d5a7bac30610829397f2028a010d0801120912070a00108080c0038a011408051210120e0a0c08dba6bac30610c0cc9682018a010d0804120912070a00108080c0038a01130802120f120d0a0b08e5a6bac30610c0de810a	Proto3
4	7	\\x080410071a373137322e32302e302e31333a373233342d332d32356637343061342d373034642d343233652d393035392d3736623933383065656136643a0b08e2a9bac306108cf5cb608a010d0801120912070a00108080c0038a011408051210120e0a0c08eca8bac3061080e4feb4028a01130802120f120d0a0b08afa9bac30610809bf77c8a010d0804120912070a00108080c003	Proto3
2	7	\\x080210071a373137322e32302e302e31333a373233342d342d31666334613730352d333139632d343837322d623761372d6432336466363630353631643a0c08f1a9bac30610c5f2c0c5028a01130805120f120d0a0b08b7a7bac30610c0b19f058a01130802120f120d0a0b08c6a9bac30610c0e6d64e8a010d0804120912070a00108080c0038a010d0801120912070a00108080c003	Proto3
\.


--
-- Data for Name: signal_info_maps; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.signal_info_maps (shard_id, namespace_id, workflow_id, run_id, initiated_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: signals_requested_sets; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.signals_requested_sets (shard_id, namespace_id, workflow_id, run_id, signal_id) FROM stdin;
\.


--
-- Data for Name: task_queue_user_data; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_queue_user_data (namespace_id, task_queue_name, data, data_encoding, version) FROM stdin;
\.


--
-- Data for Name: task_queues; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.task_queues (range_hash, task_queue_id, range_id, data, data_encoding) FROM stdin;
1566030568	\\x32049b68787240948e63d0dd59896a833938643432636635643662653a38393665373630632d373138362d343233312d386235382d35396538613763366332633001	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313938643432636635643662653a38393665373630632d373138362d343233312d386235382d35396538613763366332633018012002320c08aabbbec30610cbfdb1a3013a0c08aa98b9c30610c5ffb1a301	Proto3
3286889561	\\x32049b68787240948e63d0dd59896a833032323331386333326466633a63316339396136362d353263622d346134392d386433352d36366335336638313336316301	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313032323331386333326466633a63316339396136362d353263622d346134392d386433352d36366335336638313336316318012002320c08b0bebec30610bfe4eaf3023a0c08b09bb9c30610b9e6eaf302	Proto3
3329352183	\\xcd9e02c77af34ee0b69fe4988ee0a9413938643432636635643662653a65383337356639342d643964652d343131652d383363652d63613438313263626637353201	1	\\x0a2463643965303263372d376166332d346565302d623639662d65343938386565306139343112313938643432636635643662653a65383337356639342d643964652d343131652d383363652d63613438313263626637353218012002320c08aabbbec30610b18ebfa7013a0c08aa98b9c30610d78fbfa701	Proto3
1757711364	\\x32049b68787240948e63d0dd59896a833562353339376430303730353a35326539356638642d643662342d346535642d383530322d37363137396435383065396101	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313562353339376430303730353a35326539356638642d643662342d346535642d383530322d37363137396435383065396118012002320c08b2adbfc306109b84e1af033a0c08b28abac30610ee84e1af03	Proto3
1688886821	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d7379732d70726f636573736f722d706172656e742d636c6f73652d706f6c69637902	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833122a74656d706f72616c2d7379732d70726f636573736f722d706172656e742d636c6f73652d706f6c6963791802200128c0cf243a0c08c7a9bac30610db80aac403	Proto3
2063506710	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d617263686976616c2d747101	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121474656d706f72616c2d617263686976616c2d74711801200128c0cf243a0c08c7a9bac30610c381b1c403	Proto3
2528910666	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d7379732d70726f636573736f722d706172656e742d636c6f73652d706f6c69637901	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833122a74656d706f72616c2d7379732d70726f636573736f722d706172656e742d636c6f73652d706f6c6963791801200128c0cf243a0c08c7a9bac30610addcc2c603	Proto3
921622716	\\x32049b68787240948e63d0dd59896a833938643432636635643662653a38353530346432332d393564332d343865312d396465312d30646265386337306631666601	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313938643432636635643662653a38353530346432332d393564332d343865312d396465312d30646265386337306631666618012002320c08aabbbec30610d488919d013a0c08aa98b9c30610fb89919d01	Proto3
2259433258	\\x32049b68787240948e63d0dd59896a833938643432636635643662653a61626265363437322d356536662d343130342d396561652d32616539383535316562303101	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313938643432636635643662653a61626265363437322d356536662d343130342d396561652d32616539383535316562303118012002320c08aabbbec30610afd0e7a8013a0c08aa98b9c30610d6d1e7a801	Proto3
3633973331	\\x32049b68787240948e63d0dd59896a833639356466636633633530643a36616238333861362d313566342d343463312d623731352d64353131626562656435653001	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313639356466636633633530643a36616238333861362d313566342d343463312d623731352d64353131626562656435653018012002320c08f0a8bec30610e780c8d2013a0c08f085b9c30610b184c8d201	Proto3
1527865893	\\x32049b68787240948e63d0dd59896a833938643432636635643662653a33373430626535622d313232322d343735372d613433312d33356334663065333636386201	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313938643432636635643662653a33373430626535622d313232322d343735372d613433312d33356334663065333636386218012002320c08aabbbec30610839997aa013a0c08aa98b9c30610a79b97aa01	Proto3
489415294	\\x32049b68787240948e63d0dd59896a833938643432636635643662653a30376432623438662d656165612d343263332d393361362d62616564663065656335623901	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313938643432636635643662653a30376432623438662d656165612d343263332d393361362d62616564663065656335623918012002320c08aabbbec30610aaeec5aa013a0c08aa98b9c30610fbefc5aa01	Proto3
628837424	\\x32049b68787240948e63d0dd59896a833938643432636635643662653a30326434613530652d353735362d343935612d386261332d63336237616530346334386301	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313938643432636635643662653a30326434613530652d353735362d343935612d386261332d63336237616530346334386318012002320c08aabbbec30610a79fe9aa013a0c08aa98b9c30610a4a0e9aa01	Proto3
3610383032	\\x32049b68787240948e63d0dd59896a833765393633653837643666623a35353035663965622d313437382d346363652d623839612d35353231613933613166616401	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313765393633653837643666623a35353035663965622d313437382d346363652d623839612d35353231613933613166616418012002320b08e0a7bec30610b5c5cc2c3a0b08e084b9c30610b2c6cc2c	Proto3
1315506371	\\xcd9e02c77af34ee0b69fe4988ee0a9413765393633653837643666623a63376235653134322d613962362d343532372d623664362d31333866373032356162396201	1	\\x0a2463643965303263372d376166332d346565302d623639662d65343938386565306139343112313765393633653837643666623a63376235653134322d613962362d343532372d623664362d31333866373032356162396218012002320b08e0a7bec30610cd89da3b3a0b08e084b9c30610c48cda3b	Proto3
1683705101	\\x32049b68787240948e63d0dd59896a833634353865633031643663613a65663437376435322d366165332d346233652d623833352d39623638663963373630333401	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313634353865633031643663613a65663437376435322d366165332d346233652d623833352d39623638663963373630333418012002320b08faa7bec3061096ecc4413a0b08fa84b9c30610baeec441	Proto3
2277078745	\\xcd9e02c77af34ee0b69fe4988ee0a94174656d706f72616c2d7379732d7065722d6e732d747102	7	\\x0a2463643965303263372d376166332d346565302d623639662d653439383865653061393431121674656d706f72616c2d7379732d7065722d6e732d74711802200128c0cf243a0c088ba9bac30610988ebbb902	Proto3
3764945626	\\xcd9e02c77af34ee0b69fe4988ee0a94174656d706f72616c2d7379732d7065722d6e732d747101	7	\\x0a2463643965303263372d376166332d346565302d623639662d653439383865653061393431121674656d706f72616c2d7379732d7065722d6e732d74711801200128c0cf243a0c088ba9bac30610b9f2eeb902	Proto3
3734757610	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d7379732d7065722d6e732d747101	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121674656d706f72616c2d7379732d7065722d6e732d74711801200128c0cf243a0c088ba9bac30610a18fe8b902	Proto3
3343083358	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d7379732d7065722d6e732d747102	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121674656d706f72616c2d7379732d7065722d6e732d74711802200128c0cf243a0c088ba9bac30610d8e0deb902	Proto3
223356625	\\x32049b68787240948e63d0dd59896a8364656661756c742d776f726b65722d747102	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121164656661756c742d776f726b65722d74711802200128c0cf243a0c08c7a9bac306109db5fac003	Proto3
288707420	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d617263686976616c2d747102	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121474656d706f72616c2d617263686976616c2d74711802200128c0cf243a0c08c7a9bac30610fc82afc403	Proto3
2091865415	\\x32049b68787240948e63d0dd59896a833162336334323166396633333a65333734366537382d633962332d343436362d623034392d35353531336635643637303701	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313162336334323166396633333a65333734366537382d633962332d343436362d623034392d35353531336635643637303718012002320c08c7ccbfc30610e8c6adc4033a0c08c7a9bac30610e2c8adc403	Proto3
720314659	\\x32049b68787240948e63d0dd59896a833639356466636633633530643a31356664363366622d613736362d343231652d386138392d34373532656532346332356501	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313639356466636633633530643a31356664363366622d613736362d343231652d386138392d34373532656532346332356518012002320c08f0a8bec30610fcd7ead8013a0c08f085b9c30610a0daead801	Proto3
1410825331	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3002	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833122374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d301802200128c0cf243a0c08c7a9bac306109ec2b2c403	Proto3
1619217437	\\x32049b68787240948e63d0dd59896a833032323331386333326466633a39643633313930362d616533332d343165652d386261352d65363063663336383263643101	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313032323331386333326466633a39643633313930362d616533332d343165652d386261352d65363063663336383263643118012002320c08b0bebec30610b1a78bf8023a0c08b09bb9c3061081a98bf802	Proto3
3957811894	\\x32049b68787240948e63d0dd59896a833162336334323166396633333a35653830393531362d386239392d343232342d383533662d39666633303734636136623601	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313162336334323166396633333a35653830393531362d386239392d343232342d383533662d39666633303734636136623618012002320c08c7ccbfc3061098bda5c6033a0c08c7a9bac3061092bfa5c603	Proto3
3469555445	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d7379732d626174636865722d7461736b717565756501	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121e74656d706f72616c2d7379732d626174636865722d7461736b71756575651801200128c0cf243a0c08c7a9bac30610e184a2c603	Proto3
3678588242	\\x32049b68787240948e63d0dd59896a833765393633653837643666623a36313163653465662d643333662d343538322d613036302d66363131656262313761666201	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313765393633653837643666623a36313163653465662d643333662d343538322d613036302d66363131656262313761666218012002320b08e0a7bec30610f0f88e2e3a0b08e084b9c30610c1fa8e2e	Proto3
964672121	\\x32049b68787240948e63d0dd59896a833765393633653837643666623a66366561323863652d333036382d343633642d396132652d32386465656366303863383601	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313765393633653837643666623a66366561323863652d333036382d343633642d396132652d32386465656366303863383618012002320b08e0a7bec30610dacb9d353a0b08e084b9c30610a1d09d35	Proto3
4031166216	\\x32049b68787240948e63d0dd59896a833562353339376430303730353a37346165623063322d613362352d343832312d623062322d31316538316263316539646601	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313562353339376430303730353a37346165623063322d613362352d343832312d623062322d31316538316263316539646618012002320c08b2adbfc30610a7e4b5b1033a0c08b28abac30610a4e5b5b103	Proto3
2890844060	\\x32049b68787240948e63d0dd59896a833634353865633031643663613a36643863303764362d323439302d343765632d623864342d33653235393837363363663901	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313634353865633031643663613a36643863303764362d323439302d343765632d623864342d33653235393837363363663918012002320b08faa7bec30610e5c787443a0b08fa84b9c30610adcc8744	Proto3
3414411070	\\x32049b68787240948e63d0dd59896a833938643432636635643662653a30376538333363642d633364372d343436382d383362342d66613462663563646563316601	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313938643432636635643662653a30376538333363642d633364372d343436382d383362342d66613462663563646563316618012002320c08aabbbec30610e883e394013a0c08aa98b9c30610e285e39401	Proto3
3215470477	\\x32049b68787240948e63d0dd59896a833162336334323166396633333a61323134323433372d656163302d346238392d623437652d30343063333134623839366301	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313162336334323166396633333a61323134323433372d656163302d346238392d623437652d30343063333134623839366318012002320c08c7ccbfc30610b7a8a4c6033a0c08c7a9bac30610daaaa4c603	Proto3
3549031360	\\x32049b68787240948e63d0dd59896a833639356466636633633530643a38663930343630342d626466362d346664372d616566632d30353433643638623164616101	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313639356466636633633530643a38663930343630342d626466362d346664372d616566632d30353433643638623164616118012002320c08f0a8bec3061093cdb9e1013a0c08f085b9c30610e0cfb9e101	Proto3
673699352	\\x32049b68787240948e63d0dd59896a833162336334323166396633333a66306161356539312d636163382d346561332d396266332d32353162666430613736313701	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313162336334323166396633333a66306161356539312d636163382d346561332d396266332d32353162666430613736313718012002320c08c7ccbfc30610e0b3cac6033a0c08c7a9bac30610aeb6cac603	Proto3
4281416734	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3002	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833122874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d301802200128c0cf243a0c08c7a9bac30610a4bbcec603	Proto3
86295304	\\x32049b68787240948e63d0dd59896a833765393633653837643666623a33383035613562302d303162352d343131312d386332312d32346130636131323162326201	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313765393633653837643666623a33383035613562302d303162352d343131312d386332312d32346130636131323162326218012002320b08e0a7bec30610e2c1972d3a0b08e084b9c30610b6c2972d	Proto3
725014587	\\x32049b68787240948e63d0dd59896a833634353865633031643663613a36316433363937612d303334352d343732342d616533622d32313565373133623864313201	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313634353865633031643663613a36316433363937612d303334352d343732342d616533622d32313565373133623864313218012002320b08faa7bec30610f59bb9443a0b08fa84b9c306109b9db944	Proto3
2604553071	\\x32049b68787240948e63d0dd59896a833032323331386333326466633a36643732313630662d613639642d346234332d383038632d62336139613565343235323301	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313032323331386333326466633a36643732313630662d613639642d346234332d383038632d62336139613565343235323318012002320c08b0bebec30610abf4b8ed023a0c08b09bb9c30610ccf7b8ed02	Proto3
28195965	\\x32049b68787240948e63d0dd59896a833032323331386333326466633a63666234623962642d363733392d343562372d613335342d63323565633665303436366501	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313032323331386333326466633a63666234623962642d363733392d343562372d613335342d63323565633665303436366518012002320c08b0bebec30610f3f9b7f8023a0c08b09bb9c30610f0fab7f802	Proto3
1682929212	\\x32049b68787240948e63d0dd59896a833562353339376430303730353a37383831393938332d303132642d343631322d616337362d30613537316339353165333101	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313562353339376430303730353a37383831393938332d303132642d343631322d616337362d30613537316339353165333118012002320c08b2adbfc3061095deceaa033a0c08b28abac3061092dfceaa03	Proto3
1989765357	\\x32049b68787240948e63d0dd59896a833562353339376430303730353a64313232303531312d343262322d343337372d383865362d64363763623832376131653101	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313562353339376430303730353a64313232303531312d343262322d343337372d383865362d64363763623832376131653118012002320c08b2adbfc30610988fd6b0033a0c08b28abac30610e990d6b003	Proto3
1713739395	\\x32049b68787240948e63d0dd59896a833634353865633031643663613a33623537306439362d393833652d343332632d383163332d30373061393630323733376301	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313634353865633031643663613a33623537306439362d393833652d343332632d383163332d30373061393630323733376318012002320c089ca8bec30610a4c2b2ab023a0c089c85b9c30610c5c5b2ab02	Proto3
2444320760	\\x32049b68787240948e63d0dd59896a833162336334323166396633333a33346234653839642d376532362d343566372d613439332d30333264666630363132613401	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313162336334323166396633333a33346234653839642d376532362d343566372d613439332d30333264666630363132613418012002320c08c7ccbfc30610d5c5beb9033a0c08c7a9bac3061093cdbeb903	Proto3
3810647023	\\x32049b68787240948e63d0dd59896a8364656661756c742d776f726b65722d747101	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121164656661756c742d776f726b65722d74711801200128c0cf243a0c08c7a9bac30610fcf2aac403	Proto3
4066717557	\\xcd9e02c77af34ee0b69fe4988ee0a9413639356466636633633530643a33643739343333332d363366612d343539322d383936642d33313535323862306230386301	1	\\x0a2463643965303263372d376166332d346565302d623639662d65343938386565306139343112313639356466636633633530643a33643739343333332d363366612d343539322d383936642d33313535323862306230386318012002320c08f0a8bec30610dfed9edf013a0c08f085b9c30610d6f09edf01	Proto3
866755191	\\x32049b68787240948e63d0dd59896a833639356466636633633530643a36373731386531642d383236392d346636362d626635302d31663134623935626462643001	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313639356466636633633530643a36373731386531642d383236392d346636362d626635302d31663134623935626462643018012002320c08f0a8bec30610b4b2a9e5013a0c08f085b9c30610d8b4a9e501	Proto3
1038851210	\\x32049b68787240948e63d0dd59896a833162336334323166396633333a37343037333837652d666236352d343137362d396639642d65333335326664663237363601	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313162336334323166396633333a37343037333837652d666236352d343137362d396639642d65333335326664663237363618012002320c08c7ccbfc30610c1fea2c6033a0c08c7a9bac30610bb80a3c603	Proto3
4244893811	\\x32049b68787240948e63d0dd59896a833562353339376430303730353a63333061643666632d323135392d346234342d393163632d62366131303232666235336401	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313562353339376430303730353a63333061643666632d323135392d346234342d393163632d62366131303232666235336418012002320c08b2adbfc30610b09f9ca8033a0c08b28abac30610ada09ca803	Proto3
284522659	\\x32049b68787240948e63d0dd59896a833032323331386333326466633a61353730383865332d383732302d343762342d623461322d35313533353038323764653401	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313032323331386333326466633a61353730383865332d383732302d343762342d623461322d35313533353038323764653418012002320c08b0bebec3061089e9b7f6023a0c08b09bb9c30610b0eab7f602	Proto3
793330494	\\x32049b68787240948e63d0dd59896a833032323331386333326466633a35333530356266342d323531392d343435322d616561362d30326264623139646233366301	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313032323331386333326466633a35333530356266342d323531392d343435322d616561362d30326264623139646233366318012002320c08b0bebec30610c58aa8f7023a0c08b09bb9c30610988ba8f702	Proto3
1788044248	\\x32049b68787240948e63d0dd59896a833639356466636633633530643a64366634373834392d326530392d343434622d383363352d34333165646637636365663801	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313639356466636633633530643a64366634373834392d326530392d343434622d383363352d34333165646637636365663818012002320c08bca8bec30610ccf188a9013a0c08bc85b9c30610eff388a901	Proto3
171329438	\\x32049b68787240948e63d0dd59896a833639356466636633633530643a34636639636436642d303736632d346633612d623964662d31326234643032336536643701	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313639356466636633633530643a34636639636436642d303736632d346633612d623964662d31326234643032336536643718012002320c08bca8bec30610d28ccbaa013a0c08bc85b9c30610cf8dcbaa01	Proto3
3823516297	\\x32049b68787240948e63d0dd59896a833765393633653837643666623a39313964353866662d346533632d343232642d623734662d37656536383636373531393001	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313765393633653837643666623a39313964353866662d346533632d343232642d623734662d37656536383636373531393018012002320b08e0a7bec3061090eabe313a0b08e084b9c30610b4ecbe31	Proto3
1325391950	\\x32049b68787240948e63d0dd59896a833634353865633031643663613a63336538393034312d333934322d343935352d393838312d66303564353434383732333601	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313634353865633031643663613a63336538393034312d333934322d343935352d393838312d66303564353434383732333618012002320b08faa7bec3061080b0fa493a0b08fa84b9c30610a4b2fa49	Proto3
3888565498	\\x32049b68787240948e63d0dd59896a833162336334323166396633333a64643134333364312d303639392d343237342d623533612d66343736656339643663633801	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313162336334323166396633333a64643134333364312d303639392d343237342d623533612d66343736656339643663633818012002320c08c7ccbfc30610bfc9a6c6033a0c08c7a9bac30610e5caa6c603	Proto3
2158604455	\\xcd9e02c77af34ee0b69fe4988ee0a9413162336334323166396633333a64646537346333372d343837622d343235362d386262652d31663036326635643263623001	1	\\x0a2463643965303263372d376166332d346565302d623639662d65343938386565306139343112313162336334323166396633333a64646537346333372d343837622d343235362d386262652d31663036326635643263623018012002320c08c7ccbfc306108fcba6c6033a0c08c7a9bac306108ccca6c603	Proto3
142727818	\\x32049b68787240948e63d0dd59896a833032323331386333326466633a38313838653764342d363939612d343733342d613136382d31336534663332303366346101	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313032323331386333326466633a38313838653764342d363939612d343733342d613136382d31336534663332303366346118012002320c08b0bebec30610eaa2c2f2023a0c08b09bb9c30610e4a4c2f202	Proto3
96893160	\\x32049b68787240948e63d0dd59896a833562353339376430303730353a65633838643530322d646631612d346633662d386334622d63343136393031663230363901	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313562353339376430303730353a65633838643530322d646631612d346633662d386334622d63343136393031663230363918012002320c08b2adbfc30610d7f6f9a6033a0c08b28abac30610d1f8f9a603	Proto3
877533474	\\x32049b68787240948e63d0dd59896a833639356466636633633530643a34626132373666622d623938382d343534622d623561652d61313039633737366661393501	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313639356466636633633530643a34626132373666622d623938382d343534622d623561652d61313039633737366661393518012002320c08f0a8bec3061094aaf8e7013a0c08f085b9c30610e4abf8e701	Proto3
1122731744	\\x32049b68787240948e63d0dd59896a833765393633653837643666623a66316433643864372d396663642d343438332d396461302d39373264366433653531613801	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313765393633653837643666623a66316433643864372d396663642d343438332d396461302d39373264366433653531613818012002320b08e0a7bec306108bcaee3f3a0b08e084b9c3061085ccee3f	Proto3
3668147502	\\x32049b68787240948e63d0dd59896a833634353865633031643663613a61363434366535372d333238392d346531632d613436652d36373262323435633730303501	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313634353865633031643663613a61363434366535372d333238392d346531632d613436652d36373262323435633730303518012002320b08faa7bec30610e5a7ab4b3a0b08fa84b9c30610e2a8ab4b	Proto3
3877784121	\\x32049b68787240948e63d0dd59896a833634353865633031643663613a37333034333935302d386162652d346362612d623230642d34336335336334633565306401	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313634353865633031643663613a37333034333935302d386162652d346362612d623230642d34336335336334633565306418012002320b08faa7bec30610ebf08f4c3a0b08fa84b9c30610bef18f4c	Proto3
3509128233	\\xcd9e02c77af34ee0b69fe4988ee0a9413032323331386333326466633a37393966343162352d653232362d343233342d393830662d33336134326362616130336501	1	\\x0a2463643965303263372d376166332d346565302d623639662d65343938386565306139343112313032323331386333326466633a37393966343162352d653232362d343233342d393830662d33336134326362616130336518012002320c08b0bebec30610fb89a5f3023a0c08b09bb9c30610f58ba5f302	Proto3
2810406604	\\xcd9e02c77af34ee0b69fe4988ee0a9413562353339376430303730353a66643837313239612d336364642d346632362d383863382d38316336613762313030356101	1	\\x0a2463643965303263372d376166332d346565302d623639662d65343938386565306139343112313562353339376430303730353a66643837313239612d336364642d346632362d383863382d38316336613762313030356118012002320c08b2adbfc3061082e9b7ab033a0c08b28abac30610a8eab7ab03	Proto3
1832919139	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d3001	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833122874656d706f72616c2d7379732d686973746f72792d7363616e6e65722d7461736b71756575652d301801200128c0cf243a0c08c7a9bac30610a1d0a7c603	Proto3
3844983969	\\xcd9e02c77af34ee0b69fe4988ee0a9413634353865633031643663613a31333339303361382d663361652d346139662d626266332d35623635633365643739643801	1	\\x0a2463643965303263372d376166332d346565302d623639662d65343938386565306139343112313634353865633031643663613a31333339303361382d663361652d346139662d626266332d35623635633365643739643818012002320b08faa7bec30610b78f9e4c3a0b08fa84b9c30610b4909e4c	Proto3
1854128520	\\x32049b68787240948e63d0dd59896a833562353339376430303730353a30303162316366342d376263362d343735382d396161642d35663038306131633431313201	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313562353339376430303730353a30303162316366342d376263362d343735382d396161642d35663038306131633431313218012002320c08b2adbfc30610c593b2ac033a0c08b28abac306109695b2ac03	Proto3
4214421317	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d3001	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833122374656d706f72616c2d7379732d74712d7363616e6e65722d7461736b71756575652d301801200128c0cf243a0c08c7a9bac30610bfbdb0c403	Proto3
3637047286	\\x32049b68787240948e63d0dd59896a833765393633653837643666623a62363535396232332d663466372d346331612d393330332d38646430613635626536313601	1	\\x0a2433323034396236382d373837322d343039342d386536332d64306464353938393661383312313765393633653837643666623a62363535396232332d663466372d346331612d393330332d38646430613635626536313618012002320b08e0a7bec30610c2f0c73e3a0b08e084b9c3061093f2c73e	Proto3
3095716534	\\x32049b68787240948e63d0dd59896a8374656d706f72616c2d7379732d626174636865722d7461736b717565756502	7	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121e74656d706f72616c2d7379732d626174636865722d7461736b71756575651802200128c0cf243a0c08c7a9bac306108fd0cec603	Proto3
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.tasks (range_hash, task_queue_id, task_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: timer_info_maps; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.timer_info_maps (shard_id, namespace_id, workflow_id, run_id, timer_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: timer_tasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.timer_tasks (shard_id, visibility_timestamp, task_id, data, data_encoding) FROM stdin;
4	2025-07-14 12:00:00.108328	1048583	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121774656d706f72616c2d7379732d74712d7363616e6e65721a2437393565333031372d376235642d343062362d626530382d666538386331653931656362200f508780405a0b08c0e2d3c30610f2e8d333	Proto3
3	2025-07-16 06:37:23.889416	1048641	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833122b74656d706f72616c2d7379732d6164642d7365617263682d617474726962757465732d776f726b666c6f771a2435343463656130392d303632622d343830312d613638642d336534386635353037316566201050c180405a0c08a391ddc30610bcd38da803624c0a2435343463656130392d303632622d343830312d613638642d336534386635353037316566122433613931376666392d396364662d346564302d386666392d343463613631303135386335	Proto3
4	2025-07-16 12:08:28.895126	6291510	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121c74656d706f72616c2d7379732d686973746f72792d7363616e6e65721a2435653731643637652d643863382d343661652d386639612d336233666232396264323761201050b68080035a0c08bcacdec30610c596eaaa03624c0a2435653731643637652d643863382d343661652d386639612d336233666232396264323761122465643534323733342d306435662d343261662d623263392d366563316336636138663030	Proto3
4	2025-07-10 00:00:00.281896	6291514	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121c74656d706f72616c2d7379732d686973746f72792d7363616e6e65721a2462323139663031632d656165342d346364352d623632312d6437333365393331643033382012300250ba8080035a0c088085bcc306109acbb58601	Proto3
4	2025-07-16 12:04:55.087896	6291530	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121774656d706f72616c2d7379732d74712d7363616e6e65721a2437393565333031372d376235642d343062362d626530382d666538386331653931656362201050ca8080035a0b08e7aadec306108ce3f429624c0a2437393565333031372d376235642d343062362d626530382d666538386331653931656362122466653635663534352d306339342d346432322d613030642d353931663166363037333830	Proto3
4	2025-07-15 00:00:00.307347	6291533	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121774656d706f72616c2d7379732d74712d7363616e6e65721a2434363936373535622d333763612d343262612d623861382d383865376135346566646463200f50cd8080035a0c0880b4d6c30610af80c79201	Proto3
4	2025-07-10 00:00:00.307347	6291534	\\x0a2433323034396236382d373837322d343039342d386536332d643064643539383936613833121774656d706f72616c2d7379732d74712d7363616e6e65721a2434363936373535622d333763612d343262612d623861382d3838653761353465666464632012300250ce8080035a0c088085bcc30610af80c79201	Proto3
\.


--
-- Data for Name: transfer_tasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.transfer_tasks (shard_id, task_id, data, data_encoding) FROM stdin;
\.


--
-- Data for Name: visibility_tasks; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.visibility_tasks (shard_id, task_id, data, data_encoding) FROM stdin;
\.


--
-- Name: buffered_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: developer
--

SELECT pg_catalog.setval('public.buffered_events_id_seq', 1, false);


--
-- Name: activity_info_maps activity_info_maps_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.activity_info_maps
    ADD CONSTRAINT activity_info_maps_pkey PRIMARY KEY (shard_id, namespace_id, workflow_id, run_id, schedule_id);


--
-- Name: buffered_events buffered_events_id_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.buffered_events
    ADD CONSTRAINT buffered_events_id_key UNIQUE (id);


--
-- Name: buffered_events buffered_events_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.buffered_events
    ADD CONSTRAINT buffered_events_pkey PRIMARY KEY (shard_id, namespace_id, workflow_id, run_id, id);


--
-- Name: build_id_to_task_queue build_id_to_task_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.build_id_to_task_queue
    ADD CONSTRAINT build_id_to_task_queue_pkey PRIMARY KEY (namespace_id, build_id, task_queue_name);


--
-- Name: child_execution_info_maps child_execution_info_maps_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.child_execution_info_maps
    ADD CONSTRAINT child_execution_info_maps_pkey PRIMARY KEY (shard_id, namespace_id, workflow_id, run_id, initiated_id);


--
-- Name: cluster_membership cluster_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.cluster_membership
    ADD CONSTRAINT cluster_membership_pkey PRIMARY KEY (membership_partition, host_id);


--
-- Name: cluster_metadata_info cluster_metadata_info_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.cluster_metadata_info
    ADD CONSTRAINT cluster_metadata_info_pkey PRIMARY KEY (metadata_partition, cluster_name);


--
-- Name: cluster_metadata cluster_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.cluster_metadata
    ADD CONSTRAINT cluster_metadata_pkey PRIMARY KEY (metadata_partition);


--
-- Name: current_executions current_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.current_executions
    ADD CONSTRAINT current_executions_pkey PRIMARY KEY (shard_id, namespace_id, workflow_id);


--
-- Name: executions executions_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.executions
    ADD CONSTRAINT executions_pkey PRIMARY KEY (shard_id, namespace_id, workflow_id, run_id);


--
-- Name: history_immediate_tasks history_immediate_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.history_immediate_tasks
    ADD CONSTRAINT history_immediate_tasks_pkey PRIMARY KEY (shard_id, category_id, task_id);


--
-- Name: history_node history_node_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.history_node
    ADD CONSTRAINT history_node_pkey PRIMARY KEY (shard_id, tree_id, branch_id, node_id, txn_id);


--
-- Name: history_scheduled_tasks history_scheduled_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.history_scheduled_tasks
    ADD CONSTRAINT history_scheduled_tasks_pkey PRIMARY KEY (shard_id, category_id, visibility_timestamp, task_id);


--
-- Name: history_tree history_tree_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.history_tree
    ADD CONSTRAINT history_tree_pkey PRIMARY KEY (shard_id, tree_id, branch_id);


--
-- Name: namespace_metadata namespace_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.namespace_metadata
    ADD CONSTRAINT namespace_metadata_pkey PRIMARY KEY (partition_id);


--
-- Name: namespaces namespaces_name_key; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.namespaces
    ADD CONSTRAINT namespaces_name_key UNIQUE (name);


--
-- Name: namespaces namespaces_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.namespaces
    ADD CONSTRAINT namespaces_pkey PRIMARY KEY (partition_id, id);


--
-- Name: queue_metadata queue_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.queue_metadata
    ADD CONSTRAINT queue_metadata_pkey PRIMARY KEY (queue_type);


--
-- Name: queue queue_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.queue
    ADD CONSTRAINT queue_pkey PRIMARY KEY (queue_type, message_id);


--
-- Name: replication_tasks_dlq replication_tasks_dlq_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.replication_tasks_dlq
    ADD CONSTRAINT replication_tasks_dlq_pkey PRIMARY KEY (source_cluster_name, shard_id, task_id);


--
-- Name: replication_tasks replication_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.replication_tasks
    ADD CONSTRAINT replication_tasks_pkey PRIMARY KEY (shard_id, task_id);


--
-- Name: request_cancel_info_maps request_cancel_info_maps_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.request_cancel_info_maps
    ADD CONSTRAINT request_cancel_info_maps_pkey PRIMARY KEY (shard_id, namespace_id, workflow_id, run_id, initiated_id);


--
-- Name: schema_update_history schema_update_history_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.schema_update_history
    ADD CONSTRAINT schema_update_history_pkey PRIMARY KEY (version_partition, year, month, update_time);


--
-- Name: schema_version schema_version_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.schema_version
    ADD CONSTRAINT schema_version_pkey PRIMARY KEY (version_partition, db_name);


--
-- Name: shards shards_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.shards
    ADD CONSTRAINT shards_pkey PRIMARY KEY (shard_id);


--
-- Name: signal_info_maps signal_info_maps_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.signal_info_maps
    ADD CONSTRAINT signal_info_maps_pkey PRIMARY KEY (shard_id, namespace_id, workflow_id, run_id, initiated_id);


--
-- Name: signals_requested_sets signals_requested_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.signals_requested_sets
    ADD CONSTRAINT signals_requested_sets_pkey PRIMARY KEY (shard_id, namespace_id, workflow_id, run_id, signal_id);


--
-- Name: task_queue_user_data task_queue_user_data_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_queue_user_data
    ADD CONSTRAINT task_queue_user_data_pkey PRIMARY KEY (namespace_id, task_queue_name);


--
-- Name: task_queues task_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.task_queues
    ADD CONSTRAINT task_queues_pkey PRIMARY KEY (range_hash, task_queue_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (range_hash, task_queue_id, task_id);


--
-- Name: timer_info_maps timer_info_maps_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.timer_info_maps
    ADD CONSTRAINT timer_info_maps_pkey PRIMARY KEY (shard_id, namespace_id, workflow_id, run_id, timer_id);


--
-- Name: timer_tasks timer_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.timer_tasks
    ADD CONSTRAINT timer_tasks_pkey PRIMARY KEY (shard_id, visibility_timestamp, task_id);


--
-- Name: transfer_tasks transfer_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.transfer_tasks
    ADD CONSTRAINT transfer_tasks_pkey PRIMARY KEY (shard_id, task_id);


--
-- Name: visibility_tasks visibility_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.visibility_tasks
    ADD CONSTRAINT visibility_tasks_pkey PRIMARY KEY (shard_id, task_id);


--
-- Name: cm_idx_lasthb; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX cm_idx_lasthb ON public.cluster_membership USING btree (last_heartbeat);


--
-- Name: cm_idx_recordexpiry; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX cm_idx_recordexpiry ON public.cluster_membership USING btree (record_expiry);


--
-- Name: cm_idx_rolehost; Type: INDEX; Schema: public; Owner: developer
--

CREATE UNIQUE INDEX cm_idx_rolehost ON public.cluster_membership USING btree (role, host_id);


--
-- Name: cm_idx_rolelasthb; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX cm_idx_rolelasthb ON public.cluster_membership USING btree (role, last_heartbeat);


--
-- Name: cm_idx_rpchost; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX cm_idx_rpchost ON public.cluster_membership USING btree (rpc_address, role);


--
-- PostgreSQL database dump complete
--

--
-- Database "temporal_visibility" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: temporal_visibility; Type: DATABASE; Schema: -; Owner: developer
--

CREATE DATABASE temporal_visibility WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE temporal_visibility OWNER TO developer;

\connect temporal_visibility

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: executions_visibility; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.executions_visibility (
    namespace_id character(64) NOT NULL,
    run_id character(64) NOT NULL,
    start_time timestamp without time zone NOT NULL,
    execution_time timestamp without time zone NOT NULL,
    workflow_id character varying(255) NOT NULL,
    workflow_type_name character varying(255) NOT NULL,
    status integer NOT NULL,
    close_time timestamp without time zone,
    history_length bigint,
    memo bytea,
    encoding character varying(64) NOT NULL,
    task_queue character varying(255) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.executions_visibility OWNER TO developer;

--
-- Name: schema_update_history; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.schema_update_history (
    version_partition integer NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    update_time timestamp without time zone NOT NULL,
    description character varying(255),
    manifest_md5 character varying(64),
    new_version character varying(64),
    old_version character varying(64)
);


ALTER TABLE public.schema_update_history OWNER TO developer;

--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: developer
--

CREATE TABLE public.schema_version (
    version_partition integer NOT NULL,
    db_name character varying(255) NOT NULL,
    creation_time timestamp without time zone,
    curr_version character varying(64),
    min_compatible_version character varying(64)
);


ALTER TABLE public.schema_version OWNER TO developer;

--
-- Data for Name: executions_visibility; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.executions_visibility (namespace_id, run_id, start_time, execution_time, workflow_id, workflow_type_name, status, close_time, history_length, memo, encoding, task_queue) FROM stdin;
32049b68-7872-4094-8e63-d0dd59896a83                            	544cea09-062b-4801-a68d-3e48f55071ef                            	2025-07-09 06:28:46.785167	2025-07-09 06:28:46.785167	temporal-sys-add-search-attributes-workflow	temporal-sys-add-search-attributes-workflow	2	2025-07-09 06:28:46.830221	23	\\x	Proto3	default-worker-tq
32049b68-7872-4094-8e63-d0dd59896a83                            	b219f01c-eae4-4cd5-b621-d733e931d038                            	2025-07-09 12:00:00.281896	2025-07-10 00:00:00.281896	temporal-sys-history-scanner	temporal-sys-history-scanner-workflow	1	\N	\N	\\x	Proto3	temporal-sys-history-scanner-taskqueue-0
32049b68-7872-4094-8e63-d0dd59896a83                            	5e71d67e-d8c8-46ae-8f9a-3b3fb29bd27a                            	2025-07-09 06:28:45.107385	2025-07-09 12:00:00.107385	temporal-sys-history-scanner	temporal-sys-history-scanner-workflow	2	2025-07-09 12:00:00.280591	11	\\x	Proto3	temporal-sys-history-scanner-taskqueue-0
32049b68-7872-4094-8e63-d0dd59896a83                            	795e3017-7b5d-40b6-be08-fe88c1e91ecb                            	2025-07-09 06:28:45.108328	2025-07-09 12:00:00.108328	temporal-sys-tq-scanner	temporal-sys-tq-scanner-workflow	2	2025-07-09 12:01:10.305919	11	\\x	Proto3	temporal-sys-tq-scanner-taskqueue-0
32049b68-7872-4094-8e63-d0dd59896a83                            	4696755b-37ca-42ba-b8a8-88e7a54efddc                            	2025-07-09 12:01:10.307347	2025-07-10 00:00:00.307347	temporal-sys-tq-scanner	temporal-sys-tq-scanner-workflow	1	\N	\N	\\x	Proto3	temporal-sys-tq-scanner-taskqueue-0
\.


--
-- Data for Name: schema_update_history; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.schema_update_history (version_partition, year, month, update_time, description, manifest_md5, new_version, old_version) FROM stdin;
0	2025	7	2025-07-09 06:28:44.53567	initial version		0.0	0
0	2025	7	2025-07-09 06:28:44.564664	base version of visibility schema	698373883c1c0dd44607a446a62f2a79	1.0	0.0
0	2025	7	2025-07-09 06:28:44.56733	add close time & status index	e286f8af0a62e291b35189ce29d3fff3	1.1	1.0
\.


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: public; Owner: developer
--

COPY public.schema_version (version_partition, db_name, creation_time, curr_version, min_compatible_version) FROM stdin;
0	temporal_visibility	2025-07-09 06:28:44.566881	1.1	0.1
\.


--
-- Name: executions_visibility executions_visibility_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.executions_visibility
    ADD CONSTRAINT executions_visibility_pkey PRIMARY KEY (namespace_id, run_id);


--
-- Name: schema_update_history schema_update_history_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.schema_update_history
    ADD CONSTRAINT schema_update_history_pkey PRIMARY KEY (version_partition, year, month, update_time);


--
-- Name: schema_version schema_version_pkey; Type: CONSTRAINT; Schema: public; Owner: developer
--

ALTER TABLE ONLY public.schema_version
    ADD CONSTRAINT schema_version_pkey PRIMARY KEY (version_partition, db_name);


--
-- Name: by_close_time_by_status; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX by_close_time_by_status ON public.executions_visibility USING btree (namespace_id, close_time DESC, run_id, status);


--
-- Name: by_status_by_close_time; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX by_status_by_close_time ON public.executions_visibility USING btree (namespace_id, status, close_time DESC, run_id);


--
-- Name: by_status_by_start_time; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX by_status_by_start_time ON public.executions_visibility USING btree (namespace_id, status, start_time DESC, run_id);


--
-- Name: by_type_close_time; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX by_type_close_time ON public.executions_visibility USING btree (namespace_id, workflow_type_name, status, close_time DESC, run_id);


--
-- Name: by_type_start_time; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX by_type_start_time ON public.executions_visibility USING btree (namespace_id, workflow_type_name, status, start_time DESC, run_id);


--
-- Name: by_workflow_id_close_time; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX by_workflow_id_close_time ON public.executions_visibility USING btree (namespace_id, workflow_id, status, close_time DESC, run_id);


--
-- Name: by_workflow_id_start_time; Type: INDEX; Schema: public; Owner: developer
--

CREATE INDEX by_workflow_id_start_time ON public.executions_visibility USING btree (namespace_id, workflow_id, status, start_time DESC, run_id);


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

