<?php

return array(
    'Help on Mattermost integration' => 'Guida all\'integrazione con Mattermost',
    // 'Channel/Group/User (Optional)' => '',
);

