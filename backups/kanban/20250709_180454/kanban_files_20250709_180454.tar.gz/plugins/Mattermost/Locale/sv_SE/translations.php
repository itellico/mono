<?php

return array(
    'Help on Mattermost integration' => 'Hjälp för Mattermost integration',
    'Channel/Group/User (Optional)' => 'Kanal/Grupp/Användare (valfri)',
);

