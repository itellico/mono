<?php

return array(
    'Help on Mattermost integration' => 'Nápověda pro Mattermost integraci.',
    'Channel/Group/User (Optional)' => 'Kanál/Skupina/Uživatel (volitelně)',
);

