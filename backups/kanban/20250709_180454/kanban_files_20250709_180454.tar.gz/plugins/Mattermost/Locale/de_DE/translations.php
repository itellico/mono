<?php

return array(
    'Help on Mattermost integration' => 'Hilfe für Mattermost-Integration.',
    'Channel/Group/User (Optional)' => 'Kanal/Gruppe/Benutzer (optional)',
);

