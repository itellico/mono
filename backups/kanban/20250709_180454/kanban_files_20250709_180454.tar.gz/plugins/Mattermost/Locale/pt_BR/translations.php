<?php

return array(
    'Help on Mattermost integration' => 'Ajuda sobre integração com o Mattermost',
    'Channel/Group/User (Optional)' => 'Canal/Grupo/Utilizador (Opcional)',
);

