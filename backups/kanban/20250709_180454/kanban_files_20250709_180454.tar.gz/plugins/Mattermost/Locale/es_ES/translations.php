<?php

return array(
    'Help on Mattermost integration' => 'Ayuda sobre integración Desatendida',
    'Channel/Group/User (Optional)' => 'Canal/Grupo/Usuario (Opcional)',
);

