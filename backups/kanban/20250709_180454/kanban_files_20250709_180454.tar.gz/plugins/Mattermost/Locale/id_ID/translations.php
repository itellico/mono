<?php

return array(
    'Help on Mattermost integration' => 'Bantuan pada integrasi Mattermost',
    'Channel/Group/User (Optional)' => 'Kanal/Grup/Pengguna (pilihan)',
);

