<?php

return array(
    'Help on Mattermost integration' => 'Aide sur l\'intégration avec Mattermost',
    'Channel/Group/User (Optional)' => 'Canal/Groupe/Utilisateur (Optionnel)',
);

