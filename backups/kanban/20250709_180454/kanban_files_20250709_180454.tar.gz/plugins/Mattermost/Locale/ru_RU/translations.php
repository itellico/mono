<?php

return array(
    'Help on Mattermost integration' => 'Помощь по интеграции Mattermost',
    'Channel/Group/User (Optional)' => 'Канал/Группа/Пользователь (опционально)',
);

