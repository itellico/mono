<?php

return array(
    'Help on Mattermost integration' => 'Mattermost 連携のヘルプ',
    // 'Channel/Group/User (Optional)' => '',
);

