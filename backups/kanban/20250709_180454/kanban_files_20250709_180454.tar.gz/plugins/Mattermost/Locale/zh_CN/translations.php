<?php

return array(
    'Help on Mattermost integration' => 'Mattermost 整合帮助',
    // 'Channel/Group/User (Optional)' => '',
);

